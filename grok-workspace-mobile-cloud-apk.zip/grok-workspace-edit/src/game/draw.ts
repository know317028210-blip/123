import { ITEMS, TILE } from "./content";
import type { RaidState } from "./engine";

const FLOOR = ["#263b27", "#2b422b", "#233624"];
const WALL = "#555447";
const WALL_LIP = "#81785e";
const WALL_FOOT = "#292c22";

function hash(tx: number, ty: number) {
  return ((tx * 73856093) ^ (ty * 19349663)) >>> 0;
}

function tileVisible(state: RaidState, tx: number, ty: number) {
  const { map, visible } = state;
  if (tx < 0 || ty < 0 || tx >= map.w || ty >= map.h) return false;
  return visible[ty * map.w + tx] === 1;
}

export function drawRaid(ctx: CanvasRenderingContext2D, state: RaidState, cssW: number, cssH: number, dpr: number) {
  const { map } = state;
  const zoom = state.zoom;
  const viewW = cssW / zoom;
  const viewH = cssH / zoom;
  let camX = state.camX;
  let camY = state.camY;
  const maxX = map.w * TILE - viewW / 2;
  const maxY = map.h * TILE - viewH / 2;
  if (map.w * TILE > viewW) camX = Math.max(viewW / 2, Math.min(maxX, camX));
  else camX = (map.w * TILE) / 2;
  if (map.h * TILE > viewH) camY = Math.max(viewH / 2, Math.min(maxY, camY));
  else camY = (map.h * TILE) / 2;
  const sh = state.shake > 0.2 ? (Math.random() - 0.5) * state.shake : 0;
  const sv = state.shake > 0.2 ? (Math.random() - 0.5) * state.shake : 0;

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = "#101810";
  ctx.fillRect(0, 0, cssW, cssH);

  ctx.setTransform(dpr * zoom, 0, 0, dpr * zoom, dpr * (cssW / 2 - camX * zoom + sh), dpr * (cssH / 2 - camY * zoom + sv));

  const x0 = Math.max(0, Math.floor((camX - viewW / 2) / TILE) - 1);
  const y0 = Math.max(0, Math.floor((camY - viewH / 2) / TILE) - 1);
  const x1 = Math.min(map.w - 1, Math.ceil((camX + viewW / 2) / TILE) + 1);
  const y1 = Math.min(map.h - 1, Math.ceil((camY + viewH / 2) / TILE) + 1);

  for (let ty = y0; ty <= y1; ty++) {
    for (let tx = x0; tx <= x1; tx++) {
      const k = ty * map.w + tx;
      if (!state.explored[k]) continue;
      const px = tx * TILE;
      const py = ty * TILE;
      const solid = map.tiles[k] === 1;
      const riverX = Math.floor(map.w * 0.34 + Math.sin(ty * 0.23) * 3.2);
      const river = !solid && Math.abs(tx - riverX) <= 1;
      if (river) {
        ctx.fillStyle = hash(tx, ty) % 2 ? "#315f68" : "#386d75";
        ctx.fillRect(px, py, TILE, TILE);
        ctx.fillStyle = "rgba(164,220,218,0.26)";
        ctx.fillRect(px + 5 + (hash(tx,ty)%20), py + 12, 17, 2);
        ctx.fillRect(px + 12, py + 31 + (hash(ty,tx)%6), 12, 2);
      } else if (solid) {
        ctx.fillStyle = WALL;
        ctx.fillRect(px, py, TILE, TILE);
        ctx.fillStyle = WALL_LIP;
        ctx.fillRect(px, py, TILE, 5);
        ctx.fillStyle = WALL_FOOT;
        ctx.fillRect(px, py + TILE - 7, TILE, 7);
      } else {
        ctx.fillStyle = FLOOR[hash(tx, ty) % FLOOR.length]!;
        ctx.fillRect(px, py, TILE, TILE);
        if (hash(tx, ty) % 11 === 0) {
          ctx.fillStyle = "rgba(172,205,116,0.16)";
          ctx.fillRect(px + 6, py + 8, 14, 3);
          ctx.fillStyle = hash(tx, ty) % 2 ? "rgba(216,190,112,0.48)" : "rgba(164,195,111,0.35)";
          ctx.fillRect(px + 12 + (hash(tx,ty)%13), py + 25 + (hash(ty,tx)%10), 2, 4);
        }
      }
      if (!state.visible[k]) {
        ctx.fillStyle = "rgba(8,10,8,0.72)";
        ctx.fillRect(px, py, TILE, TILE);
      }
    }
  }

  const t = performance.now() / 1000;
  for (const ex of map.extracts) {
    const tx = Math.floor(ex.x / TILE);
    const ty = Math.floor(ex.y / TILE);
    if (!state.explored[ty * map.w + tx]) continue;
    const open = ex.gated === "none" || (ex.gated === "switch" ? state.gateOpen : hasKey(state));
    ctx.save();
    ctx.translate(ex.x, ex.y);
    ctx.strokeStyle = open ? "rgba(180,220,133,0.9)" : "rgba(177,91,75,0.8)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, 0, 28 + Math.sin(t * 3) * 2, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = tileVisible(state, tx, ty) ? 1 : 0.35;
    ctx.fillStyle = open ? "#a9d77b" : "#a24e43";
    ctx.font = "11px WenQuanYi Zen Hei, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(ex.name, 0, 4);
    ctx.restore();
  }

  for (const sw of map.switches) {
    const tx = Math.floor(sw.x / TILE);
    const ty = Math.floor(sw.y / TILE);
    if (!state.explored[ty * map.w + tx]) continue;
    ctx.save();
    ctx.translate(sw.x, sw.y);
    ctx.fillStyle = state.gateOpen ? "#e0a53a" : "#3a4034";
    ctx.fillRect(-8, -10, 16, 20);
    ctx.fillStyle = "#0e100e";
    ctx.fillRect(-2, state.gateOpen ? -6 : 0, 4, 8);
    ctx.restore();
  }

  for (const box of state.boxes) {
    const tx = Math.floor(box.x / TILE);
    const ty = Math.floor(box.y / TILE);
    if (!tileVisible(state, tx, ty) && box.kind !== "body") {
      if (!state.explored[ty * map.w + tx]) continue;
    }
    if (!state.explored[ty * map.w + tx]) continue;
    const dim = state.visible[ty * map.w + tx] ? 1 : 0.35;
    ctx.save();
    ctx.globalAlpha = dim;
    ctx.translate(box.x, box.y);
    if (box.kind === "body") {
      ctx.fillStyle = "#6e3a30";
      ctx.beginPath();
      ctx.ellipse(0, 0, 11, 7, 0.4, 0, Math.PI * 2);
      ctx.fill();
    } else {
      const col =
        box.kind === "safe" ? "#8a7044" : box.kind === "med" ? "#6d7d62" : box.kind === "weapon" ? "#4d5960" : box.kind === "key" ? "#a6843a" : "#6a5340";
      ctx.fillStyle = col;
      ctx.fillRect(-13, -11, 26, 22);
      ctx.fillStyle = "rgba(0,0,0,0.25)";
      ctx.fillRect(-13, -11, 26, 5);
      if (!box.open) {
        ctx.strokeStyle = "#e0a53a";
        ctx.lineWidth = 1.5;
        ctx.strokeRect(-13, -11, 26, 22);
      }
    }
    ctx.restore();
  }

  for (const b of state.bullets) {
    if (!b.alive) continue;
    ctx.strokeStyle = b.team === 0 ? "#b8f29d" : "#d58ee6";
    ctx.globalAlpha = 0.95;
    ctx.lineWidth = b.team === 0 ? 2.6 : 2;
    ctx.beginPath();
    ctx.moveTo(b.px, b.py);
    ctx.lineTo(b.x, b.y);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  for (const s of state.scavs) {
    if (!s.alive) continue;
    const tx = Math.floor(s.x / TILE);
    const ty = Math.floor(s.y / TILE);
    if (!tileVisible(state, tx, ty)) continue;
    drawActor(ctx, s.x, s.y, s.aim, "scav", s.flash > 0);
    const ratio = s.hp / s.maxHp;
    ctx.fillStyle = "rgba(0,0,0,0.55)";
    ctx.fillRect(s.x - 12, s.y - 22, 24, 3);
    ctx.fillStyle = ratio > 0.4 ? "#c4452d" : "#e0a53a";
    ctx.fillRect(s.x - 12, s.y - 22, 24 * ratio, 3);
  }

  for (const bit of state.particles) {
    if (!bit.alive) continue;
    ctx.globalAlpha = Math.max(0, bit.life / bit.max);
    ctx.fillStyle = bit.color;
    ctx.fillRect(bit.x, bit.y, bit.r, bit.r);
    ctx.globalAlpha = 1;
  }

  const p = state.player;
  drawActor(ctx, p.x, p.y, p.aim, "player", p.hit > 0);
  if (state.recoil > 0) {
    const kick = state.recoil * 8;
    ctx.fillStyle = `rgba(240,212,138,${0.35 + state.recoil * 0.4})`;
    ctx.beginPath();
    ctx.arc(p.x + Math.cos(p.aim) * (22 + kick), p.y + Math.sin(p.aim) * (22 + kick), 4 + state.recoil * 3, 0, Math.PI * 2);
    ctx.fill();
  }
  if (p.extract > 0) {
    ctx.strokeStyle = "#e0a53a";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(p.x, p.y, 22, -Math.PI / 2, -Math.PI / 2 + (p.extract / 5) * Math.PI * 2);
    ctx.stroke();
  }

  ctx.font = "12px WenQuanYi Zen Hei, sans-serif";
  ctx.textAlign = "center";
  for (const ft of state.texts) {
    ctx.globalAlpha = Math.max(0, ft.life / 0.7);
    ctx.fillStyle = ft.color;
    ctx.fillText(ft.text, ft.x, ft.y - (0.7 - ft.life) * 20);
  }
  ctx.globalAlpha = 1;

  if (state.player && aimReticle(state)) {
    const ax = state.player.x + Math.cos(state.player.aim) * 70;
    const ay = state.player.y + Math.sin(state.player.aim) * 70;
    ctx.strokeStyle = "rgba(224,165,58,0.8)";
    ctx.lineWidth = 1.25;
    ctx.beginPath();
    ctx.arc(ax, ay, 5, 0, Math.PI * 2);
    ctx.moveTo(ax - 9, ay);
    ctx.lineTo(ax - 3, ay);
    ctx.moveTo(ax + 3, ay);
    ctx.lineTo(ax + 9, ay);
    ctx.moveTo(ax, ay - 9);
    ctx.lineTo(ax, ay - 3);
    ctx.moveTo(ax, ay + 3);
    ctx.lineTo(ax, ay + 9);
    ctx.stroke();
  }

  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const g = ctx.createRadialGradient(cssW / 2, cssH / 2, cssW * 0.2, cssW / 2, cssH / 2, cssW * 0.72);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, state.player.hp < 35 ? "rgba(120,24,16,0.45)" : "rgba(0,0,0,0.38)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, cssW, cssH);
  if (state.flash > 0) {
    ctx.fillStyle = `rgba(196,69,45,${state.flash * 0.45})`;
    ctx.fillRect(0, 0, cssW, cssH);
  }

  drawMinimap(ctx, state, cssW);
}

function hasKey(state: RaidState) {
  const id = state.map.keyId;
  if (!id) return false;
  return [...state.player.pack, ...state.player.secure].some((it) => it.defId === id);
}

function aimReticle(state: RaidState) {
  return !state.outcome;
}

function drawActor(ctx: CanvasRenderingContext2D, x: number, y: number, aim: number, kind: "player" | "scav", flash: boolean) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(aim);
  ctx.scale(1.2, 1.2);
  ctx.fillStyle = "rgba(0,0,0,0.35)";
  ctx.beginPath();
  ctx.ellipse(1, 6, 12, 6, 0, 0, Math.PI * 2);
  ctx.fill();
  // Hooded adventurer silhouette; the staff/wand points toward the current aim.
  ctx.fillStyle = kind === "player" ? "#263d32" : "#352b37";
  ctx.beginPath();
  ctx.moveTo(-13, -5);
  ctx.lineTo(-4, -9);
  ctx.lineTo(7, -6);
  ctx.lineTo(10, 0);
  ctx.lineTo(6, 7);
  ctx.lineTo(-8, 8);
  ctx.lineTo(-14, 3);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = flash ? "#fff9dc" : kind === "player" ? "#557b55" : "#77516b";
  ctx.beginPath();
  ctx.moveTo(-8, -7);
  ctx.lineTo(-2, -13);
  ctx.lineTo(5, -7);
  ctx.lineTo(3, 2);
  ctx.lineTo(-4, 3);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = flash ? "#ffffff" : "#d9c7a6";
  ctx.beginPath();
  ctx.arc(2, 0, 4.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = kind === "player" ? "#9edb94" : "#d48cbe";
  ctx.beginPath();
  ctx.arc(3.5, -1, 1.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = kind === "player" ? "#9bd48d" : "#c58bd8";
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(6, 2);
  ctx.lineTo(kind === "player" ? 21 : 17, 2);
  ctx.stroke();
  ctx.fillStyle = kind === "player" ? "#b4ed9e" : "#e4a2df";
  ctx.beginPath();
  ctx.arc(kind === "player" ? 22 : 18, 2, 2.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawMinimap(ctx: CanvasRenderingContext2D, state: RaidState, cssW: number) {
  const { map } = state;
  const size = 118;
  const pad = 12;
  const x = cssW - size - pad;
  const y = pad;
  ctx.fillStyle = "rgba(14,16,14,0.78)";
  ctx.fillRect(x - 4, y - 4, size + 8, size + 8);
  ctx.strokeStyle = "#343b2e";
  ctx.strokeRect(x - 4, y - 4, size + 8, size + 8);
  const sx = size / map.w;
  const sy = size / map.h;
  for (let ty = 0; ty < map.h; ty++) {
    for (let tx = 0; tx < map.w; tx++) {
      if (!state.explored[ty * map.w + tx]) continue;
      ctx.fillStyle = map.tiles[ty * map.w + tx] === 1 ? "#3a4434" : "#1e261c";
      ctx.fillRect(x + tx * sx, y + ty * sy, Math.ceil(sx), Math.ceil(sy));
    }
  }
  ctx.fillStyle = "#e0a53a";
  for (const ex of map.extracts) {
    const tx = Math.floor(ex.x / TILE);
    const ty = Math.floor(ex.y / TILE);
    if (!state.explored[ty * map.w + tx]) continue;
    ctx.fillRect(x + tx * sx, y + ty * sy, Math.max(2, sx), Math.max(2, sy));
  }
  ctx.fillStyle = "#c4452d";
  for (const s of state.scavs) {
    if (!s.alive) continue;
    const tx = Math.floor(s.x / TILE);
    const ty = Math.floor(s.y / TILE);
    if (!tileVisible(state, tx, ty)) continue;
    ctx.fillRect(x + (s.x / TILE) * sx - 1, y + (s.y / TILE) * sy - 1, 2.5, 2.5);
  }
  ctx.fillStyle = "#f0e6c8";
  ctx.fillRect(x + (state.player.x / TILE) * sx - 1.5, y + (state.player.y / TILE) * sy - 1.5, 3, 3);
}

export function weaponLabel(state: RaidState) {
  const w = state.player.weapon;
  if (!w) return "徒手";
  return ITEMS[w.defId]?.name ?? "武器";
}
