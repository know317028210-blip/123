# 秘境边境：手机端 / 双端互通开发说明

## 本轮源码改造

- 增加独立的 `mobile.html` + `src/mobile.tsx`，把游戏作为纯客户端入口运行在 Android WebView 中；原有桌面 Web/服务端入口不变。
- 增加 `vite.mobile.config.ts`，构建输出到 `mobile-dist/`，供 Capacitor 打包使用。
- 增加 `capacitor.config.ts`，应用 ID 为 `com.secretfrontier.game`。
- 出击界面补充触屏攻击（按住）、换弹、交互/搜索、治疗、背包和暂停按钮；双虚拟摇杆保留。加入全面屏安全区和防止浏览器手势抢占操作的样式。
- 增加 `src/game/sync-contract.ts`，定义版本化云存档 envelope、远端同步适配器和 GET/PUT API 合约。

## Android APK 构建

环境需要 Node.js 22+、npm、Android Studio、Android SDK 和 JDK 17。首次需要联网安装依赖。

```bash
npm install
npm install @capacitor/core @capacitor/android
npm install -D @capacitor/cli
npm run mobile:build
npx cap add android       # 只在第一次执行
npx cap sync android
npx cap open android      # 在 Android Studio 中构建/运行
```

命令行构建 Debug APK（需已安装 Android SDK，并设置好 `ANDROID_HOME` / `ANDROID_SDK_ROOT`）：

```bash
cd android
./gradlew assembleDebug
```

输出一般位于 `android/app/build/outputs/apk/debug/app-debug.apk`。Windows 使用 `gradlew.bat assembleDebug`。

## 当前限制与跨设备同步

- 当前存档仍使用浏览器 / WebView 的 `localStorage`，因此手机和电脑各自保存；尚未实现真实云同步。
- `sync-contract.ts` 是服务端接入契约，不会自行创建服务器。后续需要有登录鉴权的服务器实现 `GET /api/game/save?playerId=...` 和 `PUT /api/game/save`，校验 payload、处理 revision 冲突并做账号隔离。
- 不要仅凭客户端传入的 `playerId` 授权；服务端必须从已验证的会话 / token 确定用户身份。
- 本轮环境没有安装项目 npm 依赖，也没有 Android SDK / Gradle，因此没有在此环境生成或验证 APK。源码包可用于本地继续构建，但不能宣称已经生成可安装包。

## 用手机通过 GitHub 云端生成 APK（无需电脑编译）

1. 将本项目文件夹中的全部内容上传到你自己的 GitHub 仓库（仓库根目录应直接包含 `package.json` 和 `.github/`）。
2. 打开仓库的 **Actions** 标签页，选择 **Build Android APK** 工作流，点 **Run workflow**。
3. 等待工作流结束。绿色勾号代表构建成功；红色叉号表示构建失败，需要点进去查看日志。
4. 进入这次成功的工作流运行详情，滚动到 **Artifacts**，下载 `secret-frontier-debug-apk`，解压后得到 `app-debug.apk`。
5. 在安卓手机上打开 APK 安装。若系统询问是否允许此来源安装应用，只对自己构建且信任的文件授权。

说明：这是未签名的调试版 APK，适合个人试玩，不是可直接上架应用商店的正式发行包。云端构建需要 GitHub 仓库和 Actions 可用；若构建失败，查看日志中的第一条实际错误。工作流使用 `npm ci`，依赖安装与客户端构建都可能暴露项目原有依赖或导入问题，不能保证首次构建一定成功。
