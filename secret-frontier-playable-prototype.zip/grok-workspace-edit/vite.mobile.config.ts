import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

/** Static client-only build used by Capacitor; the normal web/server build is unchanged. */
export default defineConfig({
  base: "./",
  plugins: [tailwindcss(), react()],
  resolve: { tsconfigPaths: true },
  build: {
    outDir: "mobile-dist",
    emptyOutDir: true,
    rollupOptions: { input: "mobile.html" },
    target: "es2022",
  },
});
