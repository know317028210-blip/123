import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { GameApp } from "@/components/GameApp";
import "./styles.css";

const root = document.getElementById("root");
if (!root) throw new Error("Mobile app root element is missing");

createRoot(root).render(
  <StrictMode>
    <GameApp />
  </StrictMode>,
);
