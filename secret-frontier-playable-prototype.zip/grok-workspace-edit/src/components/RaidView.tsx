import { useEffect, useRef, useState } from "react";
import { ITEMS } from "@/game/content";
import { drawRaid, weaponLabel } from "@/game/draw";
import {
  createRaid,
  medsLeft,
  raidDrop,
  raidEquip,
  raidTransfer,
  reserveAmmo,
  snapshot,
  step,
  type InputState,
  type RaidState,
} from "@/game/engine";
import { carryWeight, sellValue, slotsOf } from "@/game/inventory";
import { sfx, setSfxVolume, unlockAudio } from "@/game/audio";
import type { RaidEnd, RaidSetup } from "@/game/types";

type Props = {
  setup: RaidSetup;
  sfxVol: number;
  onEnd: (result: RaidEnd) => void;
};

export function RaidView({ setup, sfxVol, onEnd }: Props) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef<RaidState | null>(null);
  const keysRef = useRef(new Set<string>());
  const qaRef = useRef<Set<string> | null>(null);
  const edges = useRef({ interact: false, reload: false, heal: false });
  const fireRef = useRef(false);
  const aimRef = useRef({ x: 0, y: 0, ok: false });
  const stickRef = useRef({ mx: 0, my: 0, ax: 0, ay: 0, aim: false });
  const onEndRef = useRef(onEnd);
  onEndRef.current = onEnd;
  const [hud, setHud] = useState({
    hp: 100,
    time: setup.mapId ? 0 : 0,
    mag: 0,
    reserve: 0,
    weapon: "",
    prompt: "",
    msg: "",
    kills: 0,
    weight: 0,
    limit: setup.weightLimit,
    extract: 0,
    buff: 0,
    meds: 0,
    area: "",
    map: "",
    outcome: "" as string,
  });
  const [panel, setPanel] = useState<null | "pack" | "pause">(null);
  const [tick, setTick] = useState(0);
  const [touch, setTouch] = useState(false);
  const panelRef = useRef(panel);
  panelRef.current = panel;

  useEffect(() => {
    const coarse = window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 860;
    setTouch(coarse);
    setSfxVolume(sfxVol);
  }, [sfxVol]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const state = createRaid(setup);
    stateRef.current = state;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    let raf = 0;
    let last = performance.now();
    let acc = 0;
    let hudAcc = 0;
    const ended = { done: false };

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      canvas.width = Math.max(1, Math.floor(rect.width * dpr));
      canvas.height = Math.max(1, Math.floor(rect.height * dpr));
      state.viewW = rect.width;
      state.viewH = rect.height;
      state.zoom = rect.width < 700 ? Math.min(1.15, rect.width / 520) : 1.28;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(canvas);

    const build = (): InputState => {
      const qa = qaRef.current;
      const keys = qa ?? keysRef.current;
      let mx = 0;
      let my = 0;
      if (keys.has("KeyA") || keys.has("ArrowLeft")) mx -= 1;
      if (keys.has("KeyD") || keys.has("ArrowRight")) mx += 1;
      if (keys.has("KeyW") || keys.has("ArrowUp")) my -= 1;
      if (keys.has("KeyS") || keys.has("ArrowDown")) my += 1;
      if (!qa && (stickRef.current.mx || stickRef.current.my)) {
        mx = stickRef.current.mx;
        my = stickRef.current.my;
      }
      let aimX = aimRef.current.x;
      let aimY = aimRef.current.y;
      let aimOk = aimRef.current.ok;
      const aiming = !qa && stickRef.current.aim;
      if (aiming) {
        aimX = state.player.x + stickRef.current.ax * 240;
        aimY = state.player.y + stickRef.current.ay * 240;
        aimOk = true;
      }
      const input: InputState = {
        mx,
        my,
        fire: fireRef.current || aiming,
        aimX,
        aimY,
        aimOk,
        interact: edges.current.interact,
        reload: edges.current.reload,
        heal: edges.current.heal,
      };
      edges.current.interact = false;
      edges.current.reload = false;
      edges.current.heal = false;
      return input;
    };

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      acc += dt;
      const fixed = 1 / 60;
      let guard = 0;
      while (acc >= fixed && guard++ < 5) {
        step(state, fixed, build());
        acc -= fixed;
      }
      for (const ev of state.events) sfx(ev);
      const rect = canvas.getBoundingClientRect();
      const dpr = Math.min(2, window.devicePixelRatio || 1);
      drawRaid(ctx, state, rect.width, rect.height, dpr);
      hudAcc += dt;
      if (hudAcc > 0.12) {
        hudAcc = 0;
        const gear = { weapon: state.player.weapon, armor: state.player.armor, helmet: state.player.helmet };
        setHud({
          hp: Math.max(0, Math.round(state.player.hp)),
          time: Math.max(0, state.time),
          mag: state.player.mag,
          reserve: reserveAmmo(state.player),
          weapon: weaponLabel(state),
          prompt: state.prompt,
          msg: state.msgT > 0 ? state.msg : "",
          kills: state.kills,
          weight: carryWeight(gear, state.player.pack, state.player.secure),
          limit: state.weightLimit,
          extract: state.player.extract,
          buff: state.player.buff,
          meds: medsLeft(state.player),
          area: state.map.area,
          map: state.map.name,
          outcome: state.outcome ?? "",
        });
        if (state.lootId && panelRef.current !== "pack") setPanel("pack");
      }
      if (state.outcome && state.endTimer <= 0 && !state.reported && !ended.done) {
        state.reported = true;
        ended.done = true;
        onEndRef.current(snapshot(state));
      }
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);

    const down = (e: KeyboardEvent) => {
      if (e.repeat) return;
      keysRef.current.add(e.code);
      const block = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space", "KeyW", "KeyA", "KeyS", "KeyD"];
      if (block.includes(e.code)) e.preventDefault();
      if (e.code === "KeyF" || e.code === "KeyE") {
        edges.current.interact = true;
        e.preventDefault();
      }
      if (e.code === "KeyR") edges.current.reload = true;
      if (e.code === "KeyH" || e.code === "Digit1") edges.current.heal = true;
      if (e.code === "Tab") {
        e.preventDefault();
        togglePack();
      }
      if (e.code === "Escape") {
        const s = stateRef.current;
        if (!s || s.outcome) return;
        if (s.lootId || panelRef.current === "pack") closePanels();
        else {
          s.paused = true;
          setPanel("pause");
        }
      }
    };
    const up = (e: KeyboardEvent) => keysRef.current.delete(e.code);
    const blur = () => {
      keysRef.current.clear();
      fireRef.current = false;
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    window.addEventListener("blur", blur);

    window.__controlsTest = {
      getYaw: () => state.player.aim,
      getSpeed: () => Math.hypot(state.player.vx, state.player.vy),
      setKeys: (codes: string[]) => {
        qaRef.current = new Set(codes);
      },
      getX: () => state.player.x,
      getY: () => state.player.y,
    };
    if (import.meta.env.DEV) {
      window.__raidTest = {
        forceExtract: () => {
          if (state.outcome) return;
          state.outcome = "extract";
          state.endTimer = 0.05;
        },
        killAll: () => {
          for (const s of state.scavs) if (s.alive) s.hp = 0;
        },
      };
    }

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
      window.removeEventListener("blur", blur);
      delete window.__controlsTest;
      delete window.__raidTest;
    };
    // setup is stable for the life of this mount
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [setup]);

  function closePanels() {
    const s = stateRef.current;
    if (!s || s.outcome) return;
    s.paused = false;
    s.lootId = null;
    setPanel(null);
  }

  function togglePack() {
    const s = stateRef.current;
    if (!s || s.outcome) return;
    if (panelRef.current === "pause") {
      closePanels();
      return;
    }
    if (s.paused && (s.lootId || panelRef.current === "pack")) {
      closePanels();
      return;
    }
    s.paused = true;
    setPanel("pack");
  }

  function toWorld(clientX: number, clientY: number) {
    const canvas = canvasRef.current;
    const st = stateRef.current;
    if (!canvas || !st) return;
    const rect = canvas.getBoundingClientRect();
    aimRef.current.ok = true;
    aimRef.current.x = (clientX - rect.left - rect.width / 2) / st.zoom + st.camX;
    aimRef.current.y = (clientY - rect.top - rect.height / 2) / st.zoom + st.camY;
  }

  const clock = `${Math.floor(hud.time / 60)}:${String(Math.floor(hud.time % 60)).padStart(2, "0")}`;
  const low = hud.hp < 35;
  const st = stateRef.current;
  const box = st?.boxes.find((b) => b.id === st.lootId) ?? null;

  return (
    <div className="relative h-dvh w-full select-none overflow-hidden bg-bg text-fg touch-none">
      <canvas
        ref={canvasRef}
        className="absolute inset-0 h-full w-full"
        onContextMenu={(e) => e.preventDefault()}
        onPointerDown={(e) => {
          if (e.pointerType === "touch") return;
          unlockAudio();
          if (e.button === 0) {
            fireRef.current = true;
            toWorld(e.clientX, e.clientY);
          }
        }}
        onPointerMove={(e) => {
          if (e.pointerType === "touch") return;
          toWorld(e.clientX, e.clientY);
        }}
        onPointerUp={(e) => {
          if (e.button === 0) fireRef.current = false;
        }}
        onPointerLeave={() => {
          fireRef.current = false;
        }}
      />
      <div className="pointer-events-none absolute inset-0 p-3">
        <div className="w-2/3 max-w-sm">
          <div className="font-mono text-xs tracking-widest text-amber">{hud.area || "战区"}</div>
          <div className="text-xl leading-tight">{hud.map || "进入中"}</div>
          <div className="mt-2 h-2 w-44 bg-surface-2">
            <div className={`h-full ${low ? "bg-blood" : "bg-amber"}`} style={{ width: `${hud.hp}%` }} />
          </div>
          <div className="mt-1 flex flex-wrap gap-x-3 font-mono text-xs text-muted">
            <span className={low ? "text-blood" : "text-fg"}>{hud.hp} HP</span>
            <span>{clock}</span>
            <span>击倒 {hud.kills}</span>
            {hud.buff > 0 ? <span className="text-amber">止痛 {Math.ceil(hud.buff)}s</span> : null}
          </div>
          <div className="mt-2 text-sm">
            {hud.weapon}{" "}
            <span className="font-mono text-amber">
              {hud.mag}
              <span className="text-muted"> / {hud.reserve}</span>
            </span>
          </div>
          <div className="font-mono text-xs text-muted">
            负重 {hud.weight.toFixed(1)} / {hud.limit} kg · 医疗 {hud.meds}
          </div>
          {hud.prompt ? <div className="mt-2 bg-surface/80 px-2 py-1 text-sm text-amber">{hud.prompt}</div> : null}
          {hud.msg ? <div className="mt-2 text-sm text-fg">{hud.msg}</div> : null}
          <p className="mt-2 hidden text-xs text-muted sm:block">WASD 移动 · 鼠标瞄准并按住射击 · F 搜索 · R 换弹 · H 治疗 · Tab 背包</p>
        </div>
      </div>

      <div className={`pointer-events-auto absolute z-20 flex flex-wrap gap-2 ${touch ? "bottom-[calc(env(safe-area-inset-bottom)+9.5rem)] left-1/2 w-[min(92vw,28rem)] -translate-x-1/2 justify-center" : "bottom-4 left-3"}`}>
        <HudButton label="交互 / 搜索" onClick={() => { edges.current.interact = true; }} />
        <HudButton label="换弹" onClick={() => { edges.current.reload = true; }} />
        <HudButton label="治疗" onClick={() => { edges.current.heal = true; }} />
        <HudButton label="背包" onClick={togglePack} />
        <HudButton label="暂停" onClick={() => {
          const s = stateRef.current;
          if (!s || s.outcome) return;
          s.paused = true;
          setPanel("pause");
        }} />
      </div>

      {touch ? (
        <>
          <Stick
            side="left"
            onChange={(x, y) => {
              stickRef.current.mx = x;
              stickRef.current.my = y;
            }}
          />
          <Stick
            side="right"
            onChange={(x, y, active) => {
              stickRef.current.ax = x;
              stickRef.current.ay = y;
              stickRef.current.aim = active;
            }}
          />
          <button
            aria-label="按住施放魔法攻击"
            className="mobile-fire pointer-events-auto absolute bottom-[calc(env(safe-area-inset-bottom)+2rem)] right-[9.5rem] z-20 flex size-[4.25rem] items-center justify-center rounded-full border-2 border-amber bg-blood/85 text-sm font-bold text-white shadow-lg active:scale-95"
            onPointerDown={(e) => {
              e.preventDefault();
              e.currentTarget.setPointerCapture(e.pointerId);
              unlockAudio();
              const live = stateRef.current;
              if (live) {
                aimRef.current.x = live.player.x + Math.cos(live.player.aim) * 240;
                aimRef.current.y = live.player.y + Math.sin(live.player.aim) * 240;
                aimRef.current.ok = true;
              }
              fireRef.current = true;
            }}
            onPointerUp={() => { fireRef.current = false; }}
            onPointerCancel={() => { fireRef.current = false; }}
            onLostPointerCapture={() => { fireRef.current = false; }}
          >
            攻击
          </button>
        </>
      ) : null}

      {panel === "pause" && !hud.outcome ? (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-bg/80 p-4">
          <div className="w-full max-w-sm border border-line bg-surface p-5">
            <h2 className="text-xl">暂停</h2>
            <p className="mt-2 text-sm text-muted">计时已停。放弃会按失踪结算，带出来的只有安全箱。</p>
            <div className="mt-4 flex flex-col gap-2">
              <button className="min-h-11 bg-amber px-3 text-bg" onClick={closePanels}>
                继续
              </button>
              <button
                className="min-h-11 border border-blood px-3 text-blood"
                onClick={() => {
                  const s = stateRef.current;
                  if (!s || s.outcome) return;
                  s.paused = false;
                  s.lootId = null;
                  s.outcome = "mia";
                  s.endTimer = 0.05;
                  setPanel(null);
                }}
              >
                放弃本局
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {panel === "pack" && st && !hud.outcome ? (
        <div className="absolute inset-0 z-30 flex items-end justify-center bg-bg/70 p-3 sm:items-center">
          <div className="max-h-[85dvh] w-full max-w-lg overflow-y-auto border border-line bg-surface p-4">
            <div className="flex items-center justify-between gap-3">
              <h2 className="text-lg">{box ? "搜索" : "携带物品"}</h2>
              <button className="min-h-11 px-3 text-amber" onClick={closePanels}>
                关闭
              </button>
            </div>
            {box ? (
              <section className="mt-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm text-muted">里面</h3>
                  <button
                    className="min-h-11 px-2 text-sm text-amber"
                    onClick={() => {
                      const live = stateRef.current;
                      const liveBox = live?.boxes.find((b) => b.id === live.lootId);
                      if (!live || !liveBox) return;
                      for (const it of liveBox.items.slice()) {
                        if (!raidTransfer(live, "box", "pack", it.uid)) raidTransfer(live, "box", "secure", it.uid);
                      }
                      setTick((n) => n + 1);
                    }}
                  >
                    能拿的都拿走
                  </button>
                </div>
                <ItemBlock
                  items={box.items}
                  empty="空了。"
                  action="拿走"
                  onAction={(uid) => {
                    const live = stateRef.current;
                    if (!live) return;
                    if (!raidTransfer(live, "box", "pack", uid)) {
                      if (!raidTransfer(live, "box", "secure", uid)) return;
                    }
                    setTick((n) => n + 1);
                  }}
                />
              </section>
            ) : null}
            <section className="mt-4">
              <h3 className="text-sm text-muted">
                背包 {slotsOf(st.player.pack)}/{st.packCap}
              </h3>
              <ItemBlock
                items={st.player.pack}
                empty="背包是空的。"
                action={box ? "放回" : "丢弃"}
                extra="装备"
                onAction={(uid) => {
                  const live = stateRef.current;
                  if (!live) return;
                  if (box) raidTransfer(live, "pack", "box", uid);
                  else raidDrop(live, uid);
                  setTick((n) => n + 1);
                }}
                onExtra={(uid) => {
                  const live = stateRef.current;
                  if (!live) return;
                  raidEquip(live, uid);
                  setTick((n) => n + 1);
                }}
                secureAction="放入安全箱"
                onSecure={(uid) => {
                  const live = stateRef.current;
                  if (!live) return;
                  raidTransfer(live, "pack", "secure", uid);
                  setTick((n) => n + 1);
                }}
              />
            </section>
            <section className="mt-4">
              <h3 className="text-sm text-amber">安全箱 {slotsOf(st.player.secure)}/{st.secureCap} · 死了也留得住</h3>
              <ItemBlock
                items={st.player.secure}
                empty="安全箱是空的。贵的东西放这里。"
                action="拿回背包"
                onAction={(uid) => {
                  const live = stateRef.current;
                  if (!live) return;
                  raidTransfer(live, "secure", "pack", uid);
                  setTick((n) => n + 1);
                }}
              />
            </section>
            <p className="mt-3 text-xs text-muted" data-tick={tick}>
              负重过高会变慢。治疗时开枪会打断包扎。
            </p>
          </div>
        </div>
      ) : null}

      {hud.outcome === "dead" || hud.outcome === "mia" ? (
        <div className="pointer-events-none absolute inset-0 z-40 flex items-center justify-center">
          <div className="border border-blood px-6 py-3 font-mono text-2xl tracking-widest text-blood">
            {hud.outcome === "mia" ? "失踪" : "失去意识"}
          </div>
        </div>
      ) : null}
      {hud.outcome === "extract" ? (
        <div className="pointer-events-none absolute inset-0 z-40 flex items-center justify-center">
          <div className="border border-amber px-6 py-3 font-mono text-2xl tracking-widest text-amber">已撤离</div>
        </div>
      ) : null}
    </div>
  );
}

function HudButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button className="min-h-11 min-w-14 bg-surface/90 px-3 text-sm text-fg border border-line" onClick={onClick}>
      {label}
    </button>
  );
}

function Stick({
  side,
  onChange,
}: {
  side: "left" | "right";
  onChange: (x: number, y: number, active: boolean) => void;
}) {
  const origin = useRef<{ x: number; y: number; id: number } | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  const end = () => {
    origin.current = null;
    setKnob({ x: 0, y: 0 });
    onChange(0, 0, false);
  };
  return (
    <div
      className={`mobile-stick absolute bottom-[calc(env(safe-area-inset-bottom)+1.5rem)] z-20 size-28 touch-none rounded-full border border-line bg-surface/70 shadow-lg ${side === "left" ? "left-4" : "right-4"}`}
      onPointerDown={(e) => {
        unlockAudio();
        e.currentTarget.setPointerCapture(e.pointerId);
        origin.current = { x: e.clientX, y: e.clientY, id: e.pointerId };
      }}
      onPointerMove={(e) => {
        if (!origin.current || origin.current.id !== e.pointerId) return;
        let dx = e.clientX - origin.current.x;
        let dy = e.clientY - origin.current.y;
        const len = Math.hypot(dx, dy);
        const max = 44;
        if (len > max) {
          dx = (dx / len) * max;
          dy = (dy / len) * max;
        }
        setKnob({ x: dx, y: dy });
        onChange(len > 6 ? dx / max : 0, len > 6 ? dy / max : 0, len > 6);
      }}
      onPointerUp={end}
      onPointerCancel={end}
    >
      <div
        className="pointer-events-none absolute left-1/2 top-1/2 size-11 rounded-full bg-amber/90"
        style={{ transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }}
      />
    </div>
  );
}

function ItemBlock({
  items,
  empty,
  action,
  onAction,
  extra,
  onExtra,
  secureAction,
  onSecure,
}: {
  items: { uid: string; defId: string; count: number; dur?: number }[];
  empty: string;
  action: string;
  onAction: (uid: string) => void;
  extra?: string;
  onExtra?: (uid: string) => void;
  secureAction?: string;
  onSecure?: (uid: string) => void;
}) {
  if (!items.length) return <p className="mt-1 text-sm text-muted">{empty}</p>;
  return (
    <ul className="mt-1">
      {items.map((it) => {
        const d = ITEMS[it.defId];
        if (!d) return null;
        const gear = d.cat === "weapon" || d.cat === "armor" || d.cat === "helmet";
        return (
          <li key={it.uid} className="flex flex-wrap items-center gap-2 border-b border-line py-2">
            <div className="min-w-0 flex-1">
              <div className={d.rarity === "rare" || d.rarity === "legendary" ? "text-amber" : "text-fg"}>
                {d.name}
                {d.stack ? ` ×${it.count}` : ""}
              </div>
              <div className="font-mono text-xs text-muted">{sellValue(it).toLocaleString("zh-CN")} ₽</div>
            </div>
            {secureAction && onSecure ? (
              <button className="min-h-11 px-2 text-sm text-amber" onClick={() => onSecure(it.uid)}>
                {secureAction}
              </button>
            ) : null}
            {extra && onExtra && gear ? (
              <button className="min-h-11 px-2 text-sm text-fg" onClick={() => onExtra(it.uid)}>
                {extra}
              </button>
            ) : null}
            <button className="min-h-11 px-2 text-sm text-muted" onClick={() => onAction(it.uid)}>
              {action}
            </button>
          </li>
        );
      })}
    </ul>
  );
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
      getX?: () => number;
      getY?: () => number;
    };
    __raidTest?: {
      forceExtract: () => void;
      killAll: () => void;
    };
  }
}
