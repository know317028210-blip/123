import { useEffect, useRef, useState } from "react";
import type { PointerEvent } from "react";

const WORLD_W = 1600;
const WORLD_H = 552;
type Landmark = { x: number; y: number; name: string; note: string };
const landmarks: Landmark[] = [
  { x: 370, y: 255, name: "家园小屋", note: "木屋是你的家园核心，后续可升级储物、制作和休息设施。" },
  { x: 760, y: 310, name: "中央菜园", note: "菜园区域已预留：后续可种植、浇水、收获并获得食物资源。" },
  { x: 1110, y: 230, name: "风车工坊", note: "工坊区域已预留：后续可制作装备、加工矿石和升级工具。" },
  { x: 1330, y: 350, name: "池塘", note: "池塘区域已预留：后续可钓鱼、采集水生资源。" },
];

export function HomesteadWorld({ onBack }: { onBack: () => void }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pos = useRef({ x: 720, y: 340 });
  const keys = useRef<Record<string, boolean>>({});
  const stick = useRef({ x: 0, y: 0 });
  const [message, setMessage] = useState("欢迎回家！探索农庄，靠近设施后点击互动。当前地图使用生成的场景美术作为视觉底图。");
  const [near, setNear] = useState("");
  const [sceneReady, setSceneReady] = useState(false);

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      keys.current[e.key.toLowerCase()] = true;
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(e.key)) e.preventDefault();
    };
    const up = (e: KeyboardEvent) => { keys.current[e.key.toLowerCase()] = false; };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    const scene = new Image();
    scene.src = "/assets/generated-homestead.jpg";
    scene.onload = () => setSceneReady(true);
    let raf = 0;
    let last = 0;
    const draw = (t: number) => {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext("2d");
      if (!canvas || !ctx) { raf = requestAnimationFrame(draw); return; }
      const dt = Math.min(32, t - last || 16); last = t;
      let dx = (keys.current.d || keys.current.arrowright ? 1 : 0) - (keys.current.a || keys.current.arrowleft ? 1 : 0) + stick.current.x;
      let dy = (keys.current.s || keys.current.arrowdown ? 1 : 0) - (keys.current.w || keys.current.arrowup ? 1 : 0) + stick.current.y;
      const len = Math.hypot(dx, dy) || 1; dx /= len; dy /= len;
      pos.current.x = Math.max(22, Math.min(WORLD_W - 22, pos.current.x + dx * dt * 0.2));
      pos.current.y = Math.max(30, Math.min(WORLD_H - 30, pos.current.y + dy * dt * 0.2));
      const scale = Math.min(canvas.width / 960, canvas.height / 520);
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.fillStyle = "#203b2a"; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.save();
      ctx.translate(canvas.width / 2 - pos.current.x * scale, canvas.height / 2 - pos.current.y * scale);
      ctx.scale(scale, scale);
      if (scene.complete && scene.naturalWidth) ctx.drawImage(scene, 0, 0, WORLD_W, WORLD_H);
      else { ctx.fillStyle = "#7fbf60"; ctx.fillRect(0, 0, WORLD_W, WORLD_H); }
      // Temporary player marker; environment art itself is generated artwork, not procedural terrain.
      const px = pos.current.x, py = pos.current.y;
      ctx.fillStyle = "rgba(14,30,24,.42)"; ctx.beginPath(); ctx.ellipse(px, py + 15, 13, 5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = "#202b3d"; ctx.fillRect(px - 8, py - 2, 16, 18);
      ctx.fillStyle = "#f0c49b"; ctx.fillRect(px - 7, py - 17, 14, 14);
      ctx.fillStyle = "#4a3026"; ctx.fillRect(px - 8, py - 20, 16, 7); ctx.fillRect(px - 10, py - 15, 4, 8);
      ctx.fillStyle = "#d7bd80"; ctx.fillRect(px - 6, py + 12, 5, 7); ctx.fillRect(px + 2, py + 12, 5, 7);
      ctx.restore();
      let closest: Landmark | undefined; let best = 105;
      for (const point of landmarks) { const d = Math.hypot(point.x - pos.current.x, point.y - pos.current.y); if (d < best) { best = d; closest = point; } }
      const n = closest?.name ?? ""; setNear(old => old === n ? old : n);
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => { cancelAnimationFrame(raf); window.removeEventListener("keydown", down); window.removeEventListener("keyup", up); };
  }, []);

  const joystick = (e: PointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = (e.clientX - (r.left + r.width / 2)) / (r.width / 2);
    const y = (e.clientY - (r.top + r.height / 2)) / (r.height / 2);
    const len = Math.hypot(x, y) || 1;
    stick.current = { x: x / Math.max(1, len), y: y / Math.max(1, len) };
  };
  const interact = () => {
    const point = landmarks.find(p => Math.hypot(p.x - pos.current.x, p.y - pos.current.y) < 120);
    setMessage(point ? point.note : "附近没有可互动设施。靠近木屋、菜园、工坊或池塘再试试。");
  };

  return <div className="min-h-dvh bg-[#142d25] text-white">
    <header className="flex items-center justify-between gap-3 border-b border-white/15 bg-[#193d30] px-4 py-3"><div><div className="text-xs tracking-[.2em] text-[#b8e79c]">SECRET FRONTIER · HOMESTEAD</div><h1 className="text-xl font-bold">🌿 我的家园</h1></div><button onClick={onBack} className="rounded-xl border border-white/20 bg-white/10 px-4 py-2">返回主界面</button></header>
    <div className="mx-auto max-w-5xl p-3"><div className="mb-2 flex flex-wrap items-center justify-between gap-2 text-sm"><span className="rounded-full bg-black/30 px-3 py-1">☀️ 晴朗 · 第 1 天</span><span className="rounded-full bg-black/30 px-3 py-1">📍 {near || "自由探索中"}</span><span className="rounded-full bg-black/30 px-3 py-1">移动：WASD / 方向键</span></div>
      <div className="relative overflow-hidden rounded-2xl border-4 border-[#527d49] bg-[#82ce69] shadow-2xl"><canvas ref={canvasRef} width={960} height={620} className="block h-[min(66vh,620px)] w-full touch-none" onPointerDown={e => { e.currentTarget.setPointerCapture(e.pointerId); joystick(e); }} onPointerMove={e => { if (e.buttons) joystick(e); }} onPointerUp={() => { stick.current = { x: 0, y: 0 }; }} onPointerCancel={() => { stick.current = { x: 0, y: 0 }; }} />
        {!sceneReady && <div className="absolute inset-0 flex items-center justify-center bg-black/50 text-sm">正在加载家园美术素材…</div>}
        <div className="pointer-events-none absolute left-3 top-3 rounded-lg bg-[#173b2e]/90 px-3 py-2 text-xs shadow">✦ 农庄探索区域<br/>木屋 · 菜园 · 工坊 · 池塘</div>
        <div className="absolute bottom-3 left-3 flex h-24 w-24 touch-none items-center justify-center rounded-full border-2 border-white/50 bg-black/25 text-2xl" onPointerDown={e => { e.currentTarget.setPointerCapture(e.pointerId); joystick(e); }} onPointerMove={e => { if (e.buttons) joystick(e); }} onPointerUp={() => { stick.current = { x: 0, y: 0 }; }} onPointerCancel={() => { stick.current = { x: 0, y: 0 }; }}>✥</div>
        <button className="absolute bottom-4 right-4 rounded-full border-2 border-white/60 bg-[#214a37]/95 px-4 py-3 font-bold" onClick={interact}>互动</button>
      </div>
      <div className="mt-3 rounded-xl border border-white/15 bg-[#193d30] p-3 text-sm"><span className="mr-2 text-[#f3d98b]">家园日志</span>{message}<div className="mt-2 grid grid-cols-2 gap-2 text-center text-xs sm:grid-cols-4"><div className="rounded-lg bg-black/15 p-2">🏡 木屋<br/><span className="text-white/60">休息与升级</span></div><div className="rounded-lg bg-black/15 p-2">🌱 菜园<br/><span className="text-white/60">种植与收获</span></div><div className="rounded-lg bg-black/15 p-2">⚒️ 工坊<br/><span className="text-white/60">制作与加工</span></div><div className="rounded-lg bg-black/15 p-2">🎣 池塘<br/><span className="text-white/60">钓鱼与采集</span></div></div></div>
    </div>
  </div>;
}
