import { useEffect, useRef, useState } from "react";
import { Hideout } from "@/components/Hideout";
import { HomesteadWorld } from "@/components/HomesteadWorld";
import { Exchange } from "@/components/Exchange";
import { RaidView } from "@/components/RaidView";
import { ITEMS } from "@/game/content";
import { resumeAudio, setSfxVolume, unlockAudio } from "@/game/audio";
import { beginRaid, finishRaid, freshSave, loadSave, writeSave } from "@/game/save";
import type { Debrief, RaidSetup, Save } from "@/game/types";

type Phase = "hideout" | "raid" | "debrief";

export function GameApp() {
  const [save, setSave] = useState<Save>(freshSave);
  const [ready, setReady] = useState(false);
  const [phase, setPhase] = useState<Phase>("hideout");
  const [hub, setHub] = useState<"raid" | "home" | "market">("raid");
  const [setup, setSetup] = useState<RaidSetup | null>(null);
  const [debrief, setDebrief] = useState<Debrief | null>(null);
  const [toast, setToast] = useState("");
  const saveRef = useRef<Save>(save);
  saveRef.current = save;
  const ended = useRef(false);

  useEffect(() => {
    const loaded = loadSave();
    setSave(loaded);
    setSfxVolume(loaded.sfx);
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) writeSave(save);
  }, [save, ready]);

  useEffect(() => {
    const unlock = () => unlockAudio();
    const vis = () => {
      if (document.visibilityState === "visible") resumeAudio();
    };
    window.addEventListener("pointerdown", unlock);
    window.addEventListener("keydown", unlock);
    document.addEventListener("visibilitychange", vis);
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
      document.removeEventListener("visibilitychange", vis);
    };
  }, []);

  useEffect(() => {
    if (!toast) return;
    const id = window.setTimeout(() => setToast(""), 2200);
    return () => window.clearTimeout(id);
  }, [toast]);

  return (
    <main className="min-h-dvh bg-bg text-fg">
      {phase === "hideout" && hub === "home" ? <HomesteadWorld onBack={() => setHub("raid")} /> : null}
      {phase === "hideout" && hub === "market" ? <Exchange onBack={() => setHub("raid")} /> : null}
      {phase === "hideout" && hub === "raid" ? (
        <><div className="mx-auto flex max-w-5xl gap-2 px-3 pt-3 sm:px-6">
          <button onClick={() => setHub("raid")} className="min-h-12 flex-1 rounded-xl border border-amber/50 bg-amber px-3 font-bold text-bg">⚔️ 进入对局</button>
          <button onClick={() => setHub("home")} className="min-h-12 flex-1 rounded-xl border border-line bg-surface px-3 font-bold text-fg">🌿 家园</button>
          <button onClick={() => setHub("market")} className="min-h-12 flex-1 rounded-xl border border-line bg-surface px-3 font-bold text-fg">🛒 交易所</button>
        </div><Hideout
          save={save}
          setSave={setSave}
          toast={setToast}
          compact
          onDeploy={(mapId, insure) => {
            const result = beginRaid(save, mapId, insure);
            if ("error" in result) {
              setToast(result.error);
              return;
            }
            setSave(result.save);
            setSetup(result.setup);
            setDebrief(null);
            ended.current = false;
            setPhase("raid");
          }}
        /></>
      ) : null}
      {phase === "raid" && setup ? (
        <RaidView
          setup={setup}
          sfxVol={save.sfx}
          onEnd={(result) => {
            if (ended.current) return;
            ended.current = true;
            const out = finishRaid(saveRef.current, setup, result);
            setSave(out.save);
            setDebrief(out.debrief);
            setPhase("debrief");
          }}
        />
      ) : null}
      {phase === "debrief" && debrief ? (
        <DebriefView
          debrief={debrief}
          onBack={() => {
            setPhase("hideout");
            setHub("raid");
            setSetup(null);
          }}
        />
      ) : null}
      {toast ? (
        <div className="fixed bottom-4 left-1/2 z-50 -translate-x-1/2 border border-line bg-surface-2 px-4 py-3 text-sm text-fg">
          {toast}
        </div>
      ) : null}
      {phase === "hideout" && hub === "raid" ? (
        <button
          className="fixed right-3 top-3 z-40 min-h-11 border border-line bg-surface px-3 font-mono text-xs text-muted"
          onClick={() => {
            const next = Math.max(0, (save.sfx > 0.2 ? 0 : 0.7));
            setSfxVolume(next);
            setSave({ ...save, sfx: next });
          }}
        >
          {save.sfx > 0.05 ? "音效 开" : "音效 关"}
        </button>
      ) : null}
    </main>
  );
}

function DebriefView({ debrief, onBack }: { debrief: Debrief; onBack: () => void }) {
  const ok = debrief.outcome === "extract";
  return (
    <div className="mx-auto flex min-h-dvh max-w-xl flex-col justify-center px-4 py-8">
      <div className="border border-line bg-surface p-5">
        <div className={`font-mono text-xs tracking-widest ${ok ? "text-amber" : "text-blood"}`}>
          {debrief.mapName}
        </div>
        <h1 className={`mt-2 text-3xl ${ok ? "text-amber" : "text-blood"}`}>
          {ok ? "已撤离" : debrief.outcome === "mia" ? "失踪" : "阵亡"}
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">{debrief.note}</p>
        <p className="mt-3 font-mono text-sm text-fg">
          击倒 {debrief.kills} · 经验 +{debrief.xp}
          {ok ? ` · 新货估值 ${debrief.lootValue.toLocaleString("zh-CN")} ₽` : ""}
        </p>
        <LootList title={ok ? "带回来的" : "还在身上的"} items={debrief.kept} />
        <LootList title="留在湾里" items={debrief.lost} />
        <LootList title="保险退回" items={debrief.returned} />
        <button className="mt-6 min-h-11 w-full bg-amber text-bg" onClick={onBack}>
          返回藏身处
        </button>
      </div>
    </div>
  );
}

function LootList({ title, items }: { title: string; items: { uid: string; defId: string; count: number }[] }) {
  if (!items.length) return null;
  return (
    <div className="mt-4">
      <h2 className="text-sm text-muted">{title}</h2>
      <ul className="mt-1 text-sm">
        {items.map((it) => {
          const d = ITEMS[it.defId];
          return (
            <li key={`${title}-${it.uid}`} className="border-b border-line py-1">
              {d?.name ?? it.defId}
              {d?.stack ? ` ×${it.count}` : ""}
            </li>
          );
        })}
      </ul>
    </div>
  );
}
