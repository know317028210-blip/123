import { useEffect, useState } from "react";
import harbor from "@/assets/harbor.jpg";
import { ITEMS, MAPS, TRADER, UPGRADES, levelName, levelOf } from "@/game/content";
import { InventoryGrid } from "@/components/InventoryGrid";
import {
  buyPrice,
  caps,
  carryWeight,
  equipItem,
  insuranceCost,
  moveItem,
  sellValue,
  slotsOf,
  unequipItem,
} from "@/game/inventory";
import { buyItem, claimMail, repairCost, repairGear, sellStashItem } from "@/game/save";
import type { Item, Save } from "@/game/types";

type Tab = "brief" | "stash" | "gear" | "trader" | "base" | "farm" | "raid";

const TABS: { id: Tab; label: string }[] = [
  { id: "brief", label: "简报" },
  { id: "stash", label: "仓库" },
  { id: "gear", label: "装备" },
  { id: "trader", label: "交易所" },
  { id: "base", label: "营地建设" },
  { id: "farm", label: "家园" },
  { id: "raid", label: "出击" },
];

type Props = {
  save: Save;
  setSave: (save: Save) => void;
  onDeploy: (mapId: string, insure: boolean) => void;
  toast: (msg: string) => void;
  compact?: boolean;
};

export function Hideout({ save, setSave, onDeploy, toast, compact = false }: Props) {
  const [tab, setTab] = useState<Tab>(compact ? "raid" : "brief");
  useEffect(() => { if (compact) setTab("raid"); }, [compact]);
  const [clock, setClock] = useState(Date.now());
  useEffect(() => { const timer = window.setInterval(() => setClock(Date.now()), 5000); return () => window.clearInterval(timer); }, []);
  const [insure, setInsure] = useState(false);
  const level = levelOf(save.xp);
  const cap = caps(save);
  const weight = carryWeight(save.equipped, save.pack, save.secure);
  const rate = save.raids ? Math.round((save.extracts / save.raids) * 100) : 0;
  const premium = insuranceCost(save);

  function commit(mut: (draft: Save) => string | null) {
    const draft = structuredClone(save);
    const err = mut(draft);
    if (err) toast(err);
    else setSave(draft);
  }

  return (
    <div className="mx-auto min-h-dvh max-w-5xl px-3 py-4 sm:px-6">
      <header className="overflow-hidden border border-line bg-surface">
        <div className="relative h-36 sm:h-48">
          <img src={harbor} alt="" className="h-full w-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-transparent" />
          <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between gap-3">
            <div>
              <div className="font-mono text-xs tracking-widest text-amber">THE ENCHANTED FRONTIER</div>
              <h1 className="text-3xl leading-none">秘境边境</h1>
            </div>
            <div className="text-right">
              <div className="font-mono text-lg text-amber">{save.rubles.toLocaleString("zh-CN")} ₽</div>
              <div className="text-xs text-muted">
                {levelName(level)} · {level} 级
              </div>
            </div>
          </div>
        </div>
      </header>

      {!compact ? <nav className="mt-3 flex gap-1 overflow-x-auto border-b border-line" aria-label="藏身处">
        {TABS.map((t) => (
          <button
            key={t.id}
            className={`min-h-11 shrink-0 px-3 text-sm ${tab === t.id ? "border-b-2 border-amber text-amber" : "text-muted"}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </nav> : null}

      <div className="mt-4">
        {!compact && tab === "brief" ? (
          <section className="grid gap-4 sm:grid-cols-5">
            <div className="border border-line bg-surface p-4 sm:col-span-3">
              <h2 className="text-lg">边境委托</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">{save.log}</p>
              <ol className="mt-4 space-y-2 text-sm">
                <li>1. 仓库里的东西是安全的。只有装备、背包和安全箱会跟你进战区。</li>
                <li>2. 搜容器，躲开或打倒巡逻者。站在撤离圈里直到倒计时结束。</li>
                <li>3. 倒地或超时，背包和没上保险的装备都留在湾里。安全箱例外。</li>
              </ol>
              {save.mail.length ? (
                <button
                  className="mt-4 min-h-11 bg-amber px-4 text-bg"
                  onClick={() => commit((d) => claimMail(d))}
                >
                  领取保险退回（{save.mail.length}）
                </button>
              ) : null}
              <button className="mt-4 block min-h-11 px-1 text-amber" onClick={() => setTab("raid")}>
                前往秘境
              </button>
            </div>
            <dl className="grid grid-cols-2 gap-2 sm:col-span-2">
              <Stat k="出击" v={String(save.raids)} />
              <Stat k="撤离" v={String(save.extracts)} />
              <Stat k="存活" v={`${rate}%`} />
              <Stat k="击倒" v={String(save.kills)} />
            </dl>
          </section>
        ) : null}

        {!compact && tab === "stash" ? (
          <section className="border border-line bg-surface p-4">
            <h2 className="text-lg">仓库</h2>
            <p className="mt-1 font-mono text-xs text-muted">
              {slotsOf(save.stash)} / {cap.stash} 格 · 放在这里的东西不会进战区
            </p>
            <InventoryGrid items={save.stash} title="仓库网格" cols={10} rows={8} />
            <ItemList
              items={save.stash}
              empty="仓库空了。活着带东西出来，或者找商人。"
              actions={(it) => {
                const d = ITEMS[it.defId];
                const buttons = [
                  {
                    label: "出售",
                    run: () => commit((draft) => sellStashItem(draft, it.uid)),
                  },
                  {
                    label: "装进背包",
                    run: () =>
                      commit((draft) => (moveItem(draft.stash, draft.pack, it.uid, cap.pack) ? null : "背包满了")),
                  },
                  {
                    label: "安全箱",
                    run: () =>
                      commit((draft) =>
                        moveItem(draft.stash, draft.secure, it.uid, cap.secure) ? null : "安全箱满了",
                      ),
                  },
                ];
                if (d && (d.cat === "weapon" || d.cat === "armor" || d.cat === "helmet")) {
                  buttons.unshift({
                    label: "装备",
                    run: () => commit((draft) => equipItem(draft, it.uid)),
                  });
                }
                return buttons;
              }}
            />
          </section>
        ) : null}

        {!compact && tab === "gear" ? (
          <section className="grid gap-4 lg:grid-cols-2">
            <div className="border border-line bg-surface p-4">
              <h2 className="text-lg">身上</h2>
              <p className="mt-1 font-mono text-xs text-muted">
                负重 {weight.toFixed(1)} / {cap.weight} kg
                {weight > cap.weight ? " · 超重会跑不动" : ""}
              </p>
              <div className="mt-3 space-y-3">
                <GearSlot
                  title="武器"
                  item={save.equipped.weapon}
                  onOff={() => commit((d) => unequipItem(d, "weapon", "stash"))}
                />
                <GearSlot
                  title="护甲"
                  item={save.equipped.armor}
                  onOff={() => commit((d) => unequipItem(d, "armor", "stash"))}
                />
                <GearSlot
                  title="头盔"
                  item={save.equipped.helmet}
                  onOff={() => commit((d) => unequipItem(d, "helmet", "stash"))}
                />
              </div>
              <button
                className="mt-4 min-h-11 border border-line px-3 text-sm disabled:opacity-40"
                disabled={save.hideout.bench < 1 || repairCost(save) <= 0}
                onClick={() =>
                  commit((d) => {
                    const err = repairGear(d);
                    return err;
                  })
                }
              >
                {save.hideout.bench < 1
                  ? "保养需要工作台"
                  : repairCost(save) > 0
                    ? `保养装备 · ${repairCost(save).toLocaleString("zh-CN")} ₽`
                    : "装备状况良好"}
              </button>
            </div>
            <div className="border border-line bg-surface p-4">
              <h2 className="text-lg">背包与安全箱</h2>
              <p className="mt-1 text-sm text-muted">这两格会带进战区。安全箱里的东西，死了也还在。</p>
              <h3 className="mt-3 text-sm text-muted">
                背包 {slotsOf(save.pack)}/{cap.pack}
              </h3>
              <ItemList
                items={save.pack}
                empty="背包是空的。至少带上弹药和绷带。"
                actions={(it) => [
                  {
                    label: "放回仓库",
                    run: () =>
                      commit((d) => (moveItem(d.pack, d.stash, it.uid, cap.stash) ? null : "仓库满了")),
                  },
                  {
                    label: "安全箱",
                    run: () =>
                      commit((d) => (moveItem(d.pack, d.secure, it.uid, cap.secure) ? null : "安全箱满了")),
                  },
                ]}
              />
              <h3 className="mt-4 text-sm text-amber">
                安全箱 {slotsOf(save.secure)}/{cap.secure}
              </h3>
              <ItemList
                items={save.secure}
                empty="还空着。"
                actions={(it) => [
                  {
                    label: "放回仓库",
                    run: () =>
                      commit((d) => (moveItem(d.secure, d.stash, it.uid, cap.stash) ? null : "仓库满了")),
                  },
                ]}
              />
            </div>
          </section>
        ) : null}

        {!compact && tab === "trader" ? (
          <section className="border border-line bg-surface p-4">
            <h2 className="text-lg">边境交易所</h2>
            <p className="mt-1 text-sm text-muted">
              战利品可在仓库出售，交易所用于采购补给。符文工坊会降低采购成本。
              {save.hideout.bench >= 2 ? " 当前八折。" : save.hideout.bench >= 1 ? " 当前九折。" : ""}
            </p>
            <ul className="mt-3 divide-y divide-line">
              {TRADER.filter((row) => row.level <= level).map((row) => {
                const d = ITEMS[row.id];
                if (!d?.buy) return null;
                const price = buyPrice(save, row.id);
                return (
                  <li key={row.id} className="flex flex-wrap items-center gap-2 py-3">
                    <div className="min-w-0 flex-1">
                      <div className={d.rarity === "rare" || d.rarity === "legendary" ? "text-amber" : "text-fg"}>
                        {d.name}
                        {d.buyCount && d.stack ? ` ×${d.buyCount}` : ""}
                      </div>
                      <div className="text-xs text-muted">{d.blurb}</div>
                    </div>
                    <div className="font-mono text-sm text-amber">{price.toLocaleString("zh-CN")} ₽</div>
                    <button className="min-h-11 bg-surface-2 px-3 text-sm" onClick={() => commit((draft) => buyItem(draft, row.id))}>
                      购买
                    </button>
                  </li>
                );
              })}
            </ul>
            {level < 3 ? (
              <p className="mt-3 text-xs text-muted">再撤离几次，商人会拿出更好的枪。当前经验 {save.xp}。</p>
            ) : null}
          </section>
        ) : null}

        {!compact && tab === "base" ? (
          <section className="grid gap-3 sm:grid-cols-2">
            {UPGRADES.map((u) => {
              const have = save.hideout[u.key];
              const next = have + 1 === u.level;
              const done = have >= u.level;
              const locked = u.needPower && save.hideout.power < 1;
              return (
                <article key={`${u.key}-${u.level}`} className="border border-line bg-surface p-4">
                  <h2 className="text-lg">{u.name}</h2>
                  <p className="mt-1 text-sm text-muted">{u.desc}</p>
                  <div className="mt-3 flex items-center justify-between gap-2">
                    <span className="font-mono text-sm text-amber">{u.cost.toLocaleString("zh-CN")} ₽</span>
                    <button
                      className="min-h-11 bg-amber px-3 text-bg disabled:opacity-40"
                      disabled={!next || locked || save.rubles < u.cost || done}
                      onClick={() =>
                        commit((d) => {
                          if (d.rubles < u.cost) return "金币不够";
                          if (u.needPower && d.hideout.power < 1) return "需要发电机";
                          if (d.hideout[u.key] + 1 !== u.level) return "还没排到这项";
                          d.rubles -= u.cost;
                          d.hideout[u.key] = u.level;
                          d.log = `${u.name} 建好了。湾里的灯似乎稳了一点。`;
                          return null;
                        })
                      }
                    >
                      {done ? "已建成" : locked ? "需要发电机" : next ? "建造" : "未解锁"}
                    </button>
                  </div>
                </article>
              );
            })}
          </section>
        ) : null}

        {!compact && tab === "farm" ? (
          <section className="space-y-4">
            <div className="border border-line bg-surface p-4">
              <div className="font-mono text-xs tracking-widest text-amber">HOMESTEAD · 边境家园</div>
              <h2 className="mt-1 text-2xl">溪畔苗圃与牧场</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted">把搜撤带回来的东西真正用起来。种子种进苗圃，空水囊可在地图溪流边装水；作物成熟后收获月光草出售。捕获林兔可以安置到牧场，之后定期产出毛皮。</p>
              <div className="mt-3 flex flex-wrap gap-2 text-xs text-muted">
                <span className="border border-line px-2 py-1">种子：{save.stash.filter(i => i.defId === "moonseed").reduce((n,i)=>n+i.count,0)}</span>
                <span className="border border-line px-2 py-1">清水：{save.stash.filter(i => i.defId === "water_flask").reduce((n,i)=>n+i.count,0)}</span>
                <span className="border border-line px-2 py-1">牧场动物：{save.farm.pasture}</span>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-3">
              {save.farm.plots.map((plot, idx) => {
                const ready = !!plot.crop && !!plot.watered && plot.plantedAt != null && clock - plot.plantedAt >= 120000;
                const growing = !!plot.crop && !ready;
                const seeds = save.stash.find(i => i.defId === "moonseed");
                const water = save.stash.find(i => i.defId === "water_flask");
                return <article key={idx} className="border border-line bg-surface p-4">
                  <div className="text-xs text-muted">苗圃地块 {idx + 1}</div>
                  <div className="my-3 flex h-24 items-center justify-center border border-line bg-[#273526] text-4xl">{ready ? "🌿" : growing ? "🌱" : "🟫"}</div>
                  <h3 className="text-lg">{!plot.crop ? "空闲土地" : ready ? "月光草成熟" : plot.watered ? "月光草生长中" : "等待浇水"}</h3>
                  <p className="mt-1 min-h-10 text-xs text-muted">{!plot.crop ? "消耗一份月光草种子开始种植。" : ready ? "收获后可出售，也可继续探索。" : plot.watered ? "约两分钟后成熟。" : "使用一份溪水为作物浇灌。"}</p>
                  {!plot.crop ? <button className="mt-3 min-h-11 w-full bg-amber px-3 text-bg disabled:opacity-40" disabled={!seeds} onClick={() => commit(d => { const seed=d.stash.find(i=>i.defId==="moonseed"); if(!seed) return "需要月光草种子"; seed.count--; if(seed.count<=0) d.stash=d.stash.filter(i=>i.uid!==seed.uid); d.farm.plots[idx]={crop:"moonherb",plantedAt:Date.now(),watered:false}; return null; })}>种下种子</button> : !plot.watered ? <button className="mt-3 min-h-11 w-full bg-amber px-3 text-bg disabled:opacity-40" disabled={!water} onClick={() => commit(d => { const w=d.stash.find(i=>i.defId==="water_flask"); if(!w) return "需要溪水水囊；出击时在溪流边装水"; w.count--; if(w.count<=0) d.stash=d.stash.filter(i=>i.uid!==w.uid); d.farm.plots[idx].watered=true; return null; })}>浇水</button> : ready ? <button className="mt-3 min-h-11 w-full bg-amber px-3 text-bg" onClick={() => commit(d => { d.stash.push({uid:`harvest-${Date.now()}-${idx}`,defId:"moonherb",count:1}); d.farm.plots[idx]={crop:null,plantedAt:null,watered:false}; d.log="收获了月光草。可以留在仓库，或在交易所出售。"; return null; })}>收获月光草</button> : <button className="mt-3 min-h-11 w-full border border-line px-3 text-muted" onClick={() => toast("作物仍在生长，约两分钟后成熟")}>查看生长</button>}
                </article>;
              })}
            </div>
            <div className="border border-line bg-surface p-4">
              <div className="flex flex-wrap items-center justify-between gap-3"><div><h2 className="text-lg">林兔牧场</h2><p className="mt-1 text-sm text-muted">每只已安置的林兔会在完成一次出击后产出一张毛皮。</p></div><div className="text-2xl">🐇 ×{save.farm.pasture}</div></div>
              <button className="mt-3 min-h-11 bg-amber px-4 text-bg disabled:opacity-40" disabled={!save.stash.some(i=>i.defId==="captured_hare") || save.farm.pasture>=5} onClick={() => commit(d => { const hare=d.stash.find(i=>i.defId==="captured_hare"); if(!hare) return "先在战区找到并带回林兔"; hare.count--; if(hare.count<=0) d.stash=d.stash.filter(i=>i.uid!==hare.uid); d.farm.pasture++; return null; })}>安置捕获的林兔</button>
            </div>
          </section>
        ) : null}

        {tab === "raid" ? (
          <section>
            <div className="mb-3 flex flex-wrap items-center justify-between gap-3 border border-line bg-surface p-4">
              <label className="flex min-h-11 items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={insure}
                  onChange={(e) => setInsure(e.target.checked)}
                  className="size-4 accent-amber"
                />
                为枪和护甲上保险 · {premium.toLocaleString("zh-CN")} ₽
              </label>
              <p className="text-xs text-muted">
                倒地后退回邮箱，并掉一些耐久。撤离则保险作废。负重 {weight.toFixed(1)}/{cap.weight} kg
              </p>
            </div>
            <div className="grid gap-3 lg:grid-cols-3">
              {MAPS.map((map) => (
                <article key={map.id} className="flex flex-col border border-line bg-surface p-4">
                  <div className="font-mono text-xs text-amber">{map.area}</div>
                  <h2 className="mt-1 text-xl">{map.name}</h2>
                  <p className="mt-2 flex-1 text-sm text-muted">{map.brief}</p>
                  <p className="mt-3 font-mono text-xs text-muted">
                    难度 {"●".repeat(map.difficulty)}
                    {"○".repeat(3 - map.difficulty)} · {Math.round(map.time / 60)} 分钟 · 巡逻 {map.scavs.length}
                  </p>
                  <button
                    className="mt-4 min-h-11 bg-amber px-3 text-bg"
                    onClick={() => onDeploy(map.id, insure && premium > 0)}
                  >
                    部署 · {map.name}
                  </button>
                </article>
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="border border-line bg-surface p-3">
      <dt className="text-xs text-muted">{k}</dt>
      <dd className="font-mono text-2xl text-fg">{v}</dd>
    </div>
  );
}

function GearSlot({ item, title, onOff }: { item: Item | null; title: string; onOff: () => void }) {
  const d = item ? ITEMS[item.defId] : null;
  const dur = d?.dur && item?.dur != null ? Math.round((item.dur / d.dur) * 100) : null;
  return (
    <div className="border border-line bg-surface-2 p-3">
      <div className="text-xs text-muted">{title}</div>
      <div className="mt-1 flex items-center justify-between gap-2">
        <div>
          <div>{d?.name ?? "空"}</div>
          {dur != null ? (
            <div className="mt-1 h-1 w-28 bg-bg">
              <div className="h-full bg-amber" style={{ width: `${dur}%` }} />
            </div>
          ) : null}
        </div>
        {item ? (
          <button className="min-h-11 px-2 text-sm text-muted" onClick={onOff}>
            卸下
          </button>
        ) : null}
      </div>
    </div>
  );
}

function ItemList({
  items,
  empty,
  actions,
}: {
  items: Item[];
  empty: string;
  actions: (it: Item) => { label: string; run: () => void }[];
}) {
  if (!items.length) return <p className="mt-3 text-sm text-muted">{empty}</p>;
  return (
    <ul className="mt-2">
      {items.map((it) => {
        const d = ITEMS[it.defId];
        if (!d) return null;
        return (
          <li key={it.uid} className="flex flex-wrap items-center gap-2 border-b border-line py-2">
            <div className="min-w-0 flex-1">
              <div className={d.rarity === "rare" || d.rarity === "legendary" ? "text-amber" : "text-fg"}>
                {d.name}
                {d.stack ? ` ×${it.count}` : ""}
              </div>
              <div className="text-xs text-muted">{d.blurb}</div>
            </div>
            <div className="font-mono text-xs text-muted">{sellValue(it).toLocaleString("zh-CN")} ₽</div>
            {actions(it).map((a) => (
              <button key={a.label} className="min-h-11 bg-surface-2 px-2 text-sm" onClick={a.run}>
                {a.label}
              </button>
            ))}
          </li>
        );
      })}
    </ul>
  );
}
