let ctx: AudioContext | null = null;
let master: GainNode | null = null;
let sfxBus: GainNode | null = null;
let volume = 0.7;

function ensure() {
  if (ctx) return ctx;
  const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  ctx = new AC({ latencyHint: "interactive" });
  master = ctx.createGain();
  sfxBus = ctx.createGain();
  master.gain.value = volume * volume;
  sfxBus.connect(master);
  master.connect(ctx.destination);
  return ctx;
}

export function unlockAudio() {
  const ac = ensure();
  if (ac.state === "suspended") void ac.resume();
}

export function resumeAudio() {
  if (ctx && ctx.state === "suspended") void ctx.resume();
}

export function setSfxVolume(v: number) {
  volume = Math.max(0, Math.min(1, v));
  if (master && ctx) master.gain.setTargetAtTime(volume * volume, ctx.currentTime, 0.02);
}

function tone(
  freq: number,
  dur: number,
  type: OscillatorType,
  gain: number,
  slide = 0,
  noise = 0,
) {
  if (!ctx || !sfxBus || volume <= 0.01) return;
  const t = ctx.currentTime;
  const g = ctx.createGain();
  g.gain.setValueAtTime(gain, t);
  g.gain.exponentialRampToValueAtTime(0.001, t + dur);
  g.connect(sfxBus);
  if (noise > 0) {
    const n = noiseBuffer(dur);
    if (n) {
      const src = ctx.createBufferSource();
      src.buffer = n;
      const ng = ctx.createGain();
      ng.gain.value = noise;
      src.connect(ng);
      ng.connect(g);
      src.start(t);
      src.stop(t + dur);
    }
  }
  if (freq > 0) {
    const o = ctx.createOscillator();
    o.type = type;
    o.frequency.setValueAtTime(freq, t);
    if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
    o.connect(g);
    o.start(t);
    o.stop(t + dur + 0.02);
  }
}

function noiseBuffer(dur: number) {
  if (!ctx) return null;
  const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
  const buf = ctx.createBuffer(1, len, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
  return buf;
}

export type SfxName = "shot" | "shotgun" | "hit" | "hurt" | "dry" | "reload" | "search" | "extract" | "death" | "ui" | "zip";

export function sfx(name: SfxName) {
  unlockAudio();
  const jitter = 0.94 + Math.random() * 0.12;
  switch (name) {
    case "shot":
      tone(210 * jitter, 0.09, "square", 0.08, -120, 0.35);
      break;
    case "shotgun":
      tone(120, 0.16, "sawtooth", 0.1, -80, 0.7);
      break;
    case "hit":
      tone(340 * jitter, 0.06, "triangle", 0.05, -180, 0.15);
      break;
    case "hurt":
      tone(90, 0.18, "sawtooth", 0.08, -40, 0.2);
      break;
    case "dry":
      tone(640, 0.04, "square", 0.04, 0, 0);
      break;
    case "reload":
      tone(180, 0.07, "square", 0.05, 40, 0.05);
      tone(90, 0.09, "triangle", 0.04, 0, 0);
      break;
    case "search":
      tone(520, 0.05, "triangle", 0.04, 80, 0);
      break;
    case "extract":
      tone(440, 0.12, "sine", 0.06, 0, 0);
      tone(660, 0.16, "sine", 0.05, 0, 0);
      break;
    case "death":
      tone(70, 0.4, "sawtooth", 0.09, -30, 0.3);
      break;
    case "zip":
      tone(880, 0.08, "sine", 0.04, 200, 0);
      break;
    default:
      tone(600, 0.04, "square", 0.03, 0, 0);
  }
}
