import { ITEMS, TILE, mapById, rollContainer } from "./content";
import { carryWeight, moveItem, slotsOf } from "./inventory";
import type { ContainerKind, GameMap, Gear, Item, RaidEnd, RaidSetup } from "./types";

export type SfxName = "shot" | "shotgun" | "hit" | "hurt" | "dry" | "reload" | "search" | "extract" | "death" | "ui" | "zip";

export type Player = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  aim: number;
  hp: number;
  mag: number;
  fireCd: number;
  reload: number;
  use: number;
  using: string | null;
  buff: number;
  extract: number;
  weapon: Item | null;
  armor: Item | null;
  helmet: Item | null;
  pack: Item[];
  secure: Item[];
  hit: number;
};

export type Scav = {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  aim: number;
  hp: number;
  maxHp: number;
  alive: boolean;
  cd: number;
  react: number;
  seen: boolean;
  wander: number;
  wanderT: number;
  flash: number;
};

export type LootBox = {
  id: string;
  x: number;
  y: number;
  kind: ContainerKind;
  items: Item[];
  open: boolean;
};

export type Bullet = {
  alive: boolean;
  x: number;
  y: number;
  px: number;
  py: number;
  vx: number;
  vy: number;
  life: number;
  dmg: number;
  team: 0 | 1;
};

export type Particle = {
  alive: boolean;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  r: number;
  color: string;
};

export type FloatText = {
  x: number;
  y: number;
  text: string;
  life: number;
  color: string;
};

export type InputState = {
  mx: number;
  my: number;
  fire: boolean;
  aimX: number;
  aimY: number;
  aimOk: boolean;
  interact: boolean;
  reload: boolean;
  heal: boolean;
};

export type RaidState = {
  map: GameMap;
  player: Player;
  scavs: Scav[];
  boxes: LootBox[];
  bullets: Bullet[];
  particles: Particle[];
  texts: FloatText[];
  explored: Uint8Array;
  visible: Uint8Array;
  time: number;
  kills: number;
  camX: number;
  camY: number;
  shake: number;
  recoil: number;
  hitStop: number;
  flash: number;
  gateOpen: boolean;
  paused: boolean;
  lootId: string | null;
  prompt: string;
  msg: string;
  msgT: number;
  outcome: RaidEnd["outcome"] | null;
  endTimer: number;
  reported: boolean;
  events: SfxName[];
  spreadMul: number;
  healMul: number;
  packCap: number;
  secureCap: number;
  weightLimit: number;
  insure: boolean;
  zoom: number;
  viewW: number;
  viewH: number;
};

const R = 13;
const VIEW = 292;

export function createRaid(setup: RaidSetup): RaidState {
  const map = mapById(setup.mapId);
  const weapon = setup.gear.weapon ? { ...setup.gear.weapon } : null;
  const player: Player = {
    x: map.spawn.x,
    y: map.spawn.y,
    vx: 0,
    vy: 0,
    aim: -Math.PI / 2,
    hp: 100,
    mag: weapon?.mag ?? 0,
    fireCd: 0,
    reload: 0,
    use: 0,
    using: null,
    buff: 0,
    extract: 0,
    weapon,
    armor: setup.gear.armor ? { ...setup.gear.armor } : null,
    helmet: setup.gear.helmet ? { ...setup.gear.helmet } : null,
    pack: setup.pack.map((it) => ({ ...it })),
    secure: setup.secure.map((it) => ({ ...it })),
    hit: 0,
  };
  const state: RaidState = {
    map,
    player,
    scavs: map.scavs.map((s, i) => ({
      id: i + 1,
      x: s.x,
      y: s.y,
      vx: 0,
      vy: 0,
      aim: Math.random() * Math.PI * 2,
      hp: map.scav.hp,
      maxHp: map.scav.hp,
      alive: true,
      cd: 0.4 + Math.random() * 0.5,
      react: 0.3,
      seen: false,
      wander: Math.random() * Math.PI * 2,
      wanderT: 0.4,
      flash: 0,
    })),
    boxes: map.containers.map((c) => ({
      id: c.id,
      x: c.x,
      y: c.y,
      kind: c.kind,
      items: rollContainer(c.kind, map),
      open: false,
    })),
    bullets: [],
    particles: [],
    texts: [],
    explored: new Uint8Array(map.w * map.h),
    visible: new Uint8Array(map.w * map.h),
    time: map.time,
    kills: 0,
    camX: player.x,
    camY: player.y,
    shake: 0,
    recoil: 0,
    hitStop: 0,
    flash: 0,
    gateOpen: false,
    paused: false,
    lootId: null,
    prompt: "",
    msg: `${map.name} · 找到撤离点，活着出去`,
    msgT: 3.2,
    outcome: null,
    endTimer: 0,
    reported: false,
    events: [],
    spreadMul: setup.spreadMul,
    healMul: setup.healMul,
    packCap: setup.packCap,
    secureCap: setup.secureCap,
    weightLimit: setup.weightLimit,
    insure: setup.insure,
    zoom: 1,
    viewW: 800,
    viewH: 600,
  };
  reveal(state);
  return state;
}

function wallAt(map: GameMap, x: number, y: number) {
  const tx = Math.floor(x / TILE);
  const ty = Math.floor(y / TILE);
  if (tx < 0 || ty < 0 || tx >= map.w || ty >= map.h) return true;
  return map.tiles[ty * map.w + tx] === 1;
}

function blocked(map: GameMap, x: number, y: number, rad: number) {
  const minX = Math.floor((x - rad) / TILE);
  const maxX = Math.floor((x + rad) / TILE);
  const minY = Math.floor((y - rad) / TILE);
  const maxY = Math.floor((y + rad) / TILE);
  for (let ty = minY; ty <= maxY; ty++) {
    for (let tx = minX; tx <= maxX; tx++) {
      const solid = tx < 0 || ty < 0 || tx >= map.w || ty >= map.h || map.tiles[ty * map.w + tx] === 1;
      if (!solid) continue;
      const left = tx * TILE;
      const top = ty * TILE;
      const nx = Math.max(left, Math.min(x, left + TILE));
      const ny = Math.max(top, Math.min(y, top + TILE));
      const dx = x - nx;
      const dy = y - ny;
      if (dx * dx + dy * dy < rad * rad) return true;
    }
  }
  return false;
}

function moveBody(map: GameMap, e: { x: number; y: number }, dx: number, dy: number, rad: number) {
  const ox = e.x;
  const oy = e.y;
  if (!blocked(map, e.x + dx, e.y, rad)) e.x += dx;
  if (!blocked(map, e.x, e.y + dy, rad)) e.y += dy;
  return e.x !== ox || e.y !== oy;
}

function los(map: GameMap, x0: number, y0: number, x1: number, y1: number) {
  const dist = Math.hypot(x1 - x0, y1 - y0);
  const steps = Math.max(1, Math.ceil(dist / (TILE * 0.4)));
  for (let i = 1; i < steps; i++) {
    const t = i / steps;
    if (wallAt(map, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)) return false;
  }
  return true;
}

function reveal(state: RaidState) {
  const { map, player, visible, explored } = state;
  visible.fill(0);
  const r = Math.ceil(VIEW / TILE);
  const tx = Math.floor(player.x / TILE);
  const ty = Math.floor(player.y / TILE);
  for (let y = ty - r; y <= ty + r; y++) {
    for (let x = tx - r; x <= tx + r; x++) {
      if (x < 0 || y < 0 || x >= map.w || y >= map.h) continue;
      const cx = (x + 0.5) * TILE;
      const cy = (y + 0.5) * TILE;
      if (Math.hypot(cx - player.x, cy - player.y) > VIEW) continue;
      if (!los(map, player.x, player.y, cx, cy)) continue;
      const k = y * map.w + x;
      visible[k] = 1;
      explored[k] = 1;
    }
  }
}

function reduction(p: Player) {
  const mit = (it: Item | null) => {
    if (!it || it.dur == null || it.dur <= 0) return 0;
    return ITEMS[it.defId]?.armor ?? 0;
  };
  const a = mit(p.armor);
  const h = mit(p.helmet);
  return 1 - (1 - a) * (1 - h);
}

function spark(state: RaidState, x: number, y: number, color: string, n: number, speed: number) {
  for (let i = 0; i < n; i++) {
    const a = Math.random() * Math.PI * 2;
    const v = speed * (0.3 + Math.random());
    const p = state.particles.find((q) => !q.alive);
    const life = 0.18 + Math.random() * 0.28;
    const bit: Particle = p ?? {
      alive: true,
      x,
      y,
      vx: 0,
      vy: 0,
      life,
      max: life,
      r: 2,
      color,
    };
    bit.alive = true;
    bit.x = x;
    bit.y = y;
    bit.vx = Math.cos(a) * v;
    bit.vy = Math.sin(a) * v;
    bit.life = life;
    bit.max = life;
    bit.r = 1.4 + Math.random() * 2.2;
    bit.color = color;
    if (!p) {
      if (state.particles.length < 140) state.particles.push(bit);
    }
  }
}

function floatText(state: RaidState, x: number, y: number, text: string, color: string) {
  state.texts.push({ x, y, text, life: 0.7, color });
  if (state.texts.length > 24) state.texts.shift();
}

function spawnBullet(state: RaidState, x: number, y: number, aim: number, dmg: number, team: 0 | 1, range: number) {
  const speed = team === 0 ? 720 : 460;
  let b = state.bullets.find((q) => !q.alive);
  if (!b) {
    if (state.bullets.length > 90) return;
    b = { alive: true, x, y, px: x, py: y, vx: 0, vy: 0, life: 1, dmg, team };
    state.bullets.push(b);
  }
  b.alive = true;
  b.x = x;
  b.y = y;
  b.px = x;
  b.py = y;
  b.vx = Math.cos(aim) * speed;
  b.vy = Math.sin(aim) * speed;
  b.life = range / speed;
  b.dmg = dmg;
  b.team = team;
}

function weaponDef(p: Player) {
  if (!p.weapon) return null;
  const d = ITEMS[p.weapon.defId];
  return d?.cat === "weapon" ? d : null;
}

function ammoCount(p: Player, id: string) {
  return [...p.pack, ...p.secure].filter((i) => i.defId === id).reduce((n, i) => n + i.count, 0);
}

function takeAmmo(p: Player, id: string, n: number) {
  let need = n;
  for (const list of [p.pack, p.secure]) {
    for (let i = 0; i < list.length && need > 0; i++) {
      const it = list[i]!;
      if (it.defId !== id) continue;
      const take = Math.min(it.count, need);
      it.count -= take;
      need -= take;
      if (it.count <= 0) {
        list.splice(i, 1);
        i--;
      }
    }
  }
  return n - need;
}

function startReload(state: RaidState, p: Player) {
  const w = weaponDef(p);
  if (!w?.ammo || !w.mag || p.reload > 0 || p.use > 0) return;
  const need = w.mag - p.mag;
  if (need <= 0) return;
  if (ammoCount(p, w.ammo) <= 0) {
    state.events.push("dry");
    state.msg = "没有备用弹药";
    state.msgT = 0.8;
    return;
  }
  p.reload = (w.reload ?? 1.6) * (p.weapon?.dur != null && p.weapon.dur < 25 ? 1.25 : 1);
  state.events.push("reload");
}

function tryFire(state: RaidState, p: Player) {
  const w = weaponDef(p);
  if (!w) return;
  if (p.fireCd > 0 || p.reload > 0 || p.use > 0) return;
  if (p.weapon?.dur != null && p.weapon.dur <= 0) {
    state.events.push("dry");
    state.msg = "枪械故障，回藏身处保养";
    state.msgT = 0.9;
    return;
  }
  if (p.mag <= 0) {
    startReload(state, p);
    return;
  }
  p.mag -= 1;
  if (p.weapon?.dur != null) p.weapon.dur = Math.max(0, p.weapon.dur - 0.28);
  const pellets = w.pellets ?? 1;
  const moving = Math.hypot(p.vx, p.vy) > 24;
  const spread = (w.spread ?? 0.05) * state.spreadMul * (moving ? 1.9 : 1);
  const ox = p.x + Math.cos(p.aim) * 18;
  const oy = p.y + Math.sin(p.aim) * 18;
  for (let i = 0; i < pellets; i++) {
    const a = p.aim + (Math.random() - 0.5) * spread * 2;
    spawnBullet(state, ox, oy, a, w.dmg ?? 10, 0, w.range ?? 480);
  }
  p.fireCd = 60 / (w.rpm ?? 400);
  state.recoil = 1;
  state.shake = Math.min(7, state.shake + (pellets > 1 ? 3.4 : 1.5));
  spark(state, ox, oy, "#e0a53a", pellets > 1 ? 8 : 3, 90);
  state.events.push(pellets > 1 ? "shotgun" : "shot");
}

function killScav(state: RaidState, s: Scav) {
  s.alive = false;
  s.hp = 0;
  state.kills += 1;
  state.hitStop = 0.04;
  state.boxes.push({
    id: `body-${s.id}-${state.kills}`,
    x: s.x,
    y: s.y,
    kind: "body",
    items: rollContainer("body", state.map),
    open: false,
  });
  spark(state, s.x, s.y, "#c4452d", 12, 120);
  floatText(state, s.x, s.y - 16, "击倒", "#e0a53a");
  state.events.push("hit");
}

function damageScav(state: RaidState, s: Scav, dmg: number) {
  s.hp -= dmg;
  s.flash = 0.08;
  s.seen = true;
  s.react = 0;
  spark(state, s.x, s.y, "#e7e4d8", 4, 70);
  floatText(state, s.x, s.y - 10, String(Math.round(dmg)), "#e7e4d8");
  if (s.hp <= 0) killScav(state, s);
  else state.events.push("hit");
}

function hurtPlayer(state: RaidState, dmg: number) {
  const p = state.player;
  const dealt = Math.max(1, dmg * (1 - reduction(p)));
  p.hp -= dealt;
  p.hit = 0.14;
  for (const part of [p.armor, p.helmet]) {
    if (part?.dur != null) part.dur = Math.max(0, part.dur - dmg * 0.5);
  }
  state.flash = 0.2;
  state.shake = Math.min(9, state.shake + 3.2);
  floatText(state, p.x, p.y - 18, String(Math.round(dealt)), "#c4452d");
  state.events.push("hurt");
  if (p.hp <= 0) {
    p.hp = 0;
    state.outcome = "dead";
    state.endTimer = 1.2;
    state.paused = false;
    state.lootId = null;
    state.events.push("death");
  }
}

function segDist(px: number, py: number, x1: number, y1: number, x2: number, y2: number) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  const l2 = dx * dx + dy * dy || 1;
  let t = ((px - x1) * dx + (py - y1) * dy) / l2;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
}

function hasKey(p: Player, id?: string) {
  if (!id) return false;
  return [...p.pack, ...p.secure].some((it) => it.defId === id);
}

function extractOpen(state: RaidState, gated: "none" | "switch" | "key") {
  if (gated === "none") return true;
  if (gated === "switch") return state.gateOpen;
  return hasKey(state.player, state.map.keyId);
}

function riverAt(state: RaidState, x: number, y: number) {
  const tx = Math.floor(x / TILE);
  const ty = Math.floor(y / TILE);
  const riverX = Math.floor(state.map.w * 0.34 + Math.sin(ty * 0.23) * 3.2);
  return Math.abs(tx - riverX) <= 1 && tx >= 1 && tx < state.map.w - 1 && ty >= 1 && ty < state.map.h - 1 && state.map.tiles[ty * state.map.w + tx] === 0;
}

function updatePrompt(state: RaidState) {
  const p = state.player;
  let best = 54;
  let prompt = "";
  for (const box of state.boxes) {
    if (box.open && box.items.length === 0) continue;
    const d = Math.hypot(box.x - p.x, box.y - p.y);
    if (d < best) {
      best = d;
      const label = box.kind === "body" ? "遗体" : box.kind === "safe" ? "保险箱" : "容器";
      prompt = box.open ? `F  翻找${label}` : `F  搜索${label}`;
    }
  }
  for (const sw of state.map.switches) {
    const d = Math.hypot(sw.x - p.x, sw.y - p.y);
    if (d < best) {
      best = d;
      prompt = state.gateOpen ? "电闸已经合上" : "F  拉下电闸";
    }
  }
  const hasEmptyFlask = [...p.pack, ...p.secure].some(it => it.defId === "empty_flask");
  if (hasEmptyFlask && riverAt(state, p.x, p.y) && best >= 54) prompt = "F  从溪流装取清水";
  for (const ex of state.map.extracts) {
    const d = Math.hypot(ex.x - p.x, ex.y - p.y);
    if (d < 78) {
      if (!extractOpen(state, ex.gated)) {
        prompt =
          ex.gated === "key"
            ? `${ex.name} · 需要${ITEMS[state.map.keyId ?? ""]?.name ?? "钥匙"}`
            : `${ex.name} · 电闸未合`;
      }
    }
  }
  if (p.extract > 0) prompt = `撤离中 ${Math.ceil(5 - p.extract)}`;
  state.prompt = prompt;
}

function interact(state: RaidState) {
  const p = state.player;
  if (riverAt(state, p.x, p.y)) {
    const list = [p.pack, p.secure];
    for (const items of list) {
      const flask = items.find(it => it.defId === "empty_flask");
      if (flask) {
        flask.defId = "water_flask";
        state.msg = "水囊装满了溪水。撤离后可用来浇灌家园。";
        state.msgT = 2.4;
        state.events.push("zip");
        return;
      }
    }
  }
  let bestD = 54;
  let kind: "box" | "switch" | null = null;
  let box: LootBox | null = null;
  for (const b of state.boxes) {
    if (b.open && b.items.length === 0) continue;
    const d = Math.hypot(b.x - p.x, b.y - p.y);
    if (d < bestD) {
      bestD = d;
      kind = "box";
      box = b;
    }
  }
  for (const sw of state.map.switches) {
    const d = Math.hypot(sw.x - p.x, sw.y - p.y);
    if (d < bestD) {
      bestD = d;
      kind = "switch";
      box = null;
    }
  }
  if (kind === "switch") {
    state.gateOpen = true;
    state.msg = "电闸合上了，对应的门已经打开。";
    state.msgT = 2.2;
    state.events.push("zip");
    return;
  }
  if (kind === "box" && box) {
    if (!box.open) {
      box.open = true;
      state.events.push("search");
    }
    state.lootId = box.id;
    state.paused = true;
  }
}

function applyMed(state: RaidState) {
  const p = state.player;
  for (const list of [p.pack, p.secure]) {
    const i = list.findIndex((it) => it.uid === p.using);
    if (i < 0) continue;
    const it = list[i]!;
    const d = ITEMS[it.defId];
    if (d?.heal) p.hp = Math.min(100, p.hp + d.heal);
    if (d?.buff) {
      p.buff = Math.max(p.buff, d.buff);
      state.msg = "腿暂时不疼了。";
      state.msgT = 1.2;
    }
    it.count -= 1;
    if (it.count <= 0) list.splice(i, 1);
    state.events.push("zip");
    return;
  }
}

function finishReload(state: RaidState) {
  const p = state.player;
  const w = weaponDef(p);
  if (!w?.ammo || !w.mag) return;
  const need = w.mag - p.mag;
  if (need <= 0) return;
  p.mag += takeAmmo(p, w.ammo, need);
}

function lerpAngle(a: number, b: number, t: number) {
  const d = Math.atan2(Math.sin(b - a), Math.cos(b - a));
  return a + d * t;
}

export function step(state: RaidState, dt: number, input: InputState) {
  state.events.length = 0;
  if (state.outcome) {
    state.endTimer -= dt;
    state.flash = Math.max(0, state.flash - dt);
    return;
  }
  if (state.paused) return;
  if (state.hitStop > 0) {
    state.hitStop -= dt;
    return;
  }

  const p = state.player;
  const map = state.map;
  p.fireCd = Math.max(0, p.fireCd - dt);
  p.buff = Math.max(0, p.buff - dt);
  p.hit = Math.max(0, p.hit - dt);
  state.flash = Math.max(0, state.flash - dt);
  state.recoil = Math.max(0, state.recoil - dt * 6);
  state.msgT = Math.max(0, state.msgT - dt);
  state.shake *= Math.exp(-5.5 * dt);

  if (input.aimOk) p.aim = Math.atan2(input.aimY - p.y, input.aimX - p.x);

  const weight = carryWeight(
    { weapon: p.weapon, armor: p.armor, helmet: p.helmet },
    p.pack,
    p.secure,
  );
  let speed = 178;
  const enc = weight / state.weightLimit;
  if (enc > 0.6) speed *= 1 - Math.min(0.42, (enc - 0.6) * 0.65);
  if (enc > 1) speed *= state.weightLimit / weight;
  if (p.buff > 0) speed *= 1.12;
  if (p.use > 0) speed *= 0.7;
  if (p.reload > 0) speed *= 0.84;

  let mx = input.mx;
  let my = input.my;
  const len = Math.hypot(mx, my);
  if (len > 1) {
    mx /= len;
    my /= len;
  }
  const ox = p.x;
  const oy = p.y;
  moveBody(map, p, mx * speed * dt, my * speed * dt, R);
  p.vx = dt > 0 ? (p.x - ox) / dt : 0;
  p.vy = dt > 0 ? (p.y - oy) / dt : 0;

  if (input.heal && p.use <= 0 && p.reload <= 0) {
    const med = [...p.pack, ...p.secure].find((it) => ITEMS[it.defId]?.cat === "med" && it.count > 0);
    if (med) {
      const d = ITEMS[med.defId];
      p.use = (d?.use ?? 2) * state.healMul;
      p.using = med.uid;
    } else {
      state.msg = "没有医疗品";
      state.msgT = 0.7;
    }
  }
  if (p.use > 0) {
    if (input.fire) {
      p.use = 0;
      p.using = null;
    } else {
      p.use -= dt;
      if (p.use <= 0) applyMed(state);
    }
  }

  if (input.reload) startReload(state, p);
  if (p.reload > 0) {
    p.reload -= dt;
    if (p.reload <= 0) finishReload(state);
  } else if (input.fire) tryFire(state, p);

  if (input.interact) interact(state);

  let inZone = false;
  for (const ex of map.extracts) {
    if (!extractOpen(state, ex.gated)) continue;
    if (Math.hypot(ex.x - p.x, ex.y - p.y) < 62) inZone = true;
  }
  if (inZone) {
    p.extract += dt;
    if (p.extract >= 5 && !state.outcome) {
      state.outcome = "extract";
      state.endTimer = 0.85;
      state.events.push("extract");
      state.msg = "撤离成功";
      state.msgT = 2;
    }
  } else p.extract = Math.max(0, p.extract - dt * 2);

  state.time -= dt;
  if (state.time <= 0 && !state.outcome) {
    state.time = 0;
    state.outcome = "mia";
    state.endTimer = 1.1;
    state.events.push("death");
  }

  for (const s of state.scavs) {
    if (!s.alive) continue;
    s.cd = Math.max(0, s.cd - dt);
    s.flash = Math.max(0, s.flash - dt);
    const dist = Math.hypot(p.x - s.x, p.y - s.y);
    const see = dist < map.scav.range + 30 && los(map, s.x, s.y, p.x, p.y);
    let dx = 0;
    let dy = 0;
    if (see) {
      if (!s.seen) s.react = 0.32;
      s.seen = true;
      s.react = Math.max(0, s.react - dt);
      const ang = Math.atan2(p.y - s.y, p.x - s.x);
      s.aim = lerpAngle(s.aim, ang, 1 - Math.exp(-9 * dt));
      if (dist > 168) {
        dx = Math.cos(ang);
        dy = Math.sin(ang);
      } else if (dist < 96) {
        dx = -Math.cos(ang);
        dy = -Math.sin(ang);
      }
      if (s.react <= 0 && s.cd <= 0 && dist < map.scav.range) {
        const miss = (Math.random() - 0.5) * 0.22;
        spawnBullet(state, s.x + Math.cos(s.aim) * 16, s.y + Math.sin(s.aim) * 16, s.aim + miss, map.scav.dmg, 1, map.scav.range);
        s.cd = map.scav.cd * (0.85 + Math.random() * 0.45);
        spark(state, s.x + Math.cos(s.aim) * 16, s.y + Math.sin(s.aim) * 16, "#c4452d", 3, 40);
      }
    } else {
      if (dist > map.scav.range + 120) s.seen = false;
      s.wanderT -= dt;
      if (s.wanderT <= 0) {
        s.wander = Math.random() * Math.PI * 2;
        s.wanderT = 0.7 + Math.random() * 1.5;
      }
      dx = Math.cos(s.wander);
      dy = Math.sin(s.wander);
      s.aim = lerpAngle(s.aim, s.wander, 1 - Math.exp(-4 * dt));
    }
    for (const o of state.scavs) {
      if (o === s || !o.alive) continue;
      const ddx = s.x - o.x;
      const ddy = s.y - o.y;
      const d = Math.hypot(ddx, ddy);
      if (d > 0 && d < 30) {
        dx += ddx / d;
        dy += ddy / d;
      }
    }
    const L = Math.hypot(dx, dy);
    if (L > 0) {
      const moved = moveBody(map, s, (dx / L) * map.scav.speed * dt, (dy / L) * map.scav.speed * dt, R);
      if (!moved) s.wanderT = 0;
    }
    const sox = s.x;
    const soy = s.y;
    s.vx = dt > 0 ? (s.x - sox) / dt : 0;
    s.vy = dt > 0 ? (s.y - soy) / dt : 0;
  }

  for (const b of state.bullets) {
    if (!b.alive) continue;
    b.px = b.x;
    b.py = b.y;
    b.x += b.vx * dt;
    b.y += b.vy * dt;
    b.life -= dt;
    if (b.life <= 0) {
      b.alive = false;
      continue;
    }
    let hitWall = false;
    const steps = 3;
    for (let i = 1; i <= steps; i++) {
      const t = i / steps;
      if (wallAt(map, b.px + (b.x - b.px) * t, b.py + (b.y - b.py) * t)) {
        hitWall = true;
        break;
      }
    }
    if (hitWall) {
      b.alive = false;
      spark(state, b.x, b.y, "#8e8a7c", 3, 40);
      continue;
    }
    if (b.team === 0) {
      for (const s of state.scavs) {
        if (!s.alive) continue;
        if (segDist(s.x, s.y, b.px, b.py, b.x, b.y) < R + 2) {
          b.alive = false;
          damageScav(state, s, b.dmg);
          break;
        }
      }
    } else if (segDist(p.x, p.y, b.px, b.py, b.x, b.y) < R + 2) {
      b.alive = false;
      hurtPlayer(state, b.dmg);
    }
  }

  for (const bit of state.particles) {
    if (!bit.alive) continue;
    bit.life -= dt;
    bit.x += bit.vx * dt;
    bit.y += bit.vy * dt;
    bit.vx *= Math.exp(-3 * dt);
    bit.vy *= Math.exp(-3 * dt);
    if (bit.life <= 0) bit.alive = false;
  }
  for (const t of state.texts) t.life -= dt;
  state.texts = state.texts.filter((t) => t.life > 0);

  const look = 42;
  const tx = p.x + Math.cos(p.aim) * look;
  const ty = p.y + Math.sin(p.aim) * look;
  const k = 1 - Math.exp(-7 * dt);
  state.camX += (tx - state.camX) * k;
  state.camY += (ty - state.camY) * k;
  const viewW = state.viewW / Math.max(0.2, state.zoom);
  const viewH = state.viewH / Math.max(0.2, state.zoom);
  const mapW = map.w * TILE;
  const mapH = map.h * TILE;
  if (mapW > viewW) state.camX = Math.max(viewW / 2, Math.min(mapW - viewW / 2, state.camX));
  else state.camX = mapW / 2;
  if (mapH > viewH) state.camY = Math.max(viewH / 2, Math.min(mapH - viewH / 2, state.camY));
  else state.camY = mapH / 2;

  reveal(state);
  updatePrompt(state);
}

export function gearOf(p: Player): Gear {
  if (p.weapon) p.weapon.mag = p.mag;
  return { weapon: p.weapon, armor: p.armor, helmet: p.helmet };
}

export function snapshot(state: RaidState): RaidEnd {
  return {
    outcome: state.outcome ?? "mia",
    kills: state.kills,
    pack: state.player.pack.map((it) => ({ ...it })),
    secure: state.player.secure.map((it) => ({ ...it })),
    equipped: {
      weapon: state.player.weapon ? { ...state.player.weapon, mag: state.player.mag } : null,
      armor: state.player.armor ? { ...state.player.armor } : null,
      helmet: state.player.helmet ? { ...state.player.helmet } : null,
    },
    timeLeft: Math.max(0, state.time),
  };
}

export function raidTransfer(state: RaidState, from: "pack" | "secure" | "box", to: "pack" | "secure" | "box", uid: string) {
  const box = state.boxes.find((b) => b.id === state.lootId);
  const lists = {
    pack: state.player.pack,
    secure: state.player.secure,
    box: box?.items ?? [],
  };
  const cap = to === "pack" ? state.packCap : to === "secure" ? state.secureCap : 99;
  return moveItem(lists[from], lists[to], uid, cap);
}

export function raidDrop(state: RaidState, uid: string) {
  const i = state.player.pack.findIndex((it) => it.uid === uid);
  if (i >= 0) {
    state.player.pack.splice(i, 1);
    return true;
  }
  return false;
}

export function raidEquip(state: RaidState, uid: string): string | null {
  const p = state.player;
  if (p.weapon) p.weapon.mag = p.mag;
  const fromPack = p.pack.find((it) => it.uid === uid);
  const fromSecure = p.secure.find((it) => it.uid === uid);
  const it = fromPack ?? fromSecure;
  if (!it) return "不在身上";
  const d = ITEMS[it.defId];
  const slot = d?.cat === "weapon" ? "weapon" : d?.cat === "armor" ? "armor" : d?.cat === "helmet" ? "helmet" : null;
  if (!slot || !d) return "不能装备";
  const list = fromPack ? p.pack : p.secure;
  const prev = p[slot];
  if (prev && slotsOf(list.filter((x) => x.uid !== uid)) + (ITEMS[prev.defId]?.slots ?? 1) > (fromPack ? state.packCap : state.secureCap)) {
    return "没有空位交换";
  }
  const idx = list.findIndex((x) => x.uid === uid);
  list.splice(idx, 1);
  if (prev) list.push(prev);
  p[slot] = it;
  if (slot === "weapon") p.mag = it.mag ?? 0;
  return null;
}

export function reserveAmmo(p: Player) {
  const w = weaponDef(p);
  if (!w?.ammo) return 0;
  return ammoCount(p, w.ammo);
}

export function medsLeft(p: Player) {
  return [...p.pack, ...p.secure].filter((it) => ITEMS[it.defId]?.cat === "med").reduce((n, it) => n + it.count, 0);
}
