import type { Save } from "./types";

/**
 * Cross-device save contract. The game remains playable offline using localStorage.
 * A future authenticated server can implement this contract without changing game rules.
 */
export type CloudSaveEnvelope = {
  schemaVersion: 1;
  playerId: string;
  revision: number;
  updatedAt: string;
  save: Save;
};

export type SaveSyncStatus = "local-only" | "syncing" | "synced" | "offline" | "conflict";

export type SaveSyncAdapter = {
  pull(playerId: string): Promise<CloudSaveEnvelope | null>;
  push(envelope: CloudSaveEnvelope): Promise<CloudSaveEnvelope>;
};

/** Endpoint contract for the server planned for a later milestone:
 * GET /api/game/save?playerId=... -> CloudSaveEnvelope | 404
 * PUT /api/game/save with CloudSaveEnvelope JSON -> saved CloudSaveEnvelope
 * The server must authenticate the player and validate save payloads; playerId alone is not auth.
 */
export function createHttpSaveSyncAdapter(baseUrl: string, getToken: () => Promise<string | null>): SaveSyncAdapter {
  const endpoint = `${baseUrl.replace(/\/$/, "")}/api/game/save`;
  async function headers(): Promise<HeadersInit> {
    const token = await getToken();
    return { "content-type": "application/json", ...(token ? { authorization: `Bearer ${token}` } : {}) };
  }
  return {
    async pull(playerId) {
      const response = await fetch(`${endpoint}?playerId=${encodeURIComponent(playerId)}`, {
        headers: await headers(),
      });
      if (response.status === 404) return null;
      if (!response.ok) throw new Error(`Cloud save pull failed (${response.status})`);
      return (await response.json()) as CloudSaveEnvelope;
    },
    async push(envelope) {
      const response = await fetch(endpoint, {
        method: "PUT",
        headers: await headers(),
        body: JSON.stringify(envelope),
      });
      if (response.status === 409) throw new Error("Cloud save conflict; resolve revisions before overwriting");
      if (!response.ok) throw new Error(`Cloud save push failed (${response.status})`);
      return (await response.json()) as CloudSaveEnvelope;
    },
  };
}
