export type Cat = "weapon" | "armor" | "helmet" | "med" | "ammo" | "loot" | "key";
export type Rarity = "common" | "uncommon" | "rare" | "legendary";

export type ItemDef = {
  id: string;
  name: string;
  cat: Cat;
  slots: number;
  weight: number;
  sell: number;
  buy?: number;
  buyCount?: number;
  rarity: Rarity;
  blurb: string;
  stack?: number;
  dmg?: number;
  rpm?: number;
  mag?: number;
  reload?: number;
  spread?: number;
  range?: number;
  pellets?: number;
  ammo?: string;
  armor?: number;
  dur?: number;
  heal?: number;
  use?: number;
  buff?: number;
};

export type Item = {
  uid: string;
  defId: string;
  count: number;
  dur?: number;
  mag?: number;
};

export type Gear = {
  weapon: Item | null;
  armor: Item | null;
  helmet: Item | null;
};

export type HideoutLevels = {
  med: number;
  bench: number;
  power: number;
  case: number;
};

export type PendingRaid = {
  secure: Item[];
  insuredGear: Item[] | null;
};

export type FarmPlot = { crop: string | null; plantedAt: number | null; watered: boolean };

export type FarmState = { plots: FarmPlot[]; pasture: number };

export type Save = {
  version: 1;
  rubles: number;
  xp: number;
  raids: number;
  extracts: number;
  kills: number;
  deaths: number;
  stash: Item[];
  pack: Item[];
  secure: Item[];
  equipped: Gear;
  hideout: HideoutLevels;
  farm: FarmState;
  mail: Item[];
  pending: PendingRaid | null;
  log: string;
  sfx: number;
};

export type ContainerKind = "crate" | "med" | "weapon" | "duffel" | "safe" | "key" | "body";

export type Gate = "none" | "switch" | "key";

export type GameMap = {
  id: string;
  name: string;
  area: string;
  brief: string;
  difficulty: 1 | 2 | 3;
  time: number;
  keyId?: string;
  w: number;
  h: number;
  tiles: Uint8Array;
  spawn: { x: number; y: number };
  scavs: { x: number; y: number }[];
  containers: { id: string; x: number; y: number; kind: ContainerKind }[];
  extracts: { id: string; x: number; y: number; gated: Gate; name: string }[];
  switches: { x: number; y: number }[];
  scav: { hp: number; dmg: number; speed: number; range: number; cd: number };
};

export type RaidSetup = {
  mapId: string;
  gear: Gear;
  pack: Item[];
  secure: Item[];
  insure: boolean;
  healMul: number;
  spreadMul: number;
  packCap: number;
  secureCap: number;
  weightLimit: number;
};

export type RaidEnd = {
  outcome: "extract" | "dead" | "mia";
  kills: number;
  pack: Item[];
  secure: Item[];
  equipped: Gear;
  timeLeft: number;
};

export type Debrief = {
  outcome: RaidEnd["outcome"];
  mapName: string;
  kills: number;
  xp: number;
  lootValue: number;
  kept: Item[];
  lost: Item[];
  returned: Item[];
  note: string;
};
