import { ITEMS } from "./content";
import type { Gear, Item, Save } from "./types";

export function defOf(it: Item) {
  return ITEMS[it.defId];
}

export function slotsOf(items: Item[]) {
  return items.reduce((n, it) => n + (defOf(it)?.slots ?? 1), 0);
}

export function unitWeight(it: Item) {
  const d = defOf(it);
  if (!d) return 0;
  return d.stack ? d.weight * it.count : d.weight;
}

export function listWeight(items: Item[]) {
  return items.reduce((n, it) => n + unitWeight(it), 0);
}

export function gearList(gear: Gear) {
  return [gear.weapon, gear.armor, gear.helmet].filter((it): it is Item => !!it);
}

export function carryWeight(gear: Gear, pack: Item[], secure: Item[]) {
  return listWeight([...gearList(gear), ...pack, ...secure]);
}

export function sellValue(it: Item) {
  const d = defOf(it);
  if (!d) return 0;
  if (d.stack) return Math.round(d.sell * it.count);
  const ratio = d.dur && it.dur != null ? it.dur / d.dur : 1;
  return Math.round(d.sell * (0.4 + 0.6 * Math.max(0, Math.min(1, ratio))));
}

export function caps(save: Save) {
  return {
    stash: 28 + save.hideout.bench * 6,
    pack: 10 + (save.hideout.power ? 2 : 0),
    secure: 2 + save.hideout.case,
    weight: 12 + (save.hideout.power ? 3 : 0),
  };
}

export function buyPrice(save: Save, id: string) {
  const d = ITEMS[id];
  if (!d?.buy) return 0;
  const cut = save.hideout.bench >= 2 ? 0.8 : save.hideout.bench >= 1 ? 0.9 : 1;
  return Math.round(d.buy * cut);
}

export function moveItem(from: Item[], to: Item[], uid: string, toCap: number) {
  const i = from.findIndex((x) => x.uid === uid);
  if (i < 0) return false;
  const it = from[i]!;
  const d = defOf(it);
  if (!d) return false;
  if (d.stack) {
    const dest = to.find((x) => x.defId === it.defId && x.count + it.count <= (d.stack ?? 1));
    if (dest) {
      dest.count += it.count;
      from.splice(i, 1);
      return true;
    }
  }
  if (slotsOf(to) + d.slots > toCap) return false;
  from.splice(i, 1);
  to.push(it);
  return true;
}

export function insuranceCost(save: Save) {
  return Math.round(gearList(save.equipped).reduce((n, it) => n + sellValue(it), 0) * 0.28);
}

export function slotOf(cat: string): keyof Gear | null {
  if (cat === "weapon") return "weapon";
  if (cat === "armor") return "armor";
  if (cat === "helmet") return "helmet";
  return null;
}

function lists(save: Save): { name: "stash" | "pack" | "secure"; items: Item[] }[] {
  return [
    { name: "stash", items: save.stash },
    { name: "pack", items: save.pack },
    { name: "secure", items: save.secure },
  ];
}

export function equipItem(save: Save, uid: string): string | null {
  let fromName: "stash" | "pack" | "secure" | null = null;
  let it: Item | undefined;
  for (const list of lists(save)) {
    const found = list.items.find((x) => x.uid === uid);
    if (found) {
      it = found;
      fromName = list.name;
      break;
    }
  }
  if (!it || !fromName) return "找不到这件东西";
  const d = defOf(it);
  const slot = d ? slotOf(d.cat) : null;
  if (!slot || !d) return "这件不能装备";
  const prev = save.equipped[slot];
  if (prev) {
    const places: ("stash" | "pack" | "secure")[] = [fromName, "stash", "pack", "secure"];
    const fits = places.some((name) => {
      const base = name === fromName ? save[name].filter((x) => x.uid !== uid) : save[name];
      return slotsOf(base) + (defOf(prev)?.slots ?? 1) <= caps(save)[name];
    });
    if (!fits) return "没有空位放下原来的装备";
  }
  save[fromName] = save[fromName].filter((x) => x.uid !== uid);
  if (prev) {
    const order: ("stash" | "pack" | "secure")[] = [fromName, "stash", "pack", "secure"];
    let parked = false;
    for (const name of order) {
      if (moveItem([prev], save[name], prev.uid, caps(save)[name])) {
        parked = true;
        break;
      }
    }
    if (!parked) {
      save[fromName].push(it);
      return "没有空位放下原来的装备";
    }
  }
  save.equipped[slot] = it;
  return null;
}

export function unequipItem(save: Save, slot: keyof Gear, dest: "stash" | "pack"): string | null {
  const it = save.equipped[slot];
  if (!it) return null;
  const cap = caps(save)[dest];
  const holder = [it];
  if (!moveItem(holder, save[dest], it.uid, cap)) return dest === "pack" ? "背包满了" : "仓库满了";
  save.equipped[slot] = null;
  return null;
}

export function stashCapsOk(save: Save) {
  return slotsOf(save.stash) <= caps(save).stash;
}
