import { ITEMS, levelOf, makeItem, mapById } from "./content";
import { buyPrice, caps, carryWeight, equipItem, insuranceCost, sellValue, slotsOf } from "./inventory";
import type { Debrief, Item, RaidEnd, RaidSetup, Save } from "./types";

const KEY = "rustbay-save-v1";

function starter(id: string, uid: string, count = 1): Item {
  const d = ITEMS[id];
  if (!d) throw new Error(id);
  const it: Item = { uid, defId: id, count };
  if (d.dur) it.dur = d.dur;
  if (d.mag) it.mag = d.mag;
  return it;
}

export function freshSave(): Save {
  return {
    version: 1,
    rubles: 7600,
    xp: 0,
    raids: 0,
    extracts: 0,
    kills: 0,
    deaths: 0,
    stash: [starter("soap", "st-soap"), starter("bolts", "st-bolts"), starter("canned", "st-can"), starter("ammo9", "st-ammo", 20), starter("moonseed", "st-seed", 3), starter("empty_flask", "st-flask")],
    pack: [starter("bandage", "st-ban", 2), starter("ammo9", "st-mag", 32)],
    secure: [],
    equipped: {
      weapon: starter("pm", "st-pm"),
      armor: starter("paca", "st-paca"),
      helmet: null,
    },
    hideout: { med: 0, bench: 0, power: 0, case: 0 },
    farm: { plots: [{ crop: null, plantedAt: null, watered: false }, { crop: null, plantedAt: null, watered: false }, { crop: null, plantedAt: null, watered: false }], pasture: 0 },
    mail: [],
    pending: null,
    log: "南码头的灯还亮着。带上枪，活着回来。",
    sfx: 0.7,
  };
}

function resolvePending(save: Save): Save {
  if (!save.pending) return save;
  const next: Save = {
    ...save,
    secure: save.pending.secure.map((it) => ({ ...it })),
    pack: [],
    mail: save.mail.slice(),
    equipped: {
      weapon: save.equipped.weapon ? { ...save.equipped.weapon } : null,
      armor: save.equipped.armor ? { ...save.equipped.armor } : null,
      helmet: save.equipped.helmet ? { ...save.equipped.helmet } : null,
    },
    pending: null,
    deaths: save.deaths + 1,
    raids: save.raids + 1,
  };
  if (save.pending.insuredGear?.length) {
    next.mail = next.mail.concat(save.pending.insuredGear.map((it) => ({ ...it })));
    next.equipped = { weapon: null, armor: null, helmet: null };
    next.log = "上次联络中断。上了保险的装备退回了邮箱，背包里的东西没了。";
  } else {
    next.equipped = { weapon: null, armor: null, helmet: null };
    next.log = "上次没能撤离。带进去的装备和搜到的东西都留在湾里了。";
  }
  const net = safetyNet(next);
  if (net.logNote) net.save.log = `${net.save.log}${net.logNote}`;
  return net.save;
}

export function loadSave(): Save {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return freshSave();
    const data = JSON.parse(raw) as Partial<Save>;
    if (!data || data.version !== 1) return freshSave();
    const base = freshSave();
    const save: Save = {
      ...base,
      ...data,
      stash: Array.isArray(data.stash) ? data.stash : [],
      pack: Array.isArray(data.pack) ? data.pack : [],
      secure: Array.isArray(data.secure) ? data.secure : [],
      mail: Array.isArray(data.mail) ? data.mail : [],
      equipped: { ...base.equipped, ...(data.equipped ?? {}) },
      hideout: { ...base.hideout, ...(data.hideout ?? {}) },
      farm: { ...base.farm, ...(data.farm ?? {}), plots: Array.isArray(data.farm?.plots) ? data.farm.plots : base.farm.plots },
      pending: data.pending ?? null,
      version: 1,
    };
    return resolvePending(save);
  } catch {
    return freshSave();
  }
}

export function writeSave(save: Save) {
  try {
    const backup = localStorage.getItem(KEY);
    if (backup) localStorage.setItem(`${KEY}-bak`, backup);
    localStorage.setItem(KEY, JSON.stringify(save));
  } catch {
    /* private mode / quota: keep playing in memory */
  }
}

function cloneGear(g: Save["equipped"]): Save["equipped"] {
  return {
    weapon: g.weapon ? { ...g.weapon } : null,
    armor: g.armor ? { ...g.armor } : null,
    helmet: g.helmet ? { ...g.helmet } : null,
  };
}

export function beginRaid(save: Save, mapId: string, insure: boolean): { save: Save; setup: RaidSetup } | { error: string } {
  const cost = insuranceCost(save);
  if (insure && save.rubles < cost) return { error: "卢布不够付保险" };
  const cap = caps(save);
  if (slotsOf(save.pack) > cap.pack) return { error: "背包超格，先拿回仓库" };
  if (carryWeight(save.equipped, save.pack, save.secure) > cap.weight + 6) {
    return { error: "负重太高，先卸掉一些" };
  }
  const gear = cloneGear(save.equipped);
  const setup: RaidSetup = {
    mapId,
    gear: cloneGear(gear),
    pack: save.pack.map((it) => ({ ...it })),
    secure: save.secure.map((it) => ({ ...it })),
    insure,
    healMul: save.hideout.med >= 2 ? 0.68 : save.hideout.med >= 1 ? 0.84 : 1,
    spreadMul: save.hideout.bench >= 2 ? 0.88 : 1,
    packCap: cap.pack,
    secureCap: cap.secure,
    weightLimit: cap.weight,
  };
  const next: Save = {
    ...save,
    rubles: save.rubles - (insure ? cost : 0),
    pack: [],
    secure: [],
    equipped: insure ? { weapon: null, armor: null, helmet: null } : cloneGear(save.equipped),
    pending: {
      secure: save.secure.map((it) => ({ ...it })),
      insuredGear: insure
        ? [gear.weapon, gear.armor, gear.helmet].filter((it): it is Item => !!it).map((it) => ({ ...it }))
        : null,
    },
  };
  return { save: next, setup };
}

function hurtGear(items: Item[]) {
  return items.map((it) => {
    const d = ITEMS[it.defId];
    if (!d?.dur || it.dur == null) return { ...it };
    return { ...it, dur: Math.max(8, it.dur - 18) };
  });
}

export function finishRaid(save: Save, setup: RaidSetup, result: RaidEnd): { save: Save; debrief: Debrief } {
  const map = mapById(setup.mapId);
  const brought = new Set<string>(
    [...setup.pack, ...setup.secure, setup.gear.weapon, setup.gear.armor, setup.gear.helmet]
      .filter((it): it is Item => !!it)
      .map((it) => it.uid),
  );
  const gained = [...result.pack, ...result.secure].filter((it) => !brought.has(it.uid));
  const lootValue = result.outcome === "extract" ? gained.reduce((n, it) => n + sellValue(it), 0) : 0;
  const xp =
    result.outcome === "extract" ? 45 + result.kills * 12 + Math.floor(lootValue / 900) : result.kills * 5;
  const next: Save = {
    ...save,
    xp: save.xp + xp,
    kills: save.kills + result.kills,
    raids: save.raids + 1,
    pending: null,
    secure: result.secure.map((it) => ({ ...it })),
    mail: save.mail.slice(),
  };
  if (next.farm.pasture > 0) {
    for (let i = 0; i < next.farm.pasture; i++) {
      next.stash.push({ uid: `pelt-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 6)}`, defId: "hare_pelt", count: 1 });
    }
  }
  let kept: Item[] = [];
  let lost: Item[] = [];
  let returned: Item[] = [];
  let note = "";
  if (result.outcome === "extract") {
    next.extracts += 1;
    next.pack = result.pack.map((it) => ({ ...it }));
    next.equipped = {
      weapon: result.equipped.weapon ? { ...result.equipped.weapon } : null,
      armor: result.equipped.armor ? { ...result.equipped.armor } : null,
      helmet: result.equipped.helmet ? { ...result.equipped.helmet } : null,
    };
    kept = [...next.pack, ...gearItems(next.equipped), ...next.secure];
    note =
      lootValue > 0
        ? `活着离开${map.name}。新带出的东西大约值 ${lootValue.toLocaleString("zh-CN")} 卢布，得卖了才算数。`
        : `活着离开${map.name}。口袋没鼓，但人还在。`;
  } else {
    next.deaths += 1;
    next.pack = [];
    next.equipped = { weapon: null, armor: null, helmet: null };
    lost = result.pack.map((it) => ({ ...it }));
    const gear = [result.equipped.weapon, result.equipped.armor, result.equipped.helmet].filter(
      (it): it is Item => !!it,
    );
    if (setup.insure && gear.length) {
      returned = hurtGear(gear);
      next.mail = next.mail.concat(returned.map((it) => ({ ...it })));
      note =
        result.outcome === "mia"
          ? "时间到了，你被留在雾里。保险会把装备退回，搜到的不会。"
          : "你倒在湾里。上了保险的装备会退回邮箱，其余的留在原地。";
    } else {
      lost = lost.concat(gear.map((it) => ({ ...it })));
      note =
        result.outcome === "mia"
          ? "时间耗尽。没保险，带进去的一切都不是你的了。"
          : "没有撤离，就没有战利品。枪也留在那里了。";
    }
    kept = next.secure.map((it) => ({ ...it }));
  }
  const net = safetyNet(next);
  if (net.logNote) note = `${note}${net.logNote}`;
  next.log = note;
  const debrief: Debrief = {
    outcome: result.outcome,
    mapName: map.name,
    kills: result.kills,
    xp,
    lootValue,
    kept,
    lost,
    returned,
    note,
  };
  return { save: net.save, debrief };
}

function gearItems(g: Save["equipped"]) {
  return [g.weapon, g.armor, g.helmet].filter((it): it is Item => !!it);
}

export function safetyNet(save: Save): { save: Save; logNote: string } {
  const hasWeapon = [save.equipped.weapon, ...save.stash, ...save.pack, ...save.secure, ...save.mail].some(
    (it) => it && ITEMS[it.defId]?.cat === "weapon",
  );
  if (!hasWeapon && save.rubles < 4800) {
    const gun = makeItem("pm");
    save.equipped.weapon = gun;
    save.pack = save.pack.concat([makeItem("ammo9", 24)]);
    save.rubles += 1800;
    return { save, logNote: " 黑市留了一支马卡洛夫和一点路费。" };
  }
  return { save, logNote: "" };
}

export function sellStashItem(save: Save, uid: string): string | null {
  const it = save.stash.find((x) => x.uid === uid);
  if (!it) return "仓库里没有这件";
  save.stash = save.stash.filter((x) => x.uid !== uid);
  save.rubles += sellValue(it);
  return null;
}

export function buyItem(save: Save, id: string): string | null {
  const d = ITEMS[id];
  if (!d?.buy) return "商人不卖这个";
  if (levelOf(save.xp) < (TRADER_LEVEL[id] ?? 1)) return "等级不够";
  const price = buyPrice(save, id);
  if (save.rubles < price) return "卢布不够";
  const count = d.buyCount ?? 1;
  const it = makeItem(id, count);
  if (slotsOf(save.stash) + d.slots > caps(save).stash) return "仓库满了";
  save.rubles -= price;
  save.stash = save.stash.concat(it);
  return null;
}

const TRADER_LEVEL: Record<string, number> = {
  pm: 1,
  kedr: 1,
  paca: 1,
  bandage: 1,
  pain: 1,
  ammo9: 1,
  ifak: 2,
  ssh: 2,
  vest: 2,
  ak: 2,
  ammo545: 2,
  shottie: 3,
  ammo12: 3,
  mosin: 3,
  ammo762: 3,
  heavy: 3,
  mich: 3,
};

export function claimMail(save: Save): string | null {
  if (!save.mail.length) return null;
  const left: Item[] = [];
  for (const it of save.mail) {
    const d = ITEMS[it.defId];
    const slot = d?.cat === "weapon" ? "weapon" : d?.cat === "armor" ? "armor" : d?.cat === "helmet" ? "helmet" : null;
    if (slot && !save.equipped[slot]) {
      save.equipped[slot] = it;
      continue;
    }
    if (slotsOf(save.stash) + (d?.slots ?? 1) <= caps(save).stash) {
      save.stash.push(it);
    } else left.push(it);
  }
  save.mail = left;
  return left.length ? "仓库满了，还有东西在邮箱里" : null;
}

export function repairGear(save: Save): string | null {
  if (save.hideout.bench < 1) return "先建工作台";
  const items = gearItems(save.equipped);
  let cost = 0;
  for (const it of items) {
    const d = ITEMS[it.defId];
    if (!d?.dur || it.dur == null) continue;
    const missing = 1 - it.dur / d.dur;
    if (missing <= 0.02) continue;
    cost += Math.round(600 + missing * d.sell * 0.18);
  }
  if (cost <= 0) return "装备还很新";
  if (save.rubles < cost) return `保养要 ${cost} 卢布`;
  save.rubles -= cost;
  for (const it of items) {
    const d = ITEMS[it.defId];
    if (d?.dur) it.dur = d.dur;
  }
  return null;
}

export function repairCost(save: Save) {
  let cost = 0;
  for (const it of gearItems(save.equipped)) {
    const d = ITEMS[it.defId];
    if (!d?.dur || it.dur == null) continue;
    const missing = 1 - it.dur / d.dur;
    if (missing <= 0.02) continue;
    cost += Math.round(600 + missing * d.sell * 0.18);
  }
  return cost;
}

export { equipItem };
