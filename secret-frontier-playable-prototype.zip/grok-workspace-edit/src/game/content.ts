import type { ContainerKind, GameMap, Item, ItemDef } from "./types";

export const TILE = 48;

export const ITEMS: Record<string, ItemDef> = {
  pm: {
    id: "pm",
    name: "旅人短弩",
    cat: "weapon",
    slots: 2,
    weight: 0.73,
    sell: 2400,
    buy: 5200,
    rarity: "common",
    blurb: "轻便的旅人弩，射程有限，但足以应付边境低阶魔物。",
    dmg: 22,
    rpm: 420,
    mag: 8,
    reload: 1.45,
    spread: 0.045,
    range: 460,
    ammo: "ammo9",
    dur: 100,
  },
  kedr: {
    id: "kedr",
    name: "连发符文弩",
    cat: "weapon",
    slots: 3,
    weight: 1.55,
    sell: 9000,
    buy: 16800,
    rarity: "uncommon",
    blurb: "刻有连发符文的短弩，近距离火力凶猛，耗矢也快。",
    dmg: 12,
    rpm: 880,
    mag: 20,
    reload: 1.9,
    spread: 0.075,
    range: 400,
    ammo: "ammo9",
    dur: 100,
  },
  ak: {
    id: "ak",
    name: "精灵长弓",
    cat: "weapon",
    slots: 4,
    weight: 3.3,
    sell: 17000,
    buy: 30500,
    rarity: "rare",
    blurb: "精灵工匠打造的长弓，稳定而可靠，适合中距离交战。",
    dmg: 28,
    rpm: 600,
    mag: 30,
    reload: 2.25,
    spread: 0.03,
    range: 640,
    ammo: "ammo545",
    dur: 100,
  },
  shottie: {
    id: "shottie",
    name: "矮人散射弩",
    cat: "weapon",
    slots: 3,
    weight: 2.5,
    sell: 15000,
    buy: 27500,
    rarity: "rare",
    blurb: "矮人制作的散射弩，近处威力惊人，远处精度有限。",
    dmg: 8,
    rpm: 78,
    mag: 5,
    reload: 2.5,
    spread: 0.16,
    range: 280,
    pellets: 6,
    ammo: "ammo12",
    dur: 100,
  },
  mosin: {
    id: "mosin",
    name: "秘银穿刺弩",
    cat: "weapon",
    slots: 4,
    weight: 3.6,
    sell: 21000,
    buy: 38000,
    rarity: "legendary",
    blurb: "秘银穿刺弩的装填很慢，但一发就能洞穿重甲。",
    dmg: 74,
    rpm: 40,
    mag: 5,
    reload: 2.7,
    spread: 0.006,
    range: 880,
    ammo: "ammo762",
    dur: 100,
  },
  paca: {
    id: "paca",
    name: "皮革护胸",
    cat: "armor",
    slots: 3,
    weight: 3.1,
    sell: 4200,
    buy: 9600,
    rarity: "common",
    blurb: "硬化皮革护胸，轻便，能挡住一部分近战伤害。",
    armor: 0.28,
    dur: 45,
  },
  vest: {
    id: "vest",
    name: "锁子甲",
    cat: "armor",
    slots: 4,
    weight: 6.4,
    sell: 15000,
    buy: 28000,
    rarity: "uncommon",
    blurb: "传统锁子甲，沉重但可靠，适合踏入危险遗迹。",
    armor: 0.46,
    dur: 60,
  },
  heavy: {
    id: "heavy",
    name: "骑士板甲",
    cat: "armor",
    slots: 4,
    weight: 9.2,
    sell: 30000,
    buy: 52000,
    rarity: "rare",
    blurb: "厚重骑士板甲，显著降低伤害，但会拖慢行动。",
    armor: 0.62,
    dur: 75,
  },
  ssh: {
    id: "ssh",
    name: "铁制头盔",
    cat: "helmet",
    slots: 2,
    weight: 1.4,
    sell: 5200,
    buy: 11500,
    rarity: "common",
    blurb: "旧钢，新伤。总比光着好。",
    armor: 0.16,
    dur: 32,
  },
  mich: {
    id: "mich",
    name: "符文头盔",
    cat: "helmet",
    slots: 2,
    weight: 1.25,
    sell: 17000,
    buy: 32000,
    rarity: "rare",
    blurb: "能买到它的人，通常已经不需要解释为什么。",
    armor: 0.3,
    dur: 42,
  },
  bandage: {
    id: "bandage",
    name: "绷带",
    cat: "med",
    slots: 1,
    weight: 0.08,
    sell: 700,
    buy: 1500,
    buyCount: 1,
    rarity: "common",
    blurb: "用干净布条与草药包扎伤口。",
    stack: 4,
    heal: 34,
    use: 3.1,
  },
  ifak: {
    id: "ifak",
    name: "急救包",
    cat: "med",
    slots: 1,
    weight: 0.32,
    sell: 2800,
    buy: 5400,
    rarity: "uncommon",
    blurb: "炼金师预制的急救包，快速恢复生命。",
    stack: 2,
    heal: 70,
    use: 2.5,
  },
  pain: {
    id: "pain",
    name: "止痛针",
    cat: "med",
    slots: 1,
    weight: 0.05,
    sell: 1800,
    buy: 3600,
    rarity: "uncommon",
    blurb: "短暂提升行动能力的炼金药剂。",
    stack: 3,
    heal: 0,
    use: 1.15,
    buff: 18,
  },
  ammo9: {
    id: "ammo9",
    name: "轻型弩矢",
    cat: "ammo",
    slots: 1,
    weight: 0.012,
    sell: 22,
    buy: 1100,
    buyCount: 30,
    rarity: "common",
    blurb: "马卡洛夫和克林的口粮。",
    stack: 60,
  },
  ammo545: {
    id: "ammo545",
    name: "精灵箭矢",
    cat: "ammo",
    slots: 1,
    weight: 0.012,
    sell: 34,
    buy: 1600,
    buyCount: 30,
    rarity: "uncommon",
    blurb: "步枪吃这个。",
    stack: 60,
  },
  ammo762: {
    id: "ammo762",
    name: "重型弩矢",
    cat: "ammo",
    slots: 1,
    weight: 0.018,
    sell: 55,
    buy: 1800,
    buyCount: 20,
    rarity: "rare",
    blurb: "栓动步枪的五发，每一发都贵。",
    stack: 40,
  },
  ammo12: {
    id: "ammo12",
    name: "散射箭束",
    cat: "ammo",
    slots: 1,
    weight: 0.038,
    sell: 48,
    buy: 1400,
    buyCount: 10,
    rarity: "uncommon",
    blurb: "近处很吵，远处没用。",
    stack: 20,
  },
  soap: {
    id: "soap",
    name: "炼金皂石",
    cat: "loot",
    slots: 1,
    weight: 0.22,
    sell: 1900,
    rarity: "common",
    blurb: "港区还能用的干净东西不多，这是一件。",
  },
  bolts: {
    id: "bolts",
    name: "古铜铆钉",
    cat: "loot",
    slots: 1,
    weight: 0.45,
    sell: 2400,
    rarity: "common",
    blurb: "商人拿去修船，你拿去换子弹。",
  },
  canned: {
    id: "canned",
    name: "旅者干粮",
    cat: "loot",
    slots: 1,
    weight: 0.36,
    sell: 2800,
    rarity: "common",
    blurb: "标签掉了。味道还在。",
  },
  circuit: {
    id: "circuit",
    name: "破损符文板",
    cat: "loot",
    slots: 1,
    weight: 0.16,
    sell: 5600,
    rarity: "uncommon",
    blurb: "烧毁了一半，剩下那半值钱。",
  },
  cable: {
    id: "cable",
    name: "魔导铜线",
    cat: "loot",
    slots: 2,
    weight: 0.95,
    sell: 8200,
    rarity: "uncommon",
    blurb: "沉。藏身处的发电机喜欢这个。",
  },
  chain: {
    id: "chain",
    name: "贵族金链",
    cat: "loot",
    slots: 1,
    weight: 0.08,
    sell: 15000,
    rarity: "rare",
    blurb: "原来的主人没能带走它。",
  },
  doc: {
    id: "doc",
    name: "王国密令",
    cat: "loot",
    slots: 1,
    weight: 0.06,
    sell: 12000,
    rarity: "rare",
    blurb: "海关印章还没干。别在战区里读。",
  },
  hdd: {
    id: "hdd",
    name: "封印水晶",
    cat: "loot",
    slots: 1,
    weight: 0.28,
    sell: 24000,
    rarity: "rare",
    blurb: "打不开。所以更贵。",
  },
  gpu: {
    id: "gpu",
    name: "古代魔导核心",
    cat: "loot",
    slots: 2,
    weight: 0.62,
    sell: 52000,
    rarity: "legendary",
    blurb: "港区只流通过几块。看见就别犹豫。",
  },
  dogtag: {
    id: "dogtag",
    name: "佣兵徽记",
    cat: "loot",
    slots: 1,
    weight: 0.04,
    sell: 1600,
    rarity: "uncommon",
    blurb: "搜刮者的收据。",
  },
  moonseed: {
    id: "moonseed", name: "月光草种子", cat: "loot", slots: 1, weight: 0.03, sell: 180,
    buy: 350, buyCount: 1, rarity: "common", stack: 10,
    blurb: "在家园的苗圃种下，浇水后等待它成熟。",
  },
  empty_flask: {
    id: "empty_flask", name: "空水囊", cat: "loot", slots: 1, weight: 0.12, sell: 80,
    buy: 160, rarity: "common", blurb: "到溪流边装满清水，再带回家园。",
  },
  water_flask: {
    id: "water_flask", name: "溪水水囊", cat: "loot", slots: 1, weight: 0.22, sell: 30,
    rarity: "common", blurb: "用于浇灌家园里的作物。",
  },
  moonherb: {
    id: "moonherb", name: "月光草", cat: "loot", slots: 1, weight: 0.08, sell: 950,
    rarity: "uncommon", blurb: "带有微光的药草，可出售给商人。",
  },
  captured_hare: {
    id: "captured_hare", name: "捕获的林兔", cat: "loot", slots: 2, weight: 0.7, sell: 450,
    rarity: "uncommon", blurb: "把它安置进牧场，之后会定期产出毛皮。",
  },
  hare_pelt: {
    id: "hare_pelt", name: "林兔毛皮", cat: "loot", slots: 1, weight: 0.2, sell: 620,
    rarity: "common", blurb: "牧场收获的柔软毛皮。",
  },
  key_apt: {
    id: "key_apt",
    name: "法师塔古钥",
    cat: "key",
    slots: 1,
    weight: 0.05,
    sell: 4500,
    rarity: "uncommon",
    blurb: "天台门的齿纹还在。",
  },
  key_yard: {
    id: "key_yard",
    name: "要塞通行符",
    cat: "key",
    slots: 1,
    weight: 0.05,
    sell: 6800,
    rarity: "rare",
    blurb: "塑料卡片，磁条快磨没了。侧门还认它。",
  },
};

export const TRADER: { id: string; level: number }[] = [
  { id: "pm", level: 1 },
  { id: "kedr", level: 1 },
  { id: "paca", level: 1 },
  { id: "bandage", level: 1 },
  { id: "pain", level: 1 },
  { id: "ammo9", level: 1 },
  { id: "ifak", level: 2 },
  { id: "ssh", level: 2 },
  { id: "vest", level: 2 },
  { id: "ak", level: 2 },
  { id: "ammo545", level: 2 },
  { id: "shottie", level: 3 },
  { id: "ammo12", level: 3 },
  { id: "mosin", level: 3 },
  { id: "ammo762", level: 3 },
  { id: "heavy", level: 3 },
  { id: "mich", level: 3 },
];

export const UPGRADES: {
  key: "med" | "bench" | "power" | "case";
  level: number;
  cost: number;
  name: string;
  desc: string;
  needPower: boolean;
}[] = [
  { key: "power", level: 1, cost: 15000, name: "以太晶能源炉", desc: "负重提高，并解锁二级设施。", needPower: false },
  { key: "med", level: 1, cost: 7000, name: "炼金治疗台", desc: "战区里包扎更快。", needPower: false },
  { key: "med", level: 2, cost: 19000, name: "炼金治疗台 II", desc: "包扎再缩短一截。", needPower: true },
  { key: "bench", level: 1, cost: 8500, name: "符文工坊", desc: "商人便宜一成，仓库变大，可以保养枪械。", needPower: false },
  { key: "bench", level: 2, cost: 23000, name: "符文工坊 II", desc: "进货再便宜，点射更稳。", needPower: true },
  { key: "case", level: 1, cost: 13000, name: "秘藏箱扩容", desc: "安全格 +1。死了也带得走。", needPower: false },
  { key: "case", level: 2, cost: 28000, name: "秘藏箱扩容 II", desc: "安全格再 +1。", needPower: true },
];

const KIND: Record<string, ContainerKind> = {
  C: "crate",
  H: "med",
  B: "weapon",
  F: "duffel",
  $: "safe",
  K: "key",
};

function grid(w: number, h: number) {
  return Array.from({ length: h }, () => Array.from({ length: w }, () => "#"));
}

function rect(g: string[][], x: number, y: number, w: number, h: number, ch = ".") {
  for (let j = 0; j < h; j++) {
    for (let i = 0; i < w; i++) {
      const row = g[y + j];
      if (row && row[x + i] !== undefined) row[x + i] = ch;
    }
  }
}

function put(g: string[][], x: number, y: number, ch: string) {
  const row = g[y];
  if (!row || row[x] === undefined) return;
  if (row[x] === "#") row[x] = ".";
  row[x] = ch;
}

function mapDocks(): string[][] {
  const g = grid(46, 30);
  rect(g, 2, 18, 12, 9);
  rect(g, 6, 12, 4, 8);
  rect(g, 2, 3, 14, 11);
  rect(g, 14, 7, 6, 5);
  rect(g, 18, 4, 22, 18);
  rect(g, 22, 11, 8, 1, "#");
  rect(g, 32, 15, 1, 5, "#");
  rect(g, 30, 2, 13, 6);
  rect(g, 34, 18, 10, 9);
  put(g, 5, 22, "S");
  put(g, 4, 6, "H");
  put(g, 8, 8, "F");
  put(g, 11, 5, "C");
  put(g, 21, 8, "C");
  put(g, 23, 8, "C");
  put(g, 26, 14, "C");
  put(g, 28, 17, "C");
  put(g, 34, 9, "B");
  put(g, 36, 9, "B");
  put(g, 20, 18, "F");
  put(g, 38, 23, "F");
  put(g, 40, 20, "C");
  put(g, 33, 4, "P");
  put(g, 38, 4, "G");
  put(g, 40, 24, "E");
  put(g, 24, 9, "A");
  put(g, 30, 13, "A");
  put(g, 36, 16, "A");
  put(g, 22, 19, "A");
  put(g, 39, 22, "A");
  return g;
}

function mapApts(): string[][] {
  const g = grid(43, 36);
  rect(g, 19, 1, 5, 34);
  rect(g, 1, 16, 41, 5);
  rect(g, 2, 2, 15, 12);
  rect(g, 26, 2, 15, 12);
  rect(g, 2, 23, 15, 11);
  rect(g, 26, 23, 15, 11);
  rect(g, 15, 6, 5, 3);
  rect(g, 23, 6, 5, 3);
  rect(g, 7, 12, 4, 6);
  rect(g, 32, 12, 4, 6);
  rect(g, 7, 20, 4, 5);
  rect(g, 32, 20, 4, 5);
  rect(g, 9, 2, 1, 12, "#");
  rect(g, 8, 6, 3, 2);
  rect(g, 33, 2, 1, 12, "#");
  rect(g, 32, 7, 3, 2);
  rect(g, 9, 23, 1, 11, "#");
  rect(g, 8, 27, 3, 2);
  rect(g, 33, 23, 1, 11, "#");
  rect(g, 32, 26, 3, 2);
  put(g, 5, 5, "S");
  put(g, 5, 9, "C");
  put(g, 12, 4, "H");
  put(g, 13, 10, "F");
  put(g, 29, 5, "K");
  put(g, 36, 4, "C");
  put(g, 37, 9, "B");
  put(g, 4, 26, "F");
  put(g, 13, 30, "C");
  put(g, 6, 30, "H");
  put(g, 29, 28, "G");
  put(g, 36, 25, "B");
  put(g, 37, 30, "$");
  put(g, 21, 18, "E");
  put(g, 12, 8, "A");
  put(g, 30, 9, "A");
  put(g, 21, 8, "A");
  put(g, 21, 27, "A");
  put(g, 8, 18, "A");
  put(g, 34, 18, "A");
  put(g, 6, 28, "A");
  put(g, 36, 28, "A");
  return g;
}

function mapYard(): string[][] {
  const g = grid(50, 34);
  rect(g, 1, 1, 48, 32);
  rect(g, 3, 3, 16, 12, "#");
  rect(g, 4, 4, 14, 10);
  rect(g, 9, 13, 4, 3);
  rect(g, 22, 3, 16, 10, "#");
  rect(g, 23, 4, 14, 8);
  rect(g, 28, 11, 4, 3);
  rect(g, 38, 8, 10, 14, "#");
  rect(g, 39, 9, 8, 12);
  rect(g, 36, 13, 4, 3);
  rect(g, 16, 21, 18, 9, "#");
  rect(g, 17, 22, 16, 7);
  rect(g, 22, 20, 4, 3);
  rect(g, 8, 18, 6, 1, "#");
  rect(g, 14, 24, 1, 6, "#");
  rect(g, 36, 22, 5, 1, "#");
  rect(g, 30, 16, 6, 1, "#");
  put(g, 7, 8, "S");
  put(g, 6, 6, "H");
  put(g, 12, 6, "F");
  put(g, 15, 10, "C");
  put(g, 26, 6, "K");
  put(g, 30, 6, "B");
  put(g, 33, 8, "B");
  put(g, 27, 9, "C");
  put(g, 42, 11, "$");
  put(g, 44, 16, "F");
  put(g, 41, 18, "C");
  put(g, 20, 24, "P");
  put(g, 28, 25, "C");
  put(g, 30, 23, "B");
  put(g, 24, 30, "E");
  put(g, 45, 22, "G");
  put(g, 26, 16, "A");
  put(g, 18, 17, "A");
  put(g, 34, 18, "A");
  put(g, 12, 20, "A");
  put(g, 40, 24, "A");
  put(g, 28, 8, "A");
  put(g, 43, 14, "A");
  put(g, 22, 25, "A");
  put(g, 32, 27, "A");
  put(g, 10, 28, "A");
  return g;
}

function bake(
  id: string,
  name: string,
  area: string,
  brief: string,
  difficulty: 1 | 2 | 3,
  time: number,
  keyId: string | undefined,
  rows: string[][],
  extracts: { ch: string; gated: "none" | "switch" | "key"; name: string }[],
  scav: GameMap["scav"],
): GameMap {
  const h = rows.length;
  const w = rows[0]?.length ?? 0;
  const tiles = new Uint8Array(w * h);
  const spawn = { x: TILE * 2, y: TILE * 2 };
  const scavs: GameMap["scavs"] = [];
  const containers: GameMap["containers"] = [];
  const ex: GameMap["extracts"] = [];
  const switches: GameMap["switches"] = [];
  const exMeta = new Map(extracts.map((e) => [e.ch, e]));
  let ci = 0;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const ch = rows[y]?.[x] ?? "#";
      const wall = ch === "#";
      tiles[y * w + x] = wall ? 1 : 0;
      const px = (x + 0.5) * TILE;
      const py = (y + 0.5) * TILE;
      if (ch === "S") {
        spawn.x = px;
        spawn.y = py;
      } else if (ch === "A") scavs.push({ x: px, y: py });
      else if (ch === "P") switches.push({ x: px, y: py });
      else if (ch === "E" || ch === "G") {
        const meta = exMeta.get(ch) ?? { ch, gated: "none" as const, name: "撤离点" };
        ex.push({ id: `${id}-${ch}-${ex.length}`, x: px, y: py, gated: meta.gated, name: meta.name });
      } else if (KIND[ch]) {
        containers.push({ id: `${id}-c${ci++}`, x: px, y: py, kind: KIND[ch] });
      }
    }
  }
  return {
    id,
    name,
    area,
    brief,
    difficulty,
    time,
    keyId,
    w,
    h,
    tiles,
    spawn,
    scavs,
    containers,
    extracts: ex,
    switches,
    scav,
  };
}

export const MAPS: GameMap[] = [
  bake(
    "docks",
    "苔石溪谷",
    "溪谷边境",
    "古老石桥横跨溪流，遗迹与灌木之间藏着第一批战利品。",
    1,
    360,
    undefined,
    mapDocks(),
    [
      { ch: "E", gated: "none", name: "栈桥" },
      { ch: "G", gated: "switch", name: "北门" },
    ],
    { hp: 46, dmg: 9, speed: 76, range: 300, cd: 0.95 },
  ),
  bake(
    "apts",
    "藤蔓法师塔",
    "旧王国遗迹",
    "被藤蔓吞没的石屋与法师塔连成一片，塔顶的封印需要古钥匙。",
    2,
    420,
    "key_apt",
    mapApts(),
    [
      { ch: "E", gated: "none", name: "临街出口" },
      { ch: "G", gated: "key", name: "天台门" },
    ],
    { hp: 62, dmg: 12, speed: 90, range: 340, cd: 0.82 },
  ),
  bake(
    "yard",
    "黑曜石要塞",
    "禁忌边境",
    "黑曜石城墙围住古老庭院，守卫更强，深处藏着高阶魔法遗物。",
    3,
    480,
    "key_yard",
    mapYard(),
    [
      { ch: "E", gated: "switch", name: "主闸" },
      { ch: "G", gated: "key", name: "侧门" },
    ],
    { hp: 78, dmg: 15, speed: 100, range: 380, cd: 0.7 },
  ),
];

export function mapById(id: string) {
  return MAPS.find((m) => m.id === id) ?? MAPS[0]!;
}

const TABLES: Record<Exclude<ContainerKind, "body" | "key">, [string, number][]> = {
  crate: [
    ["bolts", 5],
    ["soap", 4],
    ["canned", 4],
    ["circuit", 2],
    ["cable", 1],
    ["moonseed", 3],
    ["empty_flask", 2],
    ["captured_hare", 1],
  ],
  med: [
    ["bandage", 5],
    ["ifak", 2],
    ["pain", 3],
    ["soap", 1],
  ],
  weapon: [
    ["ammo9", 4],
    ["ammo545", 3],
    ["ammo762", 2],
    ["ammo12", 2],
    ["circuit", 2],
    ["pm", 1],
  ],
  duffel: [
    ["canned", 3],
    ["circuit", 3],
    ["cable", 2],
    ["chain", 2],
    ["doc", 1],
    ["hdd", 1],
  ],
  safe: [
    ["chain", 3],
    ["doc", 3],
    ["hdd", 3],
    ["gpu", 1],
    ["cable", 2],
  ],
};

function pick(table: [string, number][]) {
  const sum = table.reduce((n, row) => n + row[1], 0);
  let r = Math.random() * sum;
  for (const [id, w] of table) {
    r -= w;
    if (r <= 0) return id;
  }
  return table[0]?.[0] ?? "bolts";
}

export function rid() {
  return Math.random().toString(36).slice(2, 10);
}

export function makeItem(id: string, count?: number): Item {
  const d = ITEMS[id];
  if (!d) throw new Error(`unknown item ${id}`);
  const it: Item = { uid: rid(), defId: id, count: 1 };
  if (d.stack) it.count = Math.max(1, Math.min(d.stack, count ?? 1));
  if (d.dur) it.dur = d.dur;
  if (d.mag) it.mag = d.mag;
  return it;
}

export function rollContainer(kind: ContainerKind, map: GameMap): Item[] {
  if (kind === "body") {
    const out = [makeItem("dogtag", 1)];
    if (Math.random() < 0.55) {
      const ammo = map.difficulty >= 3 ? "ammo545" : "ammo9";
      out.push(makeItem(ammo, 8 + Math.floor(Math.random() * 16)));
    }
    return out;
  }
  if (kind === "key") {
    const out: Item[] = [];
    if (map.keyId) out.push(makeItem(map.keyId));
    out.push(makeItem(pick(TABLES.crate)));
    return out;
  }
  const table = TABLES[kind].slice();
  if (kind === "weapon" && map.difficulty >= 2) table.push(["kedr", 1]);
  if (kind === "weapon" && map.difficulty >= 3) table.push(["shottie", 1]);
  if (kind === "duffel" && map.difficulty >= 3) table.push(["gpu", 1]);
  const n = kind === "safe" ? 2 : kind === "med" ? 1 + (Math.random() < 0.5 ? 1 : 0) : 2;
  const out: Item[] = [];
  for (let i = 0; i < n; i++) {
    const id = pick(table);
    const def = ITEMS[id];
    if (!def) continue;
    if (def.cat === "ammo") out.push(makeItem(id, 12 + Math.floor(Math.random() * 24)));
    else if (def.stack) out.push(makeItem(id, 1));
    else out.push(makeItem(id));
  }
  return out;
}

export function levelOf(xp: number) {
  if (xp >= 280) return 3;
  if (xp >= 100) return 2;
  return 1;
}

export function levelName(level: number) {
  return level >= 3 ? "老手" : level === 2 ? "熟客" : "新承包商";
}

export function mapErrors(map: GameMap) {
  const errors: string[] = [];
  const { w, h, tiles } = map;
  const startTx = Math.floor(map.spawn.x / TILE);
  const startTy = Math.floor(map.spawn.y / TILE);
  if (tiles[startTy * w + startTx] === 1) errors.push(`${map.id} spawn in wall`);
  const seen = new Uint8Array(w * h);
  const q: [number, number][] = [[startTx, startTy]];
  seen[startTy * w + startTx] = 1;
  for (let i = 0; i < q.length; i++) {
    const [x, y] = q[i]!;
    for (const [dx, dy] of [
      [1, 0],
      [-1, 0],
      [0, 1],
      [0, -1],
    ]) {
      const nx = x + dx;
      const ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue;
      const k = ny * w + nx;
      if (seen[k] || tiles[k] === 1) continue;
      seen[k] = 1;
      q.push([nx, ny]);
    }
  }
  const check = (x: number, y: number, label: string) => {
    const tx = Math.floor(x / TILE);
    const ty = Math.floor(y / TILE);
    if (!seen[ty * w + tx]) errors.push(`${map.id} unreachable ${label}`);
  };
  map.extracts.forEach((e) => check(e.x, e.y, e.name));
  map.containers.forEach((c) => check(c.x, c.y, c.kind));
  map.switches.forEach((s, i) => check(s.x, s.y, `switch${i}`));
  map.scavs.forEach((s, i) => check(s.x, s.y, `scav${i}`));
  const far = map.scavs.some((s) => Math.hypot(s.x - map.spawn.x, s.y - map.spawn.y) < 180);
  if (far) errors.push(`${map.id} scav too close to spawn`);
  return errors;
}
