import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C2FvOUtv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var harbor_default = "/assets/harbor-Btdri7pi.jpg";
var ITEMS = {
	pm: {
		id: "pm",
		name: "马卡洛夫",
		cat: "weapon",
		slots: 2,
		weight: .73,
		sell: 2400,
		buy: 5200,
		rarity: "common",
		blurb: "短、轻、弹尽得快。新来的人靠它活过第一晚。",
		dmg: 22,
		rpm: 420,
		mag: 8,
		reload: 1.45,
		spread: .045,
		range: 460,
		ammo: "ammo9",
		dur: 100
	},
	kedr: {
		id: "kedr",
		name: "克林冲锋枪",
		cat: "weapon",
		slots: 3,
		weight: 1.55,
		sell: 9e3,
		buy: 16800,
		rarity: "uncommon",
		blurb: "近距离倾泻 9mm。压住走廊比瞄准更有用。",
		dmg: 12,
		rpm: 880,
		mag: 20,
		reload: 1.9,
		spread: .075,
		range: 400,
		ammo: "ammo9",
		dur: 100
	},
	ak: {
		id: "ak",
		name: "74式步枪",
		cat: "weapon",
		slots: 4,
		weight: 3.3,
		sell: 17e3,
		buy: 30500,
		rarity: "rare",
		blurb: "中距离的正经答案。后坐可控，弹道够直。",
		dmg: 28,
		rpm: 600,
		mag: 30,
		reload: 2.25,
		spread: .03,
		range: 640,
		ammo: "ammo545",
		dur: 100
	},
	shottie: {
		id: "shottie",
		name: "短管霰弹",
		cat: "weapon",
		slots: 3,
		weight: 2.5,
		sell: 15e3,
		buy: 27500,
		rarity: "rare",
		blurb: "转角就见分晓。距离一远，它只是噪声。",
		dmg: 8,
		rpm: 78,
		mag: 5,
		reload: 2.5,
		spread: .16,
		range: 280,
		pellets: 6,
		ammo: "ammo12",
		dur: 100
	},
	mosin: {
		id: "mosin",
		name: "栓动步枪",
		cat: "weapon",
		slots: 4,
		weight: 3.6,
		sell: 21e3,
		buy: 38e3,
		rarity: "legendary",
		blurb: "一发够用。空仓的时候你会听见自己的呼吸。",
		dmg: 74,
		rpm: 40,
		mag: 5,
		reload: 2.7,
		spread: .006,
		range: 880,
		ammo: "ammo762",
		dur: 100
	},
	paca: {
		id: "paca",
		name: "轻型防弹衣",
		cat: "armor",
		slots: 3,
		weight: 3.1,
		sell: 4200,
		buy: 9600,
		rarity: "common",
		blurb: "挡得住手枪，挡不住决心。",
		armor: .28,
		dur: 45
	},
	vest: {
		id: "vest",
		name: "制式防弹衣",
		cat: "armor",
		slots: 4,
		weight: 6.4,
		sell: 15e3,
		buy: 28e3,
		rarity: "uncommon",
		blurb: "海关标配。沉，但子弹会犹豫一下。",
		armor: .46,
		dur: 60
	},
	heavy: {
		id: "heavy",
		name: "重型插板",
		cat: "armor",
		slots: 4,
		weight: 9.2,
		sell: 3e4,
		buy: 52e3,
		rarity: "rare",
		blurb: "走路像背着一扇门。门后面是你。",
		armor: .62,
		dur: 75
	},
	ssh: {
		id: "ssh",
		name: "钢盔",
		cat: "helmet",
		slots: 2,
		weight: 1.4,
		sell: 5200,
		buy: 11500,
		rarity: "common",
		blurb: "旧钢，新伤。总比光着好。",
		armor: .16,
		dur: 32
	},
	mich: {
		id: "mich",
		name: "复合盔",
		cat: "helmet",
		slots: 2,
		weight: 1.25,
		sell: 17e3,
		buy: 32e3,
		rarity: "rare",
		blurb: "能买到它的人，通常已经不需要解释为什么。",
		armor: .3,
		dur: 42
	},
	bandage: {
		id: "bandage",
		name: "绷带",
		cat: "med",
		slots: 1,
		weight: .08,
		sell: 700,
		buy: 1500,
		buyCount: 1,
		rarity: "common",
		blurb: "慢，但能把血停在衣服里面。",
		stack: 4,
		heal: 34,
		use: 3.1
	},
	ifak: {
		id: "ifak",
		name: "急救包",
		cat: "med",
		slots: 1,
		weight: .32,
		sell: 2800,
		buy: 5400,
		rarity: "uncommon",
		blurb: "撕开，按住，继续跑。",
		stack: 2,
		heal: 70,
		use: 2.5
	},
	pain: {
		id: "pain",
		name: "止痛针",
		cat: "med",
		slots: 1,
		weight: .05,
		sell: 1800,
		buy: 3600,
		rarity: "uncommon",
		blurb: "不治伤。只是让腿暂时忘记这件事。",
		stack: 3,
		heal: 0,
		use: 1.15,
		buff: 18
	},
	ammo9: {
		id: "ammo9",
		name: "9mm 弹",
		cat: "ammo",
		slots: 1,
		weight: .012,
		sell: 22,
		buy: 1100,
		buyCount: 30,
		rarity: "common",
		blurb: "马卡洛夫和克林的口粮。",
		stack: 60
	},
	ammo545: {
		id: "ammo545",
		name: "5.45 弹",
		cat: "ammo",
		slots: 1,
		weight: .012,
		sell: 34,
		buy: 1600,
		buyCount: 30,
		rarity: "uncommon",
		blurb: "步枪吃这个。",
		stack: 60
	},
	ammo762: {
		id: "ammo762",
		name: "7.62 弹",
		cat: "ammo",
		slots: 1,
		weight: .018,
		sell: 55,
		buy: 1800,
		buyCount: 20,
		rarity: "rare",
		blurb: "栓动步枪的五发，每一发都贵。",
		stack: 40
	},
	ammo12: {
		id: "ammo12",
		name: "12 号霰弹",
		cat: "ammo",
		slots: 1,
		weight: .038,
		sell: 48,
		buy: 1400,
		buyCount: 10,
		rarity: "uncommon",
		blurb: "近处很吵，远处没用。",
		stack: 20
	},
	soap: {
		id: "soap",
		name: "海军肥皂",
		cat: "loot",
		slots: 1,
		weight: .22,
		sell: 1900,
		rarity: "common",
		blurb: "港区还能用的干净东西不多，这是一件。"
	},
	bolts: {
		id: "bolts",
		name: "锈螺栓",
		cat: "loot",
		slots: 1,
		weight: .45,
		sell: 2400,
		rarity: "common",
		blurb: "商人拿去修船，你拿去换子弹。"
	},
	canned: {
		id: "canned",
		name: "压缩口粮",
		cat: "loot",
		slots: 1,
		weight: .36,
		sell: 2800,
		rarity: "common",
		blurb: "标签掉了。味道还在。"
	},
	circuit: {
		id: "circuit",
		name: "破损电路板",
		cat: "loot",
		slots: 1,
		weight: .16,
		sell: 5600,
		rarity: "uncommon",
		blurb: "烧毁了一半，剩下那半值钱。"
	},
	cable: {
		id: "cable",
		name: "军用电缆",
		cat: "loot",
		slots: 2,
		weight: .95,
		sell: 8200,
		rarity: "uncommon",
		blurb: "沉。藏身处的发电机喜欢这个。"
	},
	chain: {
		id: "chain",
		name: "镀金项链",
		cat: "loot",
		slots: 1,
		weight: .08,
		sell: 15e3,
		rarity: "rare",
		blurb: "原来的主人没能带走它。"
	},
	doc: {
		id: "doc",
		name: "机密文件",
		cat: "loot",
		slots: 1,
		weight: .06,
		sell: 12e3,
		rarity: "rare",
		blurb: "海关印章还没干。别在战区里读。"
	},
	hdd: {
		id: "hdd",
		name: "加密硬盘",
		cat: "loot",
		slots: 1,
		weight: .28,
		sell: 24e3,
		rarity: "rare",
		blurb: "打不开。所以更贵。"
	},
	gpu: {
		id: "gpu",
		name: "实验显卡",
		cat: "loot",
		slots: 2,
		weight: .62,
		sell: 52e3,
		rarity: "legendary",
		blurb: "港区只流通过几块。看见就别犹豫。"
	},
	dogtag: {
		id: "dogtag",
		name: "身份牌",
		cat: "loot",
		slots: 1,
		weight: .04,
		sell: 1600,
		rarity: "uncommon",
		blurb: "搜刮者的收据。"
	},
	key_apt: {
		id: "key_apt",
		name: "公寓钥匙",
		cat: "key",
		slots: 1,
		weight: .05,
		sell: 4500,
		rarity: "uncommon",
		blurb: "天台门的齿纹还在。"
	},
	key_yard: {
		id: "key_yard",
		name: "侧门通行证",
		cat: "key",
		slots: 1,
		weight: .05,
		sell: 6800,
		rarity: "rare",
		blurb: "塑料卡片，磁条快磨没了。侧门还认它。"
	}
};
var TRADER = [
	{
		id: "pm",
		level: 1
	},
	{
		id: "kedr",
		level: 1
	},
	{
		id: "paca",
		level: 1
	},
	{
		id: "bandage",
		level: 1
	},
	{
		id: "pain",
		level: 1
	},
	{
		id: "ammo9",
		level: 1
	},
	{
		id: "ifak",
		level: 2
	},
	{
		id: "ssh",
		level: 2
	},
	{
		id: "vest",
		level: 2
	},
	{
		id: "ak",
		level: 2
	},
	{
		id: "ammo545",
		level: 2
	},
	{
		id: "shottie",
		level: 3
	},
	{
		id: "ammo12",
		level: 3
	},
	{
		id: "mosin",
		level: 3
	},
	{
		id: "ammo762",
		level: 3
	},
	{
		id: "heavy",
		level: 3
	},
	{
		id: "mich",
		level: 3
	}
];
var UPGRADES = [
	{
		key: "power",
		level: 1,
		cost: 15e3,
		name: "柴油发电机",
		desc: "负重提高，并解锁二级设施。",
		needPower: false
	},
	{
		key: "med",
		level: 1,
		cost: 7e3,
		name: "医疗角",
		desc: "战区里包扎更快。",
		needPower: false
	},
	{
		key: "med",
		level: 2,
		cost: 19e3,
		name: "医疗角 II",
		desc: "包扎再缩短一截。",
		needPower: true
	},
	{
		key: "bench",
		level: 1,
		cost: 8500,
		name: "工作台",
		desc: "商人便宜一成，仓库变大，可以保养枪械。",
		needPower: false
	},
	{
		key: "bench",
		level: 2,
		cost: 23e3,
		name: "工作台 II",
		desc: "进货再便宜，点射更稳。",
		needPower: true
	},
	{
		key: "case",
		level: 1,
		cost: 13e3,
		name: "安全箱扩容",
		desc: "安全格 +1。死了也带得走。",
		needPower: false
	},
	{
		key: "case",
		level: 2,
		cost: 28e3,
		name: "安全箱扩容 II",
		desc: "安全格再 +1。",
		needPower: true
	}
];
var KIND = {
	C: "crate",
	H: "med",
	B: "weapon",
	F: "duffel",
	$: "safe",
	K: "key"
};
function grid(w, h) {
	return Array.from({ length: h }, () => Array.from({ length: w }, () => "#"));
}
function rect(g, x, y, w, h, ch = ".") {
	for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
		const row = g[y + j];
		if (row && row[x + i] !== void 0) row[x + i] = ch;
	}
}
function put(g, x, y, ch) {
	const row = g[y];
	if (!row || row[x] === void 0) return;
	if (row[x] === "#") row[x] = ".";
	row[x] = ch;
}
function mapDocks() {
	const g = grid(46, 30);
	rect(g, 2, 18, 12, 9);
	rect(g, 6, 12, 4, 8);
	rect(g, 2, 3, 14, 11);
	rect(g, 14, 7, 6, 5);
	rect(g, 18, 4, 22, 18);
	rect(g, 22, 11, 8, 1, "#");
	rect(g, 32, 15, 1, 5, "#");
	rect(g, 30, 2, 13, 6);
	rect(g, 34, 18, 10, 9);
	put(g, 5, 22, "S");
	put(g, 4, 6, "H");
	put(g, 8, 8, "F");
	put(g, 11, 5, "C");
	put(g, 21, 8, "C");
	put(g, 23, 8, "C");
	put(g, 26, 14, "C");
	put(g, 28, 17, "C");
	put(g, 34, 9, "B");
	put(g, 36, 9, "B");
	put(g, 20, 18, "F");
	put(g, 38, 23, "F");
	put(g, 40, 20, "C");
	put(g, 33, 4, "P");
	put(g, 38, 4, "G");
	put(g, 40, 24, "E");
	put(g, 24, 9, "A");
	put(g, 30, 13, "A");
	put(g, 36, 16, "A");
	put(g, 22, 19, "A");
	put(g, 39, 22, "A");
	return g;
}
function mapApts() {
	const g = grid(43, 36);
	rect(g, 19, 1, 5, 34);
	rect(g, 1, 16, 41, 5);
	rect(g, 2, 2, 15, 12);
	rect(g, 26, 2, 15, 12);
	rect(g, 2, 23, 15, 11);
	rect(g, 26, 23, 15, 11);
	rect(g, 15, 6, 5, 3);
	rect(g, 23, 6, 5, 3);
	rect(g, 7, 12, 4, 6);
	rect(g, 32, 12, 4, 6);
	rect(g, 7, 20, 4, 5);
	rect(g, 32, 20, 4, 5);
	rect(g, 9, 2, 1, 12, "#");
	rect(g, 8, 6, 3, 2);
	rect(g, 33, 2, 1, 12, "#");
	rect(g, 32, 7, 3, 2);
	rect(g, 9, 23, 1, 11, "#");
	rect(g, 8, 27, 3, 2);
	rect(g, 33, 23, 1, 11, "#");
	rect(g, 32, 26, 3, 2);
	put(g, 5, 5, "S");
	put(g, 5, 9, "C");
	put(g, 12, 4, "H");
	put(g, 13, 10, "F");
	put(g, 29, 5, "K");
	put(g, 36, 4, "C");
	put(g, 37, 9, "B");
	put(g, 4, 26, "F");
	put(g, 13, 30, "C");
	put(g, 6, 30, "H");
	put(g, 29, 28, "G");
	put(g, 36, 25, "B");
	put(g, 37, 30, "$");
	put(g, 21, 18, "E");
	put(g, 12, 8, "A");
	put(g, 30, 9, "A");
	put(g, 21, 8, "A");
	put(g, 21, 27, "A");
	put(g, 8, 18, "A");
	put(g, 34, 18, "A");
	put(g, 6, 28, "A");
	put(g, 36, 28, "A");
	return g;
}
function mapYard() {
	const g = grid(50, 34);
	rect(g, 1, 1, 48, 32);
	rect(g, 3, 3, 16, 12, "#");
	rect(g, 4, 4, 14, 10);
	rect(g, 9, 13, 4, 3);
	rect(g, 22, 3, 16, 10, "#");
	rect(g, 23, 4, 14, 8);
	rect(g, 28, 11, 4, 3);
	rect(g, 38, 8, 10, 14, "#");
	rect(g, 39, 9, 8, 12);
	rect(g, 36, 13, 4, 3);
	rect(g, 16, 21, 18, 9, "#");
	rect(g, 17, 22, 16, 7);
	rect(g, 22, 20, 4, 3);
	rect(g, 8, 18, 6, 1, "#");
	rect(g, 14, 24, 1, 6, "#");
	rect(g, 36, 22, 5, 1, "#");
	rect(g, 30, 16, 6, 1, "#");
	put(g, 7, 8, "S");
	put(g, 6, 6, "H");
	put(g, 12, 6, "F");
	put(g, 15, 10, "C");
	put(g, 26, 6, "K");
	put(g, 30, 6, "B");
	put(g, 33, 8, "B");
	put(g, 27, 9, "C");
	put(g, 42, 11, "$");
	put(g, 44, 16, "F");
	put(g, 41, 18, "C");
	put(g, 20, 24, "P");
	put(g, 28, 25, "C");
	put(g, 30, 23, "B");
	put(g, 24, 30, "E");
	put(g, 45, 22, "G");
	put(g, 26, 16, "A");
	put(g, 18, 17, "A");
	put(g, 34, 18, "A");
	put(g, 12, 20, "A");
	put(g, 40, 24, "A");
	put(g, 28, 8, "A");
	put(g, 43, 14, "A");
	put(g, 22, 25, "A");
	put(g, 32, 27, "A");
	put(g, 10, 28, "A");
	return g;
}
function bake(id, name, area, brief, difficulty, time, keyId, rows, extracts, scav) {
	const h = rows.length;
	const w = rows[0]?.length ?? 0;
	const tiles = new Uint8Array(w * h);
	const spawn = {
		x: 96,
		y: 96
	};
	const scavs = [];
	const containers = [];
	const ex = [];
	const switches = [];
	const exMeta = new Map(extracts.map((e) => [e.ch, e]));
	let ci = 0;
	for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
		const ch = rows[y]?.[x] ?? "#";
		const wall = ch === "#";
		tiles[y * w + x] = wall ? 1 : 0;
		const px = (x + .5) * 48;
		const py = (y + .5) * 48;
		if (ch === "S") {
			spawn.x = px;
			spawn.y = py;
		} else if (ch === "A") scavs.push({
			x: px,
			y: py
		});
		else if (ch === "P") switches.push({
			x: px,
			y: py
		});
		else if (ch === "E" || ch === "G") {
			const meta = exMeta.get(ch) ?? {
				ch,
				gated: "none",
				name: "撤离点"
			};
			ex.push({
				id: `${id}-${ch}-${ex.length}`,
				x: px,
				y: py,
				gated: meta.gated,
				name: meta.name
			});
		} else if (KIND[ch]) containers.push({
			id: `${id}-c${ci++}`,
			x: px,
			y: py,
			kind: KIND[ch]
		});
	}
	return {
		id,
		name,
		area,
		brief,
		difficulty,
		time,
		keyId,
		w,
		h,
		tiles,
		spawn,
		scavs,
		containers,
		extracts: ex,
		switches,
		scav
	};
}
var MAPS = [
	bake("docks", "南码头", "仓库区", "灯还亮着的栈桥，和一扇要先拉闸的北门。适合把流程走熟。", 1, 360, void 0, mapDocks(), [{
		ch: "E",
		gated: "none",
		name: "栈桥"
	}, {
		ch: "G",
		gated: "switch",
		name: "北门"
	}], {
		hp: 46,
		dmg: 9,
		speed: 76,
		range: 300,
		cd: .95
	}),
	bake("apts", "旧居民楼", "临街", "十字路口随时有人。天台门要钥匙，保险箱在最里面那间。", 2, 420, "key_apt", mapApts(), [{
		ch: "E",
		gated: "none",
		name: "临街出口"
	}, {
		ch: "G",
		gated: "key",
		name: "天台门"
	}], {
		hp: 62,
		dmg: 12,
		speed: 90,
		range: 340,
		cd: .82
	}),
	bake("yard", "海关检查站", "露天堆场", "空地很宽，掩体很薄。主闸要拉电闸，侧门认通行证。", 3, 480, "key_yard", mapYard(), [{
		ch: "E",
		gated: "switch",
		name: "主闸"
	}, {
		ch: "G",
		gated: "key",
		name: "侧门"
	}], {
		hp: 78,
		dmg: 15,
		speed: 100,
		range: 380,
		cd: .7
	})
];
function mapById(id) {
	return MAPS.find((m) => m.id === id) ?? MAPS[0];
}
var TABLES = {
	crate: [
		["bolts", 5],
		["soap", 4],
		["canned", 4],
		["circuit", 2],
		["cable", 1]
	],
	med: [
		["bandage", 5],
		["ifak", 2],
		["pain", 3],
		["soap", 1]
	],
	weapon: [
		["ammo9", 4],
		["ammo545", 3],
		["ammo762", 2],
		["ammo12", 2],
		["circuit", 2],
		["pm", 1]
	],
	duffel: [
		["canned", 3],
		["circuit", 3],
		["cable", 2],
		["chain", 2],
		["doc", 1],
		["hdd", 1]
	],
	safe: [
		["chain", 3],
		["doc", 3],
		["hdd", 3],
		["gpu", 1],
		["cable", 2]
	]
};
function pick(table) {
	const sum = table.reduce((n, row) => n + row[1], 0);
	let r = Math.random() * sum;
	for (const [id, w] of table) {
		r -= w;
		if (r <= 0) return id;
	}
	return table[0]?.[0] ?? "bolts";
}
function rid() {
	return Math.random().toString(36).slice(2, 10);
}
function makeItem(id, count) {
	const d = ITEMS[id];
	if (!d) throw new Error(`unknown item ${id}`);
	const it = {
		uid: rid(),
		defId: id,
		count: 1
	};
	if (d.stack) it.count = Math.max(1, Math.min(d.stack, count ?? 1));
	if (d.dur) it.dur = d.dur;
	if (d.mag) it.mag = d.mag;
	return it;
}
function rollContainer(kind, map) {
	if (kind === "body") {
		const out = [makeItem("dogtag", 1)];
		if (Math.random() < .55) {
			const ammo = map.difficulty >= 3 ? "ammo545" : "ammo9";
			out.push(makeItem(ammo, 8 + Math.floor(Math.random() * 16)));
		}
		return out;
	}
	if (kind === "key") {
		const out = [];
		if (map.keyId) out.push(makeItem(map.keyId));
		out.push(makeItem(pick(TABLES.crate)));
		return out;
	}
	const table = TABLES[kind].slice();
	if (kind === "weapon" && map.difficulty >= 2) table.push(["kedr", 1]);
	if (kind === "weapon" && map.difficulty >= 3) table.push(["shottie", 1]);
	if (kind === "duffel" && map.difficulty >= 3) table.push(["gpu", 1]);
	const n = kind === "safe" ? 2 : kind === "med" ? 1 + (Math.random() < .5 ? 1 : 0) : 2;
	const out = [];
	for (let i = 0; i < n; i++) {
		const id = pick(table);
		const def = ITEMS[id];
		if (!def) continue;
		if (def.cat === "ammo") out.push(makeItem(id, 12 + Math.floor(Math.random() * 24)));
		else if (def.stack) out.push(makeItem(id, 1));
		else out.push(makeItem(id));
	}
	return out;
}
function levelOf(xp) {
	if (xp >= 280) return 3;
	if (xp >= 100) return 2;
	return 1;
}
function levelName(level) {
	return level >= 3 ? "老手" : level === 2 ? "熟客" : "新承包商";
}
function defOf(it) {
	return ITEMS[it.defId];
}
function slotsOf(items) {
	return items.reduce((n, it) => n + (defOf(it)?.slots ?? 1), 0);
}
function unitWeight(it) {
	const d = defOf(it);
	if (!d) return 0;
	return d.stack ? d.weight * it.count : d.weight;
}
function listWeight(items) {
	return items.reduce((n, it) => n + unitWeight(it), 0);
}
function gearList(gear) {
	return [
		gear.weapon,
		gear.armor,
		gear.helmet
	].filter((it) => !!it);
}
function carryWeight(gear, pack, secure) {
	return listWeight([
		...gearList(gear),
		...pack,
		...secure
	]);
}
function sellValue(it) {
	const d = defOf(it);
	if (!d) return 0;
	if (d.stack) return Math.round(d.sell * it.count);
	const ratio = d.dur && it.dur != null ? it.dur / d.dur : 1;
	return Math.round(d.sell * (.4 + .6 * Math.max(0, Math.min(1, ratio))));
}
function caps(save) {
	return {
		stash: 28 + save.hideout.bench * 6,
		pack: 10 + (save.hideout.power ? 2 : 0),
		secure: 2 + save.hideout.case,
		weight: 12 + (save.hideout.power ? 3 : 0)
	};
}
function buyPrice(save, id) {
	const d = ITEMS[id];
	if (!d?.buy) return 0;
	const cut = save.hideout.bench >= 2 ? .8 : save.hideout.bench >= 1 ? .9 : 1;
	return Math.round(d.buy * cut);
}
function moveItem(from, to, uid, toCap) {
	const i = from.findIndex((x) => x.uid === uid);
	if (i < 0) return false;
	const it = from[i];
	const d = defOf(it);
	if (!d) return false;
	if (d.stack) {
		const dest = to.find((x) => x.defId === it.defId && x.count + it.count <= (d.stack ?? 1));
		if (dest) {
			dest.count += it.count;
			from.splice(i, 1);
			return true;
		}
	}
	if (slotsOf(to) + d.slots > toCap) return false;
	from.splice(i, 1);
	to.push(it);
	return true;
}
function insuranceCost(save) {
	return Math.round(gearList(save.equipped).reduce((n, it) => n + sellValue(it), 0) * .28);
}
function slotOf(cat) {
	if (cat === "weapon") return "weapon";
	if (cat === "armor") return "armor";
	if (cat === "helmet") return "helmet";
	return null;
}
function lists(save) {
	return [
		{
			name: "stash",
			items: save.stash
		},
		{
			name: "pack",
			items: save.pack
		},
		{
			name: "secure",
			items: save.secure
		}
	];
}
function equipItem(save, uid) {
	let fromName = null;
	let it;
	for (const list of lists(save)) {
		const found = list.items.find((x) => x.uid === uid);
		if (found) {
			it = found;
			fromName = list.name;
			break;
		}
	}
	if (!it || !fromName) return "找不到这件东西";
	const d = defOf(it);
	const slot = d ? slotOf(d.cat) : null;
	if (!slot || !d) return "这件不能装备";
	const prev = save.equipped[slot];
	if (prev) {
		if (![
			fromName,
			"stash",
			"pack",
			"secure"
		].some((name) => {
			return slotsOf(name === fromName ? save[name].filter((x) => x.uid !== uid) : save[name]) + (defOf(prev)?.slots ?? 1) <= caps(save)[name];
		})) return "没有空位放下原来的装备";
	}
	save[fromName] = save[fromName].filter((x) => x.uid !== uid);
	if (prev) {
		const order = [
			fromName,
			"stash",
			"pack",
			"secure"
		];
		let parked = false;
		for (const name of order) if (moveItem([prev], save[name], prev.uid, caps(save)[name])) {
			parked = true;
			break;
		}
		if (!parked) {
			save[fromName].push(it);
			return "没有空位放下原来的装备";
		}
	}
	save.equipped[slot] = it;
	return null;
}
function unequipItem(save, slot, dest) {
	const it = save.equipped[slot];
	if (!it) return null;
	const cap = caps(save)[dest];
	if (!moveItem([it], save[dest], it.uid, cap)) return dest === "pack" ? "背包满了" : "仓库满了";
	save.equipped[slot] = null;
	return null;
}
var KEY = "rustbay-save-v1";
function starter(id, uid, count = 1) {
	const d = ITEMS[id];
	if (!d) throw new Error(id);
	const it = {
		uid,
		defId: id,
		count
	};
	if (d.dur) it.dur = d.dur;
	if (d.mag) it.mag = d.mag;
	return it;
}
function freshSave() {
	return {
		version: 1,
		rubles: 7600,
		xp: 0,
		raids: 0,
		extracts: 0,
		kills: 0,
		deaths: 0,
		stash: [
			starter("soap", "st-soap"),
			starter("bolts", "st-bolts"),
			starter("canned", "st-can"),
			starter("ammo9", "st-ammo", 20)
		],
		pack: [starter("bandage", "st-ban", 2), starter("ammo9", "st-mag", 32)],
		secure: [],
		equipped: {
			weapon: starter("pm", "st-pm"),
			armor: starter("paca", "st-paca"),
			helmet: null
		},
		hideout: {
			med: 0,
			bench: 0,
			power: 0,
			case: 0
		},
		mail: [],
		pending: null,
		log: "南码头的灯还亮着。带上枪，活着回来。",
		sfx: .7
	};
}
function resolvePending(save) {
	if (!save.pending) return save;
	const next = {
		...save,
		secure: save.pending.secure.map((it) => ({ ...it })),
		pack: [],
		mail: save.mail.slice(),
		equipped: {
			weapon: save.equipped.weapon ? { ...save.equipped.weapon } : null,
			armor: save.equipped.armor ? { ...save.equipped.armor } : null,
			helmet: save.equipped.helmet ? { ...save.equipped.helmet } : null
		},
		pending: null,
		deaths: save.deaths + 1,
		raids: save.raids + 1
	};
	if (save.pending.insuredGear?.length) {
		next.mail = next.mail.concat(save.pending.insuredGear.map((it) => ({ ...it })));
		next.equipped = {
			weapon: null,
			armor: null,
			helmet: null
		};
		next.log = "上次联络中断。上了保险的装备退回了邮箱，背包里的东西没了。";
	} else {
		next.equipped = {
			weapon: null,
			armor: null,
			helmet: null
		};
		next.log = "上次没能撤离。带进去的装备和搜到的东西都留在湾里了。";
	}
	const net = safetyNet(next);
	if (net.logNote) net.save.log = `${net.save.log}${net.logNote}`;
	return net.save;
}
function loadSave() {
	try {
		const raw = localStorage.getItem(KEY);
		if (!raw) return freshSave();
		const data = JSON.parse(raw);
		if (!data || data.version !== 1) return freshSave();
		const base = freshSave();
		return resolvePending({
			...base,
			...data,
			stash: Array.isArray(data.stash) ? data.stash : [],
			pack: Array.isArray(data.pack) ? data.pack : [],
			secure: Array.isArray(data.secure) ? data.secure : [],
			mail: Array.isArray(data.mail) ? data.mail : [],
			equipped: {
				...base.equipped,
				...data.equipped ?? {}
			},
			hideout: {
				...base.hideout,
				...data.hideout ?? {}
			},
			pending: data.pending ?? null,
			version: 1
		});
	} catch {
		return freshSave();
	}
}
function writeSave(save) {
	try {
		const backup = localStorage.getItem(KEY);
		if (backup) localStorage.setItem(`${KEY}-bak`, backup);
		localStorage.setItem(KEY, JSON.stringify(save));
	} catch {}
}
function cloneGear(g) {
	return {
		weapon: g.weapon ? { ...g.weapon } : null,
		armor: g.armor ? { ...g.armor } : null,
		helmet: g.helmet ? { ...g.helmet } : null
	};
}
function beginRaid(save, mapId, insure) {
	const cost = insuranceCost(save);
	if (insure && save.rubles < cost) return { error: "卢布不够付保险" };
	const cap = caps(save);
	if (slotsOf(save.pack) > cap.pack) return { error: "背包超格，先拿回仓库" };
	if (carryWeight(save.equipped, save.pack, save.secure) > cap.weight + 6) return { error: "负重太高，先卸掉一些" };
	const gear = cloneGear(save.equipped);
	const setup = {
		mapId,
		gear: cloneGear(gear),
		pack: save.pack.map((it) => ({ ...it })),
		secure: save.secure.map((it) => ({ ...it })),
		insure,
		healMul: save.hideout.med >= 2 ? .68 : save.hideout.med >= 1 ? .84 : 1,
		spreadMul: save.hideout.bench >= 2 ? .88 : 1,
		packCap: cap.pack,
		secureCap: cap.secure,
		weightLimit: cap.weight
	};
	return {
		save: {
			...save,
			rubles: save.rubles - (insure ? cost : 0),
			pack: [],
			secure: [],
			equipped: insure ? {
				weapon: null,
				armor: null,
				helmet: null
			} : cloneGear(save.equipped),
			pending: {
				secure: save.secure.map((it) => ({ ...it })),
				insuredGear: insure ? [
					gear.weapon,
					gear.armor,
					gear.helmet
				].filter((it) => !!it).map((it) => ({ ...it })) : null
			}
		},
		setup
	};
}
function hurtGear(items) {
	return items.map((it) => {
		if (!ITEMS[it.defId]?.dur || it.dur == null) return { ...it };
		return {
			...it,
			dur: Math.max(8, it.dur - 18)
		};
	});
}
function finishRaid(save, setup, result) {
	const map = mapById(setup.mapId);
	const brought = new Set([
		...setup.pack,
		...setup.secure,
		setup.gear.weapon,
		setup.gear.armor,
		setup.gear.helmet
	].filter((it) => !!it).map((it) => it.uid));
	const gained = [...result.pack, ...result.secure].filter((it) => !brought.has(it.uid));
	const lootValue = result.outcome === "extract" ? gained.reduce((n, it) => n + sellValue(it), 0) : 0;
	const xp = result.outcome === "extract" ? 45 + result.kills * 12 + Math.floor(lootValue / 900) : result.kills * 5;
	const next = {
		...save,
		xp: save.xp + xp,
		kills: save.kills + result.kills,
		raids: save.raids + 1,
		pending: null,
		secure: result.secure.map((it) => ({ ...it })),
		mail: save.mail.slice()
	};
	let kept = [];
	let lost = [];
	let returned = [];
	let note = "";
	if (result.outcome === "extract") {
		next.extracts += 1;
		next.pack = result.pack.map((it) => ({ ...it }));
		next.equipped = {
			weapon: result.equipped.weapon ? { ...result.equipped.weapon } : null,
			armor: result.equipped.armor ? { ...result.equipped.armor } : null,
			helmet: result.equipped.helmet ? { ...result.equipped.helmet } : null
		};
		kept = [
			...next.pack,
			...gearItems(next.equipped),
			...next.secure
		];
		note = lootValue > 0 ? `活着离开${map.name}。新带出的东西大约值 ${lootValue.toLocaleString("zh-CN")} 卢布，得卖了才算数。` : `活着离开${map.name}。口袋没鼓，但人还在。`;
	} else {
		next.deaths += 1;
		next.pack = [];
		next.equipped = {
			weapon: null,
			armor: null,
			helmet: null
		};
		lost = result.pack.map((it) => ({ ...it }));
		const gear = [
			result.equipped.weapon,
			result.equipped.armor,
			result.equipped.helmet
		].filter((it) => !!it);
		if (setup.insure && gear.length) {
			returned = hurtGear(gear);
			next.mail = next.mail.concat(returned.map((it) => ({ ...it })));
			note = result.outcome === "mia" ? "时间到了，你被留在雾里。保险会把装备退回，搜到的不会。" : "你倒在湾里。上了保险的装备会退回邮箱，其余的留在原地。";
		} else {
			lost = lost.concat(gear.map((it) => ({ ...it })));
			note = result.outcome === "mia" ? "时间耗尽。没保险，带进去的一切都不是你的了。" : "没有撤离，就没有战利品。枪也留在那里了。";
		}
		kept = next.secure.map((it) => ({ ...it }));
	}
	const net = safetyNet(next);
	if (net.logNote) note = `${note}${net.logNote}`;
	next.log = note;
	const debrief = {
		outcome: result.outcome,
		mapName: map.name,
		kills: result.kills,
		xp,
		lootValue,
		kept,
		lost,
		returned,
		note
	};
	return {
		save: net.save,
		debrief
	};
}
function gearItems(g) {
	return [
		g.weapon,
		g.armor,
		g.helmet
	].filter((it) => !!it);
}
function safetyNet(save) {
	if (![
		save.equipped.weapon,
		...save.stash,
		...save.pack,
		...save.secure,
		...save.mail
	].some((it) => it && ITEMS[it.defId]?.cat === "weapon") && save.rubles < 4800) {
		const gun = makeItem("pm");
		save.equipped.weapon = gun;
		save.pack = save.pack.concat([makeItem("ammo9", 24)]);
		save.rubles += 1800;
		return {
			save,
			logNote: " 黑市留了一支马卡洛夫和一点路费。"
		};
	}
	return {
		save,
		logNote: ""
	};
}
function sellStashItem(save, uid) {
	const it = save.stash.find((x) => x.uid === uid);
	if (!it) return "仓库里没有这件";
	save.stash = save.stash.filter((x) => x.uid !== uid);
	save.rubles += sellValue(it);
	return null;
}
function buyItem(save, id) {
	const d = ITEMS[id];
	if (!d?.buy) return "商人不卖这个";
	if (levelOf(save.xp) < (TRADER_LEVEL[id] ?? 1)) return "等级不够";
	const price = buyPrice(save, id);
	if (save.rubles < price) return "卢布不够";
	const it = makeItem(id, d.buyCount ?? 1);
	if (slotsOf(save.stash) + d.slots > caps(save).stash) return "仓库满了";
	save.rubles -= price;
	save.stash = save.stash.concat(it);
	return null;
}
var TRADER_LEVEL = {
	pm: 1,
	kedr: 1,
	paca: 1,
	bandage: 1,
	pain: 1,
	ammo9: 1,
	ifak: 2,
	ssh: 2,
	vest: 2,
	ak: 2,
	ammo545: 2,
	shottie: 3,
	ammo12: 3,
	mosin: 3,
	ammo762: 3,
	heavy: 3,
	mich: 3
};
function claimMail(save) {
	if (!save.mail.length) return null;
	const left = [];
	for (const it of save.mail) {
		const d = ITEMS[it.defId];
		const slot = d?.cat === "weapon" ? "weapon" : d?.cat === "armor" ? "armor" : d?.cat === "helmet" ? "helmet" : null;
		if (slot && !save.equipped[slot]) {
			save.equipped[slot] = it;
			continue;
		}
		if (slotsOf(save.stash) + (d?.slots ?? 1) <= caps(save).stash) save.stash.push(it);
		else left.push(it);
	}
	save.mail = left;
	return left.length ? "仓库满了，还有东西在邮箱里" : null;
}
function repairGear(save) {
	if (save.hideout.bench < 1) return "先建工作台";
	const items = gearItems(save.equipped);
	let cost = 0;
	for (const it of items) {
		const d = ITEMS[it.defId];
		if (!d?.dur || it.dur == null) continue;
		const missing = 1 - it.dur / d.dur;
		if (missing <= .02) continue;
		cost += Math.round(600 + missing * d.sell * .18);
	}
	if (cost <= 0) return "装备还很新";
	if (save.rubles < cost) return `保养要 ${cost} 卢布`;
	save.rubles -= cost;
	for (const it of items) {
		const d = ITEMS[it.defId];
		if (d?.dur) it.dur = d.dur;
	}
	return null;
}
function repairCost(save) {
	let cost = 0;
	for (const it of gearItems(save.equipped)) {
		const d = ITEMS[it.defId];
		if (!d?.dur || it.dur == null) continue;
		const missing = 1 - it.dur / d.dur;
		if (missing <= .02) continue;
		cost += Math.round(600 + missing * d.sell * .18);
	}
	return cost;
}
var TABS = [
	{
		id: "brief",
		label: "简报"
	},
	{
		id: "stash",
		label: "仓库"
	},
	{
		id: "gear",
		label: "装备"
	},
	{
		id: "trader",
		label: "商人"
	},
	{
		id: "base",
		label: "藏身处"
	},
	{
		id: "raid",
		label: "出击"
	}
];
function Hideout({ save, setSave, onDeploy, toast }) {
	const [tab, setTab] = (0, import_react.useState)("brief");
	const [insure, setInsure] = (0, import_react.useState)(false);
	const level = levelOf(save.xp);
	const cap = caps(save);
	const weight = carryWeight(save.equipped, save.pack, save.secure);
	const rate = save.raids ? Math.round(save.extracts / save.raids * 100) : 0;
	const premium = insuranceCost(save);
	function commit(mut) {
		const draft = structuredClone(save);
		const err = mut(draft);
		if (err) toast(err);
		else setSave(draft);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto min-h-dvh max-w-5xl px-3 py-4 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "overflow-hidden border border-line bg-surface",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative h-36 sm:h-48",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: harbor_default,
							alt: "",
							className: "h-full w-full object-cover"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-bg via-bg/40 to-transparent" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute bottom-3 left-4 right-4 flex items-end justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "font-mono text-xs tracking-widest text-amber",
								children: "RUST BAY"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "text-3xl leading-none",
								children: "锈湾"
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "font-mono text-lg text-amber",
									children: [save.rubles.toLocaleString("zh-CN"), " ₽"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "text-xs text-muted",
									children: [
										levelName(level),
										" · ",
										level,
										" 级"
									]
								})]
							})]
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "mt-3 flex gap-1 overflow-x-auto border-b border-line",
				"aria-label": "藏身处",
				children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: `min-h-11 shrink-0 px-3 text-sm ${tab === t.id ? "border-b-2 border-amber text-amber" : "text-muted"}`,
					onClick: () => setTab(t.id),
					children: t.label
				}, t.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [
					tab === "brief" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-4 sm:grid-cols-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border border-line bg-surface p-4 sm:col-span-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg",
									children: "承包商简报"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted",
									children: save.log
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
									className: "mt-4 space-y-2 text-sm",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "1. 仓库里的东西是安全的。只有装备、背包和安全箱会跟你进战区。" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "2. 搜容器，躲开或打倒巡逻者。站在撤离圈里直到倒计时结束。" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "3. 倒地或超时，背包和没上保险的装备都留在湾里。安全箱例外。" })
									]
								}),
								save.mail.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									className: "mt-4 min-h-11 bg-amber px-4 text-bg",
									onClick: () => commit((d) => claimMail(d)),
									children: [
										"领取保险退回（",
										save.mail.length,
										"）"
									]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "mt-4 block min-h-11 px-1 text-amber",
									onClick: () => setTab("raid"),
									children: "去出击"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid grid-cols-2 gap-2 sm:col-span-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									k: "出击",
									v: String(save.raids)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									k: "撤离",
									v: String(save.extracts)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									k: "存活",
									v: `${rate}%`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									k: "击倒",
									v: String(save.kills)
								})
							]
						})]
					}) : null,
					tab === "stash" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg",
								children: "仓库"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 font-mono text-xs text-muted",
								children: [
									slotsOf(save.stash),
									" / ",
									cap.stash,
									" 格 · 放在这里的东西不会进战区"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemList, {
								items: save.stash,
								empty: "仓库空了。活着带东西出来，或者找商人。",
								actions: (it) => {
									const d = ITEMS[it.defId];
									const buttons = [
										{
											label: "出售",
											run: () => commit((draft) => sellStashItem(draft, it.uid))
										},
										{
											label: "装进背包",
											run: () => commit((draft) => moveItem(draft.stash, draft.pack, it.uid, cap.pack) ? null : "背包满了")
										},
										{
											label: "安全箱",
											run: () => commit((draft) => moveItem(draft.stash, draft.secure, it.uid, cap.secure) ? null : "安全箱满了")
										}
									];
									if (d && (d.cat === "weapon" || d.cat === "armor" || d.cat === "helmet")) buttons.unshift({
										label: "装备",
										run: () => commit((draft) => equipItem(draft, it.uid))
									});
									return buttons;
								}
							})
						]
					}) : null,
					tab === "gear" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-4 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border border-line bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg",
									children: "身上"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-mono text-xs text-muted",
									children: [
										"负重 ",
										weight.toFixed(1),
										" / ",
										cap.weight,
										" kg",
										weight > cap.weight ? " · 超重会跑不动" : ""
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-3 space-y-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearSlot, {
											title: "武器",
											item: save.equipped.weapon,
											onOff: () => commit((d) => unequipItem(d, "weapon", "stash"))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearSlot, {
											title: "护甲",
											item: save.equipped.armor,
											onOff: () => commit((d) => unequipItem(d, "armor", "stash"))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(GearSlot, {
											title: "头盔",
											item: save.equipped.helmet,
											onOff: () => commit((d) => unequipItem(d, "helmet", "stash"))
										})
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "mt-4 min-h-11 border border-line px-3 text-sm disabled:opacity-40",
									disabled: save.hideout.bench < 1 || repairCost(save) <= 0,
									onClick: () => commit((d) => {
										return repairGear(d);
									}),
									children: save.hideout.bench < 1 ? "保养需要工作台" : repairCost(save) > 0 ? `保养装备 · ${repairCost(save).toLocaleString("zh-CN")} ₽` : "装备状况良好"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "border border-line bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "text-lg",
									children: "背包与安全箱"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: "这两格会带进战区。安全箱里的东西，死了也还在。"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "mt-3 text-sm text-muted",
									children: [
										"背包 ",
										slotsOf(save.pack),
										"/",
										cap.pack
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemList, {
									items: save.pack,
									empty: "背包是空的。至少带上弹药和绷带。",
									actions: (it) => [{
										label: "放回仓库",
										run: () => commit((d) => moveItem(d.pack, d.stash, it.uid, cap.stash) ? null : "仓库满了")
									}, {
										label: "安全箱",
										run: () => commit((d) => moveItem(d.pack, d.secure, it.uid, cap.secure) ? null : "安全箱满了")
									}]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
									className: "mt-4 text-sm text-amber",
									children: [
										"安全箱 ",
										slotsOf(save.secure),
										"/",
										cap.secure
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemList, {
									items: save.secure,
									empty: "还空着。",
									actions: (it) => [{
										label: "放回仓库",
										run: () => commit((d) => moveItem(d.secure, d.stash, it.uid, cap.stash) ? null : "仓库满了")
									}]
								})
							]
						})]
					}) : null,
					tab === "trader" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "border border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg",
								children: "码头商人"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: ["只收仓库里的货。工作台会压价。", save.hideout.bench >= 2 ? " 当前八折。" : save.hideout.bench >= 1 ? " 当前九折。" : ""]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 divide-y divide-line",
								children: TRADER.filter((row) => row.level <= level).map((row) => {
									const d = ITEMS[row.id];
									if (!d?.buy) return null;
									const price = buyPrice(save, row.id);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
										className: "flex flex-wrap items-center gap-2 py-3",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0 flex-1",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
													className: d.rarity === "rare" || d.rarity === "legendary" ? "text-amber" : "text-fg",
													children: [d.name, d.buyCount && d.stack ? ` ×${d.buyCount}` : ""]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
													className: "text-xs text-muted",
													children: d.blurb
												})]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "font-mono text-sm text-amber",
												children: [price.toLocaleString("zh-CN"), " ₽"]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												className: "min-h-11 bg-surface-2 px-3 text-sm",
												onClick: () => commit((draft) => buyItem(draft, row.id)),
												children: "购买"
											})
										]
									}, row.id);
								})
							}),
							level < 3 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-xs text-muted",
								children: [
									"再撤离几次，商人会拿出更好的枪。当前经验 ",
									save.xp,
									"。"
								]
							}) : null
						]
					}) : null,
					tab === "base" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "grid gap-3 sm:grid-cols-2",
						children: UPGRADES.map((u) => {
							const have = save.hideout[u.key];
							const next = have + 1 === u.level;
							const done = have >= u.level;
							const locked = u.needPower && save.hideout.power < 1;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "border border-line bg-surface p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "text-lg",
										children: u.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted",
										children: u.desc
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-3 flex items-center justify-between gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "font-mono text-sm text-amber",
											children: [u.cost.toLocaleString("zh-CN"), " ₽"]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
											className: "min-h-11 bg-amber px-3 text-bg disabled:opacity-40",
											disabled: !next || locked || save.rubles < u.cost || done,
											onClick: () => commit((d) => {
												if (d.rubles < u.cost) return "卢布不够";
												if (u.needPower && d.hideout.power < 1) return "需要发电机";
												if (d.hideout[u.key] + 1 !== u.level) return "还没排到这项";
												d.rubles -= u.cost;
												d.hideout[u.key] = u.level;
												d.log = `${u.name} 建好了。湾里的灯似乎稳了一点。`;
												return null;
											}),
											children: done ? "已建成" : locked ? "需要发电机" : next ? "建造" : "未解锁"
										})]
									})
								]
							}, `${u.key}-${u.level}`);
						})
					}) : null,
					tab === "raid" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex flex-wrap items-center justify-between gap-3 border border-line bg-surface p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex min-h-11 items-center gap-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "checkbox",
									checked: insure,
									onChange: (e) => setInsure(e.target.checked),
									className: "size-4 accent-amber"
								}),
								"为枪和护甲上保险 · ",
								premium.toLocaleString("zh-CN"),
								" ₽"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								"倒地后退回邮箱，并掉一些耐久。撤离则保险作废。负重 ",
								weight.toFixed(1),
								"/",
								cap.weight,
								" kg"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 lg:grid-cols-3",
						children: MAPS.map((map) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "flex flex-col border border-line bg-surface p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-xs text-amber",
									children: map.area
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-1 text-xl",
									children: map.name
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 flex-1 text-sm text-muted",
									children: map.brief
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-3 font-mono text-xs text-muted",
									children: [
										"难度 ",
										"●".repeat(map.difficulty),
										"○".repeat(3 - map.difficulty),
										" · ",
										Math.round(map.time / 60),
										" 分钟 · 巡逻 ",
										map.scavs.length
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									className: "mt-4 min-h-11 bg-amber px-3 text-bg",
									onClick: () => onDeploy(map.id, insure && premium > 0),
									children: ["部署 · ", map.name]
								})
							]
						}, map.id))
					})] }) : null
				]
			})
		]
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-line bg-surface p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs text-muted",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-mono text-2xl text-fg",
			children: v
		})]
	});
}
function GearSlot({ item, title, onOff }) {
	const d = item ? ITEMS[item.defId] : null;
	const dur = d?.dur && item?.dur != null ? Math.round(item.dur / d.dur * 100) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border border-line bg-surface-2 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-1 flex items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: d?.name ?? "空" }), dur != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 h-1 w-28 bg-bg",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-full bg-amber",
					style: { width: `${dur}%` }
				})
			}) : null] }), item ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "min-h-11 px-2 text-sm text-muted",
				onClick: onOff,
				children: "卸下"
			}) : null]
		})]
	});
}
function ItemList({ items, empty, actions }) {
	if (!items.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-3 text-sm text-muted",
		children: empty
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2",
		children: items.map((it) => {
			const d = ITEMS[it.defId];
			if (!d) return null;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center gap-2 border-b border-line py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: d.rarity === "rare" || d.rarity === "legendary" ? "text-amber" : "text-fg",
							children: [d.name, d.stack ? ` ×${it.count}` : ""]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xs text-muted",
							children: d.blurb
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "font-mono text-xs text-muted",
						children: [sellValue(it).toLocaleString("zh-CN"), " ₽"]
					}),
					actions(it).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "min-h-11 bg-surface-2 px-2 text-sm",
						onClick: a.run,
						children: a.label
					}, a.label))
				]
			}, it.uid);
		})
	});
}
var FLOOR = [
	"#171c16",
	"#1b2118",
	"#141915"
];
var WALL = "#2a3126";
var WALL_LIP = "#3a4434";
var WALL_FOOT = "#121510";
function hash(tx, ty) {
	return (tx * 73856093 ^ ty * 19349663) >>> 0;
}
function tileVisible(state, tx, ty) {
	const { map, visible } = state;
	if (tx < 0 || ty < 0 || tx >= map.w || ty >= map.h) return false;
	return visible[ty * map.w + tx] === 1;
}
function drawRaid(ctx, state, cssW, cssH, dpr) {
	const { map } = state;
	const zoom = state.zoom;
	const viewW = cssW / zoom;
	const viewH = cssH / zoom;
	let camX = state.camX;
	let camY = state.camY;
	const maxX = map.w * 48 - viewW / 2;
	const maxY = map.h * 48 - viewH / 2;
	if (map.w * 48 > viewW) camX = Math.max(viewW / 2, Math.min(maxX, camX));
	else camX = map.w * 48 / 2;
	if (map.h * 48 > viewH) camY = Math.max(viewH / 2, Math.min(maxY, camY));
	else camY = map.h * 48 / 2;
	const sh = state.shake > .2 ? (Math.random() - .5) * state.shake : 0;
	const sv = state.shake > .2 ? (Math.random() - .5) * state.shake : 0;
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	ctx.fillStyle = "#0c0e0b";
	ctx.fillRect(0, 0, cssW, cssH);
	ctx.setTransform(dpr * zoom, 0, 0, dpr * zoom, dpr * (cssW / 2 - camX * zoom + sh), dpr * (cssH / 2 - camY * zoom + sv));
	const x0 = Math.max(0, Math.floor((camX - viewW / 2) / 48) - 1);
	const y0 = Math.max(0, Math.floor((camY - viewH / 2) / 48) - 1);
	const x1 = Math.min(map.w - 1, Math.ceil((camX + viewW / 2) / 48) + 1);
	const y1 = Math.min(map.h - 1, Math.ceil((camY + viewH / 2) / 48) + 1);
	for (let ty = y0; ty <= y1; ty++) for (let tx = x0; tx <= x1; tx++) {
		const k = ty * map.w + tx;
		if (!state.explored[k]) continue;
		const px = tx * 48;
		const py = ty * 48;
		if (map.tiles[k] === 1) {
			ctx.fillStyle = WALL;
			ctx.fillRect(px, py, 48, 48);
			ctx.fillStyle = WALL_LIP;
			ctx.fillRect(px, py, 48, 5);
			ctx.fillStyle = WALL_FOOT;
			ctx.fillRect(px, py + 48 - 7, 48, 7);
		} else {
			ctx.fillStyle = FLOOR[hash(tx, ty) % FLOOR.length];
			ctx.fillRect(px, py, 48, 48);
			if (hash(tx, ty) % 11 === 0) {
				ctx.fillStyle = "rgba(224,165,58,0.04)";
				ctx.fillRect(px + 6, py + 8, 14, 3);
			}
		}
		if (!state.visible[k]) {
			ctx.fillStyle = "rgba(8,10,8,0.72)";
			ctx.fillRect(px, py, 48, 48);
		}
	}
	const t = performance.now() / 1e3;
	for (const ex of map.extracts) {
		const tx = Math.floor(ex.x / 48);
		const ty = Math.floor(ex.y / 48);
		if (!state.explored[ty * map.w + tx]) continue;
		const open = ex.gated === "none" || (ex.gated === "switch" ? state.gateOpen : hasKey$1(state));
		ctx.save();
		ctx.translate(ex.x, ex.y);
		ctx.strokeStyle = open ? "rgba(224,165,58,0.85)" : "rgba(196,69,45,0.7)";
		ctx.lineWidth = 2;
		ctx.beginPath();
		ctx.arc(0, 0, 28 + Math.sin(t * 3) * 2, 0, Math.PI * 2);
		ctx.stroke();
		ctx.globalAlpha = tileVisible(state, tx, ty) ? 1 : .35;
		ctx.fillStyle = open ? "#e0a53a" : "#c4452d";
		ctx.font = "11px WenQuanYi Zen Hei, sans-serif";
		ctx.textAlign = "center";
		ctx.fillText(ex.name, 0, 4);
		ctx.restore();
	}
	for (const sw of map.switches) {
		const tx = Math.floor(sw.x / 48);
		const ty = Math.floor(sw.y / 48);
		if (!state.explored[ty * map.w + tx]) continue;
		ctx.save();
		ctx.translate(sw.x, sw.y);
		ctx.fillStyle = state.gateOpen ? "#e0a53a" : "#3a4034";
		ctx.fillRect(-8, -10, 16, 20);
		ctx.fillStyle = "#0e100e";
		ctx.fillRect(-2, state.gateOpen ? -6 : 0, 4, 8);
		ctx.restore();
	}
	for (const box of state.boxes) {
		const tx = Math.floor(box.x / 48);
		const ty = Math.floor(box.y / 48);
		if (!tileVisible(state, tx, ty) && box.kind !== "body") {
			if (!state.explored[ty * map.w + tx]) continue;
		}
		if (!state.explored[ty * map.w + tx]) continue;
		const dim = state.visible[ty * map.w + tx] ? 1 : .35;
		ctx.save();
		ctx.globalAlpha = dim;
		ctx.translate(box.x, box.y);
		if (box.kind === "body") {
			ctx.fillStyle = "#6e3a30";
			ctx.beginPath();
			ctx.ellipse(0, 0, 11, 7, .4, 0, Math.PI * 2);
			ctx.fill();
		} else {
			ctx.fillStyle = box.kind === "safe" ? "#8a7044" : box.kind === "med" ? "#6d7d62" : box.kind === "weapon" ? "#4d5960" : box.kind === "key" ? "#a6843a" : "#6a5340";
			ctx.fillRect(-13, -11, 26, 22);
			ctx.fillStyle = "rgba(0,0,0,0.25)";
			ctx.fillRect(-13, -11, 26, 5);
			if (!box.open) {
				ctx.strokeStyle = "#e0a53a";
				ctx.lineWidth = 1.5;
				ctx.strokeRect(-13, -11, 26, 22);
			}
		}
		ctx.restore();
	}
	for (const b of state.bullets) {
		if (!b.alive) continue;
		ctx.strokeStyle = b.team === 0 ? "#f0d48a" : "#e07a62";
		ctx.globalAlpha = .95;
		ctx.lineWidth = b.team === 0 ? 2 : 1.6;
		ctx.beginPath();
		ctx.moveTo(b.px, b.py);
		ctx.lineTo(b.x, b.y);
		ctx.stroke();
		ctx.globalAlpha = 1;
	}
	for (const s of state.scavs) {
		if (!s.alive) continue;
		if (!tileVisible(state, Math.floor(s.x / 48), Math.floor(s.y / 48))) continue;
		drawActor(ctx, s.x, s.y, s.aim, "scav", s.flash > 0);
		const ratio = s.hp / s.maxHp;
		ctx.fillStyle = "rgba(0,0,0,0.55)";
		ctx.fillRect(s.x - 12, s.y - 22, 24, 3);
		ctx.fillStyle = ratio > .4 ? "#c4452d" : "#e0a53a";
		ctx.fillRect(s.x - 12, s.y - 22, 24 * ratio, 3);
	}
	for (const bit of state.particles) {
		if (!bit.alive) continue;
		ctx.globalAlpha = Math.max(0, bit.life / bit.max);
		ctx.fillStyle = bit.color;
		ctx.fillRect(bit.x, bit.y, bit.r, bit.r);
		ctx.globalAlpha = 1;
	}
	const p = state.player;
	drawActor(ctx, p.x, p.y, p.aim, "player", p.hit > 0);
	if (state.recoil > 0) {
		const kick = state.recoil * 8;
		ctx.fillStyle = `rgba(240,212,138,${.35 + state.recoil * .4})`;
		ctx.beginPath();
		ctx.arc(p.x + Math.cos(p.aim) * (22 + kick), p.y + Math.sin(p.aim) * (22 + kick), 4 + state.recoil * 3, 0, Math.PI * 2);
		ctx.fill();
	}
	if (p.extract > 0) {
		ctx.strokeStyle = "#e0a53a";
		ctx.lineWidth = 3;
		ctx.beginPath();
		ctx.arc(p.x, p.y, 22, -Math.PI / 2, -Math.PI / 2 + p.extract / 5 * Math.PI * 2);
		ctx.stroke();
	}
	ctx.font = "12px WenQuanYi Zen Hei, sans-serif";
	ctx.textAlign = "center";
	for (const ft of state.texts) {
		ctx.globalAlpha = Math.max(0, ft.life / .7);
		ctx.fillStyle = ft.color;
		ctx.fillText(ft.text, ft.x, ft.y - (.7 - ft.life) * 20);
	}
	ctx.globalAlpha = 1;
	if (state.player && aimReticle(state)) {
		const ax = state.player.x + Math.cos(state.player.aim) * 70;
		const ay = state.player.y + Math.sin(state.player.aim) * 70;
		ctx.strokeStyle = "rgba(224,165,58,0.8)";
		ctx.lineWidth = 1.25;
		ctx.beginPath();
		ctx.arc(ax, ay, 5, 0, Math.PI * 2);
		ctx.moveTo(ax - 9, ay);
		ctx.lineTo(ax - 3, ay);
		ctx.moveTo(ax + 3, ay);
		ctx.lineTo(ax + 9, ay);
		ctx.moveTo(ax, ay - 9);
		ctx.lineTo(ax, ay - 3);
		ctx.moveTo(ax, ay + 3);
		ctx.lineTo(ax, ay + 9);
		ctx.stroke();
	}
	ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
	const g = ctx.createRadialGradient(cssW / 2, cssH / 2, cssW * .2, cssW / 2, cssH / 2, cssW * .72);
	g.addColorStop(0, "rgba(0,0,0,0)");
	g.addColorStop(1, state.player.hp < 35 ? "rgba(120,24,16,0.45)" : "rgba(0,0,0,0.38)");
	ctx.fillStyle = g;
	ctx.fillRect(0, 0, cssW, cssH);
	if (state.flash > 0) {
		ctx.fillStyle = `rgba(196,69,45,${state.flash * .45})`;
		ctx.fillRect(0, 0, cssW, cssH);
	}
	drawMinimap(ctx, state, cssW);
}
function hasKey$1(state) {
	const id = state.map.keyId;
	if (!id) return false;
	return [...state.player.pack, ...state.player.secure].some((it) => it.defId === id);
}
function aimReticle(state) {
	return !state.outcome;
}
function drawActor(ctx, x, y, aim, kind, flash) {
	ctx.save();
	ctx.translate(x, y);
	ctx.rotate(aim);
	ctx.scale(1.2, 1.2);
	ctx.fillStyle = "rgba(0,0,0,0.35)";
	ctx.beginPath();
	ctx.ellipse(1, 6, 12, 6, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = kind === "player" ? "#3a3224" : "#2c241f";
	ctx.fillRect(-15, -6, 9, 12);
	ctx.fillStyle = flash ? "#f4f0e4" : kind === "player" ? "#8a7044" : "#6a3a32";
	ctx.beginPath();
	ctx.ellipse(-1, 0, 9, 7, 0, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = kind === "player" ? "#c6a15c" : "#3a2824";
	ctx.fillRect(-3, -4.5, 8, 9);
	ctx.fillStyle = flash ? "#ffffff" : "#d9c7a6";
	ctx.beginPath();
	ctx.arc(7, 0, 4.3, 0, Math.PI * 2);
	ctx.fill();
	ctx.fillStyle = kind === "player" ? "#232820" : "#1a1412";
	ctx.fillRect(4, -4.4, 6.5, 3.2);
	ctx.fillStyle = "#141612";
	ctx.fillRect(9, -1.5, kind === "player" ? 16 : 12, 3);
	ctx.fillStyle = kind === "player" ? "#e0a53a" : "#c4452d";
	ctx.fillRect(kind === "player" ? 23 : 19, -1, 3, 2);
	ctx.restore();
}
function drawMinimap(ctx, state, cssW) {
	const { map } = state;
	const size = 118;
	const pad = 12;
	const x = cssW - size - pad;
	const y = pad;
	ctx.fillStyle = "rgba(14,16,14,0.78)";
	ctx.fillRect(x - 4, 8, 126, 126);
	ctx.strokeStyle = "#343b2e";
	ctx.strokeRect(x - 4, 8, 126, 126);
	const sx = size / map.w;
	const sy = size / map.h;
	for (let ty = 0; ty < map.h; ty++) for (let tx = 0; tx < map.w; tx++) {
		if (!state.explored[ty * map.w + tx]) continue;
		ctx.fillStyle = map.tiles[ty * map.w + tx] === 1 ? "#3a4434" : "#1e261c";
		ctx.fillRect(x + tx * sx, y + ty * sy, Math.ceil(sx), Math.ceil(sy));
	}
	ctx.fillStyle = "#e0a53a";
	for (const ex of map.extracts) {
		const tx = Math.floor(ex.x / 48);
		const ty = Math.floor(ex.y / 48);
		if (!state.explored[ty * map.w + tx]) continue;
		ctx.fillRect(x + tx * sx, y + ty * sy, Math.max(2, sx), Math.max(2, sy));
	}
	ctx.fillStyle = "#c4452d";
	for (const s of state.scavs) {
		if (!s.alive) continue;
		if (!tileVisible(state, Math.floor(s.x / 48), Math.floor(s.y / 48))) continue;
		ctx.fillRect(x + s.x / 48 * sx - 1, y + s.y / 48 * sy - 1, 2.5, 2.5);
	}
	ctx.fillStyle = "#f0e6c8";
	ctx.fillRect(x + state.player.x / 48 * sx - 1.5, y + state.player.y / 48 * sy - 1.5, 3, 3);
}
function weaponLabel(state) {
	const w = state.player.weapon;
	if (!w) return "徒手";
	return ITEMS[w.defId]?.name ?? "武器";
}
var R = 13;
var VIEW = 292;
function createRaid(setup) {
	const map = mapById(setup.mapId);
	const weapon = setup.gear.weapon ? { ...setup.gear.weapon } : null;
	const player = {
		x: map.spawn.x,
		y: map.spawn.y,
		vx: 0,
		vy: 0,
		aim: -Math.PI / 2,
		hp: 100,
		mag: weapon?.mag ?? 0,
		fireCd: 0,
		reload: 0,
		use: 0,
		using: null,
		buff: 0,
		extract: 0,
		weapon,
		armor: setup.gear.armor ? { ...setup.gear.armor } : null,
		helmet: setup.gear.helmet ? { ...setup.gear.helmet } : null,
		pack: setup.pack.map((it) => ({ ...it })),
		secure: setup.secure.map((it) => ({ ...it })),
		hit: 0
	};
	const state = {
		map,
		player,
		scavs: map.scavs.map((s, i) => ({
			id: i + 1,
			x: s.x,
			y: s.y,
			vx: 0,
			vy: 0,
			aim: Math.random() * Math.PI * 2,
			hp: map.scav.hp,
			maxHp: map.scav.hp,
			alive: true,
			cd: .4 + Math.random() * .5,
			react: .3,
			seen: false,
			wander: Math.random() * Math.PI * 2,
			wanderT: .4,
			flash: 0
		})),
		boxes: map.containers.map((c) => ({
			id: c.id,
			x: c.x,
			y: c.y,
			kind: c.kind,
			items: rollContainer(c.kind, map),
			open: false
		})),
		bullets: [],
		particles: [],
		texts: [],
		explored: new Uint8Array(map.w * map.h),
		visible: new Uint8Array(map.w * map.h),
		time: map.time,
		kills: 0,
		camX: player.x,
		camY: player.y,
		shake: 0,
		recoil: 0,
		hitStop: 0,
		flash: 0,
		gateOpen: false,
		paused: false,
		lootId: null,
		prompt: "",
		msg: `${map.name} · 找到撤离点，活着出去`,
		msgT: 3.2,
		outcome: null,
		endTimer: 0,
		reported: false,
		events: [],
		spreadMul: setup.spreadMul,
		healMul: setup.healMul,
		packCap: setup.packCap,
		secureCap: setup.secureCap,
		weightLimit: setup.weightLimit,
		insure: setup.insure,
		zoom: 1,
		viewW: 800,
		viewH: 600
	};
	reveal(state);
	return state;
}
function wallAt(map, x, y) {
	const tx = Math.floor(x / 48);
	const ty = Math.floor(y / 48);
	if (tx < 0 || ty < 0 || tx >= map.w || ty >= map.h) return true;
	return map.tiles[ty * map.w + tx] === 1;
}
function blocked(map, x, y, rad) {
	const minX = Math.floor((x - rad) / 48);
	const maxX = Math.floor((x + rad) / 48);
	const minY = Math.floor((y - rad) / 48);
	const maxY = Math.floor((y + rad) / 48);
	for (let ty = minY; ty <= maxY; ty++) for (let tx = minX; tx <= maxX; tx++) {
		if (!(tx < 0 || ty < 0 || tx >= map.w || ty >= map.h || map.tiles[ty * map.w + tx] === 1)) continue;
		const left = tx * 48;
		const top = ty * 48;
		const nx = Math.max(left, Math.min(x, left + 48));
		const ny = Math.max(top, Math.min(y, top + 48));
		const dx = x - nx;
		const dy = y - ny;
		if (dx * dx + dy * dy < rad * rad) return true;
	}
	return false;
}
function moveBody(map, e, dx, dy, rad) {
	const ox = e.x;
	const oy = e.y;
	if (!blocked(map, e.x + dx, e.y, rad)) e.x += dx;
	if (!blocked(map, e.x, e.y + dy, rad)) e.y += dy;
	return e.x !== ox || e.y !== oy;
}
function los(map, x0, y0, x1, y1) {
	const dist = Math.hypot(x1 - x0, y1 - y0);
	const steps = Math.max(1, Math.ceil(dist / (48 * .4)));
	for (let i = 1; i < steps; i++) {
		const t = i / steps;
		if (wallAt(map, x0 + (x1 - x0) * t, y0 + (y1 - y0) * t)) return false;
	}
	return true;
}
function reveal(state) {
	const { map, player, visible, explored } = state;
	visible.fill(0);
	const r = Math.ceil(VIEW / 48);
	const tx = Math.floor(player.x / 48);
	const ty = Math.floor(player.y / 48);
	for (let y = ty - r; y <= ty + r; y++) for (let x = tx - r; x <= tx + r; x++) {
		if (x < 0 || y < 0 || x >= map.w || y >= map.h) continue;
		const cx = (x + .5) * 48;
		const cy = (y + .5) * 48;
		if (Math.hypot(cx - player.x, cy - player.y) > VIEW) continue;
		if (!los(map, player.x, player.y, cx, cy)) continue;
		const k = y * map.w + x;
		visible[k] = 1;
		explored[k] = 1;
	}
}
function reduction(p) {
	const mit = (it) => {
		if (!it || it.dur == null || it.dur <= 0) return 0;
		return ITEMS[it.defId]?.armor ?? 0;
	};
	const a = mit(p.armor);
	const h = mit(p.helmet);
	return 1 - (1 - a) * (1 - h);
}
function spark(state, x, y, color, n, speed) {
	for (let i = 0; i < n; i++) {
		const a = Math.random() * Math.PI * 2;
		const v = speed * (.3 + Math.random());
		const p = state.particles.find((q) => !q.alive);
		const life = .18 + Math.random() * .28;
		const bit = p ?? {
			alive: true,
			x,
			y,
			vx: 0,
			vy: 0,
			life,
			max: life,
			r: 2,
			color
		};
		bit.alive = true;
		bit.x = x;
		bit.y = y;
		bit.vx = Math.cos(a) * v;
		bit.vy = Math.sin(a) * v;
		bit.life = life;
		bit.max = life;
		bit.r = 1.4 + Math.random() * 2.2;
		bit.color = color;
		if (!p) {
			if (state.particles.length < 140) state.particles.push(bit);
		}
	}
}
function floatText(state, x, y, text, color) {
	state.texts.push({
		x,
		y,
		text,
		life: .7,
		color
	});
	if (state.texts.length > 24) state.texts.shift();
}
function spawnBullet(state, x, y, aim, dmg, team, range) {
	const speed = team === 0 ? 720 : 460;
	let b = state.bullets.find((q) => !q.alive);
	if (!b) {
		if (state.bullets.length > 90) return;
		b = {
			alive: true,
			x,
			y,
			px: x,
			py: y,
			vx: 0,
			vy: 0,
			life: 1,
			dmg,
			team
		};
		state.bullets.push(b);
	}
	b.alive = true;
	b.x = x;
	b.y = y;
	b.px = x;
	b.py = y;
	b.vx = Math.cos(aim) * speed;
	b.vy = Math.sin(aim) * speed;
	b.life = range / speed;
	b.dmg = dmg;
	b.team = team;
}
function weaponDef(p) {
	if (!p.weapon) return null;
	const d = ITEMS[p.weapon.defId];
	return d?.cat === "weapon" ? d : null;
}
function ammoCount(p, id) {
	return [...p.pack, ...p.secure].filter((i) => i.defId === id).reduce((n, i) => n + i.count, 0);
}
function takeAmmo(p, id, n) {
	let need = n;
	for (const list of [p.pack, p.secure]) for (let i = 0; i < list.length && need > 0; i++) {
		const it = list[i];
		if (it.defId !== id) continue;
		const take = Math.min(it.count, need);
		it.count -= take;
		need -= take;
		if (it.count <= 0) {
			list.splice(i, 1);
			i--;
		}
	}
	return n - need;
}
function startReload(state, p) {
	const w = weaponDef(p);
	if (!w?.ammo || !w.mag || p.reload > 0 || p.use > 0) return;
	if (w.mag - p.mag <= 0) return;
	if (ammoCount(p, w.ammo) <= 0) {
		state.events.push("dry");
		state.msg = "没有备用弹药";
		state.msgT = .8;
		return;
	}
	p.reload = (w.reload ?? 1.6) * (p.weapon?.dur != null && p.weapon.dur < 25 ? 1.25 : 1);
	state.events.push("reload");
}
function tryFire(state, p) {
	const w = weaponDef(p);
	if (!w) return;
	if (p.fireCd > 0 || p.reload > 0 || p.use > 0) return;
	if (p.weapon?.dur != null && p.weapon.dur <= 0) {
		state.events.push("dry");
		state.msg = "枪械故障，回藏身处保养";
		state.msgT = .9;
		return;
	}
	if (p.mag <= 0) {
		startReload(state, p);
		return;
	}
	p.mag -= 1;
	if (p.weapon?.dur != null) p.weapon.dur = Math.max(0, p.weapon.dur - .28);
	const pellets = w.pellets ?? 1;
	const moving = Math.hypot(p.vx, p.vy) > 24;
	const spread = (w.spread ?? .05) * state.spreadMul * (moving ? 1.9 : 1);
	const ox = p.x + Math.cos(p.aim) * 18;
	const oy = p.y + Math.sin(p.aim) * 18;
	for (let i = 0; i < pellets; i++) spawnBullet(state, ox, oy, p.aim + (Math.random() - .5) * spread * 2, w.dmg ?? 10, 0, w.range ?? 480);
	p.fireCd = 60 / (w.rpm ?? 400);
	state.recoil = 1;
	state.shake = Math.min(7, state.shake + (pellets > 1 ? 3.4 : 1.5));
	spark(state, ox, oy, "#e0a53a", pellets > 1 ? 8 : 3, 90);
	state.events.push(pellets > 1 ? "shotgun" : "shot");
}
function killScav(state, s) {
	s.alive = false;
	s.hp = 0;
	state.kills += 1;
	state.hitStop = .04;
	state.boxes.push({
		id: `body-${s.id}-${state.kills}`,
		x: s.x,
		y: s.y,
		kind: "body",
		items: rollContainer("body", state.map),
		open: false
	});
	spark(state, s.x, s.y, "#c4452d", 12, 120);
	floatText(state, s.x, s.y - 16, "击倒", "#e0a53a");
	state.events.push("hit");
}
function damageScav(state, s, dmg) {
	s.hp -= dmg;
	s.flash = .08;
	s.seen = true;
	s.react = 0;
	spark(state, s.x, s.y, "#e7e4d8", 4, 70);
	floatText(state, s.x, s.y - 10, String(Math.round(dmg)), "#e7e4d8");
	if (s.hp <= 0) killScav(state, s);
	else state.events.push("hit");
}
function hurtPlayer(state, dmg) {
	const p = state.player;
	const dealt = Math.max(1, dmg * (1 - reduction(p)));
	p.hp -= dealt;
	p.hit = .14;
	for (const part of [p.armor, p.helmet]) if (part?.dur != null) part.dur = Math.max(0, part.dur - dmg * .5);
	state.flash = .2;
	state.shake = Math.min(9, state.shake + 3.2);
	floatText(state, p.x, p.y - 18, String(Math.round(dealt)), "#c4452d");
	state.events.push("hurt");
	if (p.hp <= 0) {
		p.hp = 0;
		state.outcome = "dead";
		state.endTimer = 1.2;
		state.paused = false;
		state.lootId = null;
		state.events.push("death");
	}
}
function segDist(px, py, x1, y1, x2, y2) {
	const dx = x2 - x1;
	const dy = y2 - y1;
	const l2 = dx * dx + dy * dy || 1;
	let t = ((px - x1) * dx + (py - y1) * dy) / l2;
	t = Math.max(0, Math.min(1, t));
	return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
}
function hasKey(p, id) {
	if (!id) return false;
	return [...p.pack, ...p.secure].some((it) => it.defId === id);
}
function extractOpen(state, gated) {
	if (gated === "none") return true;
	if (gated === "switch") return state.gateOpen;
	return hasKey(state.player, state.map.keyId);
}
function updatePrompt(state) {
	const p = state.player;
	let best = 54;
	let prompt = "";
	for (const box of state.boxes) {
		if (box.open && box.items.length === 0) continue;
		const d = Math.hypot(box.x - p.x, box.y - p.y);
		if (d < best) {
			best = d;
			const label = box.kind === "body" ? "遗体" : box.kind === "safe" ? "保险箱" : "容器";
			prompt = box.open ? `F  翻找${label}` : `F  搜索${label}`;
		}
	}
	for (const sw of state.map.switches) {
		const d = Math.hypot(sw.x - p.x, sw.y - p.y);
		if (d < best) {
			best = d;
			prompt = state.gateOpen ? "电闸已经合上" : "F  拉下电闸";
		}
	}
	for (const ex of state.map.extracts) if (Math.hypot(ex.x - p.x, ex.y - p.y) < 78) {
		if (!extractOpen(state, ex.gated)) prompt = ex.gated === "key" ? `${ex.name} · 需要${ITEMS[state.map.keyId ?? ""]?.name ?? "钥匙"}` : `${ex.name} · 电闸未合`;
	}
	if (p.extract > 0) prompt = `撤离中 ${Math.ceil(5 - p.extract)}`;
	state.prompt = prompt;
}
function interact(state) {
	const p = state.player;
	let bestD = 54;
	let kind = null;
	let box = null;
	for (const b of state.boxes) {
		if (b.open && b.items.length === 0) continue;
		const d = Math.hypot(b.x - p.x, b.y - p.y);
		if (d < bestD) {
			bestD = d;
			kind = "box";
			box = b;
		}
	}
	for (const sw of state.map.switches) {
		const d = Math.hypot(sw.x - p.x, sw.y - p.y);
		if (d < bestD) {
			bestD = d;
			kind = "switch";
			box = null;
		}
	}
	if (kind === "switch") {
		state.gateOpen = true;
		state.msg = "电闸合上了，对应的门已经打开。";
		state.msgT = 2.2;
		state.events.push("zip");
		return;
	}
	if (kind === "box" && box) {
		if (!box.open) {
			box.open = true;
			state.events.push("search");
		}
		state.lootId = box.id;
		state.paused = true;
	}
}
function applyMed(state) {
	const p = state.player;
	for (const list of [p.pack, p.secure]) {
		const i = list.findIndex((it) => it.uid === p.using);
		if (i < 0) continue;
		const it = list[i];
		const d = ITEMS[it.defId];
		if (d?.heal) p.hp = Math.min(100, p.hp + d.heal);
		if (d?.buff) {
			p.buff = Math.max(p.buff, d.buff);
			state.msg = "腿暂时不疼了。";
			state.msgT = 1.2;
		}
		it.count -= 1;
		if (it.count <= 0) list.splice(i, 1);
		state.events.push("zip");
		return;
	}
}
function finishReload(state) {
	const p = state.player;
	const w = weaponDef(p);
	if (!w?.ammo || !w.mag) return;
	const need = w.mag - p.mag;
	if (need <= 0) return;
	p.mag += takeAmmo(p, w.ammo, need);
}
function lerpAngle(a, b, t) {
	return a + Math.atan2(Math.sin(b - a), Math.cos(b - a)) * t;
}
function step(state, dt, input) {
	state.events.length = 0;
	if (state.outcome) {
		state.endTimer -= dt;
		state.flash = Math.max(0, state.flash - dt);
		return;
	}
	if (state.paused) return;
	if (state.hitStop > 0) {
		state.hitStop -= dt;
		return;
	}
	const p = state.player;
	const map = state.map;
	p.fireCd = Math.max(0, p.fireCd - dt);
	p.buff = Math.max(0, p.buff - dt);
	p.hit = Math.max(0, p.hit - dt);
	state.flash = Math.max(0, state.flash - dt);
	state.recoil = Math.max(0, state.recoil - dt * 6);
	state.msgT = Math.max(0, state.msgT - dt);
	state.shake *= Math.exp(-5.5 * dt);
	if (input.aimOk) p.aim = Math.atan2(input.aimY - p.y, input.aimX - p.x);
	const weight = carryWeight({
		weapon: p.weapon,
		armor: p.armor,
		helmet: p.helmet
	}, p.pack, p.secure);
	let speed = 178;
	const enc = weight / state.weightLimit;
	if (enc > .6) speed *= 1 - Math.min(.42, (enc - .6) * .65);
	if (enc > 1) speed *= state.weightLimit / weight;
	if (p.buff > 0) speed *= 1.12;
	if (p.use > 0) speed *= .7;
	if (p.reload > 0) speed *= .84;
	let mx = input.mx;
	let my = input.my;
	const len = Math.hypot(mx, my);
	if (len > 1) {
		mx /= len;
		my /= len;
	}
	const ox = p.x;
	const oy = p.y;
	moveBody(map, p, mx * speed * dt, my * speed * dt, R);
	p.vx = dt > 0 ? (p.x - ox) / dt : 0;
	p.vy = dt > 0 ? (p.y - oy) / dt : 0;
	if (input.heal && p.use <= 0 && p.reload <= 0) {
		const med = [...p.pack, ...p.secure].find((it) => ITEMS[it.defId]?.cat === "med" && it.count > 0);
		if (med) {
			p.use = (ITEMS[med.defId]?.use ?? 2) * state.healMul;
			p.using = med.uid;
		} else {
			state.msg = "没有医疗品";
			state.msgT = .7;
		}
	}
	if (p.use > 0) {
		if (input.fire) {
			p.use = 0;
			p.using = null;
		} else {
			p.use -= dt;
			if (p.use <= 0) applyMed(state);
		}
	}
	if (input.reload) startReload(state, p);
	if (p.reload > 0) {
		p.reload -= dt;
		if (p.reload <= 0) finishReload(state);
	} else if (input.fire) tryFire(state, p);
	if (input.interact) interact(state);
	let inZone = false;
	for (const ex of map.extracts) {
		if (!extractOpen(state, ex.gated)) continue;
		if (Math.hypot(ex.x - p.x, ex.y - p.y) < 62) inZone = true;
	}
	if (inZone) {
		p.extract += dt;
		if (p.extract >= 5 && !state.outcome) {
			state.outcome = "extract";
			state.endTimer = .85;
			state.events.push("extract");
			state.msg = "撤离成功";
			state.msgT = 2;
		}
	} else p.extract = Math.max(0, p.extract - dt * 2);
	state.time -= dt;
	if (state.time <= 0 && !state.outcome) {
		state.time = 0;
		state.outcome = "mia";
		state.endTimer = 1.1;
		state.events.push("death");
	}
	for (const s of state.scavs) {
		if (!s.alive) continue;
		s.cd = Math.max(0, s.cd - dt);
		s.flash = Math.max(0, s.flash - dt);
		const dist = Math.hypot(p.x - s.x, p.y - s.y);
		const see = dist < map.scav.range + 30 && los(map, s.x, s.y, p.x, p.y);
		let dx = 0;
		let dy = 0;
		if (see) {
			if (!s.seen) s.react = .32;
			s.seen = true;
			s.react = Math.max(0, s.react - dt);
			const ang = Math.atan2(p.y - s.y, p.x - s.x);
			s.aim = lerpAngle(s.aim, ang, 1 - Math.exp(-9 * dt));
			if (dist > 168) {
				dx = Math.cos(ang);
				dy = Math.sin(ang);
			} else if (dist < 96) {
				dx = -Math.cos(ang);
				dy = -Math.sin(ang);
			}
			if (s.react <= 0 && s.cd <= 0 && dist < map.scav.range) {
				const miss = (Math.random() - .5) * .22;
				spawnBullet(state, s.x + Math.cos(s.aim) * 16, s.y + Math.sin(s.aim) * 16, s.aim + miss, map.scav.dmg, 1, map.scav.range);
				s.cd = map.scav.cd * (.85 + Math.random() * .45);
				spark(state, s.x + Math.cos(s.aim) * 16, s.y + Math.sin(s.aim) * 16, "#c4452d", 3, 40);
			}
		} else {
			if (dist > map.scav.range + 120) s.seen = false;
			s.wanderT -= dt;
			if (s.wanderT <= 0) {
				s.wander = Math.random() * Math.PI * 2;
				s.wanderT = .7 + Math.random() * 1.5;
			}
			dx = Math.cos(s.wander);
			dy = Math.sin(s.wander);
			s.aim = lerpAngle(s.aim, s.wander, 1 - Math.exp(-4 * dt));
		}
		for (const o of state.scavs) {
			if (o === s || !o.alive) continue;
			const ddx = s.x - o.x;
			const ddy = s.y - o.y;
			const d = Math.hypot(ddx, ddy);
			if (d > 0 && d < 30) {
				dx += ddx / d;
				dy += ddy / d;
			}
		}
		const L = Math.hypot(dx, dy);
		if (L > 0) {
			if (!moveBody(map, s, dx / L * map.scav.speed * dt, dy / L * map.scav.speed * dt, R)) s.wanderT = 0;
		}
		const sox = s.x;
		const soy = s.y;
		s.vx = dt > 0 ? (s.x - sox) / dt : 0;
		s.vy = dt > 0 ? (s.y - soy) / dt : 0;
	}
	for (const b of state.bullets) {
		if (!b.alive) continue;
		b.px = b.x;
		b.py = b.y;
		b.x += b.vx * dt;
		b.y += b.vy * dt;
		b.life -= dt;
		if (b.life <= 0) {
			b.alive = false;
			continue;
		}
		let hitWall = false;
		const steps = 3;
		for (let i = 1; i <= steps; i++) {
			const t = i / steps;
			if (wallAt(map, b.px + (b.x - b.px) * t, b.py + (b.y - b.py) * t)) {
				hitWall = true;
				break;
			}
		}
		if (hitWall) {
			b.alive = false;
			spark(state, b.x, b.y, "#8e8a7c", 3, 40);
			continue;
		}
		if (b.team === 0) for (const s of state.scavs) {
			if (!s.alive) continue;
			if (segDist(s.x, s.y, b.px, b.py, b.x, b.y) < 15) {
				b.alive = false;
				damageScav(state, s, b.dmg);
				break;
			}
		}
		else if (segDist(p.x, p.y, b.px, b.py, b.x, b.y) < 15) {
			b.alive = false;
			hurtPlayer(state, b.dmg);
		}
	}
	for (const bit of state.particles) {
		if (!bit.alive) continue;
		bit.life -= dt;
		bit.x += bit.vx * dt;
		bit.y += bit.vy * dt;
		bit.vx *= Math.exp(-3 * dt);
		bit.vy *= Math.exp(-3 * dt);
		if (bit.life <= 0) bit.alive = false;
	}
	for (const t of state.texts) t.life -= dt;
	state.texts = state.texts.filter((t) => t.life > 0);
	const look = 42;
	const tx = p.x + Math.cos(p.aim) * look;
	const ty = p.y + Math.sin(p.aim) * look;
	const k = 1 - Math.exp(-7 * dt);
	state.camX += (tx - state.camX) * k;
	state.camY += (ty - state.camY) * k;
	const viewW = state.viewW / Math.max(.2, state.zoom);
	const viewH = state.viewH / Math.max(.2, state.zoom);
	const mapW = map.w * 48;
	const mapH = map.h * 48;
	if (mapW > viewW) state.camX = Math.max(viewW / 2, Math.min(mapW - viewW / 2, state.camX));
	else state.camX = mapW / 2;
	if (mapH > viewH) state.camY = Math.max(viewH / 2, Math.min(mapH - viewH / 2, state.camY));
	else state.camY = mapH / 2;
	reveal(state);
	updatePrompt(state);
}
function snapshot(state) {
	return {
		outcome: state.outcome ?? "mia",
		kills: state.kills,
		pack: state.player.pack.map((it) => ({ ...it })),
		secure: state.player.secure.map((it) => ({ ...it })),
		equipped: {
			weapon: state.player.weapon ? {
				...state.player.weapon,
				mag: state.player.mag
			} : null,
			armor: state.player.armor ? { ...state.player.armor } : null,
			helmet: state.player.helmet ? { ...state.player.helmet } : null
		},
		timeLeft: Math.max(0, state.time)
	};
}
function raidTransfer(state, from, to, uid) {
	const box = state.boxes.find((b) => b.id === state.lootId);
	const lists = {
		pack: state.player.pack,
		secure: state.player.secure,
		box: box?.items ?? []
	};
	const cap = to === "pack" ? state.packCap : to === "secure" ? state.secureCap : 99;
	return moveItem(lists[from], lists[to], uid, cap);
}
function raidDrop(state, uid) {
	const i = state.player.pack.findIndex((it) => it.uid === uid);
	if (i >= 0) {
		state.player.pack.splice(i, 1);
		return true;
	}
	return false;
}
function raidEquip(state, uid) {
	const p = state.player;
	if (p.weapon) p.weapon.mag = p.mag;
	const fromPack = p.pack.find((it) => it.uid === uid);
	const fromSecure = p.secure.find((it) => it.uid === uid);
	const it = fromPack ?? fromSecure;
	if (!it) return "不在身上";
	const d = ITEMS[it.defId];
	const slot = d?.cat === "weapon" ? "weapon" : d?.cat === "armor" ? "armor" : d?.cat === "helmet" ? "helmet" : null;
	if (!slot || !d) return "不能装备";
	const list = fromPack ? p.pack : p.secure;
	const prev = p[slot];
	if (prev && slotsOf(list.filter((x) => x.uid !== uid)) + (ITEMS[prev.defId]?.slots ?? 1) > (fromPack ? state.packCap : state.secureCap)) return "没有空位交换";
	const idx = list.findIndex((x) => x.uid === uid);
	list.splice(idx, 1);
	if (prev) list.push(prev);
	p[slot] = it;
	if (slot === "weapon") p.mag = it.mag ?? 0;
	return null;
}
function reserveAmmo(p) {
	const w = weaponDef(p);
	if (!w?.ammo) return 0;
	return ammoCount(p, w.ammo);
}
function medsLeft(p) {
	return [...p.pack, ...p.secure].filter((it) => ITEMS[it.defId]?.cat === "med").reduce((n, it) => n + it.count, 0);
}
var ctx = null;
var master = null;
var sfxBus = null;
var volume = .7;
function ensure() {
	if (ctx) return ctx;
	ctx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: "interactive" });
	master = ctx.createGain();
	sfxBus = ctx.createGain();
	master.gain.value = volume * volume;
	sfxBus.connect(master);
	master.connect(ctx.destination);
	return ctx;
}
function unlockAudio() {
	const ac = ensure();
	if (ac.state === "suspended") ac.resume();
}
function resumeAudio() {
	if (ctx && ctx.state === "suspended") ctx.resume();
}
function setSfxVolume(v) {
	volume = Math.max(0, Math.min(1, v));
	if (master && ctx) master.gain.setTargetAtTime(volume * volume, ctx.currentTime, .02);
}
function tone(freq, dur, type, gain, slide = 0, noise = 0) {
	if (!ctx || !sfxBus || volume <= .01) return;
	const t = ctx.currentTime;
	const g = ctx.createGain();
	g.gain.setValueAtTime(gain, t);
	g.gain.exponentialRampToValueAtTime(.001, t + dur);
	g.connect(sfxBus);
	if (noise > 0) {
		const n = noiseBuffer(dur);
		if (n) {
			const src = ctx.createBufferSource();
			src.buffer = n;
			const ng = ctx.createGain();
			ng.gain.value = noise;
			src.connect(ng);
			ng.connect(g);
			src.start(t);
			src.stop(t + dur);
		}
	}
	if (freq > 0) {
		const o = ctx.createOscillator();
		o.type = type;
		o.frequency.setValueAtTime(freq, t);
		if (slide) o.frequency.exponentialRampToValueAtTime(Math.max(40, freq + slide), t + dur);
		o.connect(g);
		o.start(t);
		o.stop(t + dur + .02);
	}
}
function noiseBuffer(dur) {
	if (!ctx) return null;
	const len = Math.max(1, Math.floor(ctx.sampleRate * dur));
	const buf = ctx.createBuffer(1, len, ctx.sampleRate);
	const data = buf.getChannelData(0);
	for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
	return buf;
}
function sfx(name) {
	unlockAudio();
	const jitter = .94 + Math.random() * .12;
	switch (name) {
		case "shot":
			tone(210 * jitter, .09, "square", .08, -120, .35);
			break;
		case "shotgun":
			tone(120, .16, "sawtooth", .1, -80, .7);
			break;
		case "hit":
			tone(340 * jitter, .06, "triangle", .05, -180, .15);
			break;
		case "hurt":
			tone(90, .18, "sawtooth", .08, -40, .2);
			break;
		case "dry":
			tone(640, .04, "square", .04, 0, 0);
			break;
		case "reload":
			tone(180, .07, "square", .05, 40, .05);
			tone(90, .09, "triangle", .04, 0, 0);
			break;
		case "search":
			tone(520, .05, "triangle", .04, 80, 0);
			break;
		case "extract":
			tone(440, .12, "sine", .06, 0, 0);
			tone(660, .16, "sine", .05, 0, 0);
			break;
		case "death":
			tone(70, .4, "sawtooth", .09, -30, .3);
			break;
		case "zip":
			tone(880, .08, "sine", .04, 200, 0);
			break;
		default: tone(600, .04, "square", .03, 0, 0);
	}
}
function RaidView({ setup, sfxVol, onEnd }) {
	const canvasRef = (0, import_react.useRef)(null);
	const stateRef = (0, import_react.useRef)(null);
	const keysRef = (0, import_react.useRef)(/* @__PURE__ */ new Set());
	const qaRef = (0, import_react.useRef)(null);
	const edges = (0, import_react.useRef)({
		interact: false,
		reload: false,
		heal: false
	});
	const fireRef = (0, import_react.useRef)(false);
	const aimRef = (0, import_react.useRef)({
		x: 0,
		y: 0,
		ok: false
	});
	const stickRef = (0, import_react.useRef)({
		mx: 0,
		my: 0,
		ax: 0,
		ay: 0,
		aim: false
	});
	const onEndRef = (0, import_react.useRef)(onEnd);
	onEndRef.current = onEnd;
	const [hud, setHud] = (0, import_react.useState)({
		hp: 100,
		time: setup.mapId ? 0 : 0,
		mag: 0,
		reserve: 0,
		weapon: "",
		prompt: "",
		msg: "",
		kills: 0,
		weight: 0,
		limit: setup.weightLimit,
		extract: 0,
		buff: 0,
		meds: 0,
		area: "",
		map: "",
		outcome: ""
	});
	const [panel, setPanel] = (0, import_react.useState)(null);
	const [tick, setTick] = (0, import_react.useState)(0);
	const [touch, setTouch] = (0, import_react.useState)(false);
	const panelRef = (0, import_react.useRef)(panel);
	panelRef.current = panel;
	(0, import_react.useEffect)(() => {
		const coarse = window.matchMedia("(pointer: coarse)").matches || window.innerWidth < 860;
		setTouch(coarse);
		setSfxVolume(sfxVol);
	}, [sfxVol]);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		const state = createRaid(setup);
		stateRef.current = state;
		const ctx = canvas.getContext("2d");
		if (!ctx) return;
		let raf = 0;
		let last = performance.now();
		let acc = 0;
		let hudAcc = 0;
		const ended = { done: false };
		const resize = () => {
			const rect = canvas.getBoundingClientRect();
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			canvas.width = Math.max(1, Math.floor(rect.width * dpr));
			canvas.height = Math.max(1, Math.floor(rect.height * dpr));
			state.viewW = rect.width;
			state.viewH = rect.height;
			state.zoom = rect.width < 700 ? Math.min(1.15, rect.width / 520) : 1.28;
		};
		resize();
		const ro = new ResizeObserver(resize);
		ro.observe(canvas);
		const build = () => {
			const qa = qaRef.current;
			const keys = qa ?? keysRef.current;
			let mx = 0;
			let my = 0;
			if (keys.has("KeyA") || keys.has("ArrowLeft")) mx -= 1;
			if (keys.has("KeyD") || keys.has("ArrowRight")) mx += 1;
			if (keys.has("KeyW") || keys.has("ArrowUp")) my -= 1;
			if (keys.has("KeyS") || keys.has("ArrowDown")) my += 1;
			if (!qa && (stickRef.current.mx || stickRef.current.my)) {
				mx = stickRef.current.mx;
				my = stickRef.current.my;
			}
			let aimX = aimRef.current.x;
			let aimY = aimRef.current.y;
			let aimOk = aimRef.current.ok;
			const aiming = !qa && stickRef.current.aim;
			if (aiming) {
				aimX = state.player.x + stickRef.current.ax * 240;
				aimY = state.player.y + stickRef.current.ay * 240;
				aimOk = true;
			}
			const input = {
				mx,
				my,
				fire: fireRef.current || aiming,
				aimX,
				aimY,
				aimOk,
				interact: edges.current.interact,
				reload: edges.current.reload,
				heal: edges.current.heal
			};
			edges.current.interact = false;
			edges.current.reload = false;
			edges.current.heal = false;
			return input;
		};
		const frame = (now) => {
			const dt = Math.min(.05, (now - last) / 1e3);
			last = now;
			acc += dt;
			const fixed = 1 / 60;
			let guard = 0;
			while (acc >= fixed && guard++ < 5) {
				step(state, fixed, build());
				acc -= fixed;
			}
			for (const ev of state.events) sfx(ev);
			const rect = canvas.getBoundingClientRect();
			const dpr = Math.min(2, window.devicePixelRatio || 1);
			drawRaid(ctx, state, rect.width, rect.height, dpr);
			hudAcc += dt;
			if (hudAcc > .12) {
				hudAcc = 0;
				const gear = {
					weapon: state.player.weapon,
					armor: state.player.armor,
					helmet: state.player.helmet
				};
				setHud({
					hp: Math.max(0, Math.round(state.player.hp)),
					time: Math.max(0, state.time),
					mag: state.player.mag,
					reserve: reserveAmmo(state.player),
					weapon: weaponLabel(state),
					prompt: state.prompt,
					msg: state.msgT > 0 ? state.msg : "",
					kills: state.kills,
					weight: carryWeight(gear, state.player.pack, state.player.secure),
					limit: state.weightLimit,
					extract: state.player.extract,
					buff: state.player.buff,
					meds: medsLeft(state.player),
					area: state.map.area,
					map: state.map.name,
					outcome: state.outcome ?? ""
				});
				if (state.lootId && panelRef.current !== "pack") setPanel("pack");
			}
			if (state.outcome && state.endTimer <= 0 && !state.reported && !ended.done) {
				state.reported = true;
				ended.done = true;
				onEndRef.current(snapshot(state));
			}
			raf = requestAnimationFrame(frame);
		};
		raf = requestAnimationFrame(frame);
		const down = (e) => {
			if (e.repeat) return;
			keysRef.current.add(e.code);
			if ([
				"ArrowUp",
				"ArrowDown",
				"ArrowLeft",
				"ArrowRight",
				"Space",
				"KeyW",
				"KeyA",
				"KeyS",
				"KeyD"
			].includes(e.code)) e.preventDefault();
			if (e.code === "KeyF" || e.code === "KeyE") {
				edges.current.interact = true;
				e.preventDefault();
			}
			if (e.code === "KeyR") edges.current.reload = true;
			if (e.code === "KeyH" || e.code === "Digit1") edges.current.heal = true;
			if (e.code === "Tab") {
				e.preventDefault();
				togglePack();
			}
			if (e.code === "Escape") {
				const s = stateRef.current;
				if (!s || s.outcome) return;
				if (s.lootId || panelRef.current === "pack") closePanels();
				else {
					s.paused = true;
					setPanel("pause");
				}
			}
		};
		const up = (e) => keysRef.current.delete(e.code);
		const blur = () => {
			keysRef.current.clear();
			fireRef.current = false;
		};
		window.addEventListener("keydown", down);
		window.addEventListener("keyup", up);
		window.addEventListener("blur", blur);
		window.__controlsTest = {
			getYaw: () => state.player.aim,
			getSpeed: () => Math.hypot(state.player.vx, state.player.vy),
			setKeys: (codes) => {
				qaRef.current = new Set(codes);
			},
			getX: () => state.player.x,
			getY: () => state.player.y
		};
		return () => {
			cancelAnimationFrame(raf);
			ro.disconnect();
			window.removeEventListener("keydown", down);
			window.removeEventListener("keyup", up);
			window.removeEventListener("blur", blur);
			delete window.__controlsTest;
			delete window.__raidTest;
		};
	}, [setup]);
	function closePanels() {
		const s = stateRef.current;
		if (!s || s.outcome) return;
		s.paused = false;
		s.lootId = null;
		setPanel(null);
	}
	function togglePack() {
		const s = stateRef.current;
		if (!s || s.outcome) return;
		if (panelRef.current === "pause") {
			closePanels();
			return;
		}
		if (s.paused && (s.lootId || panelRef.current === "pack")) {
			closePanels();
			return;
		}
		s.paused = true;
		setPanel("pack");
	}
	function toWorld(clientX, clientY) {
		const canvas = canvasRef.current;
		const st = stateRef.current;
		if (!canvas || !st) return;
		const rect = canvas.getBoundingClientRect();
		aimRef.current.ok = true;
		aimRef.current.x = (clientX - rect.left - rect.width / 2) / st.zoom + st.camX;
		aimRef.current.y = (clientY - rect.top - rect.height / 2) / st.zoom + st.camY;
	}
	const clock = `${Math.floor(hud.time / 60)}:${String(Math.floor(hud.time % 60)).padStart(2, "0")}`;
	const low = hud.hp < 35;
	const st = stateRef.current;
	const box = st?.boxes.find((b) => b.id === st.lootId) ?? null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative h-dvh w-full select-none overflow-hidden bg-bg text-fg touch-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
				ref: canvasRef,
				className: "absolute inset-0 h-full w-full",
				onContextMenu: (e) => e.preventDefault(),
				onPointerDown: (e) => {
					if (e.pointerType === "touch") return;
					unlockAudio();
					if (e.button === 0) {
						fireRef.current = true;
						toWorld(e.clientX, e.clientY);
					}
				},
				onPointerMove: (e) => {
					if (e.pointerType === "touch") return;
					toWorld(e.clientX, e.clientY);
				},
				onPointerUp: (e) => {
					if (e.button === 0) fireRef.current = false;
				},
				onPointerLeave: () => {
					fireRef.current = false;
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 p-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-2/3 max-w-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "font-mono text-xs tracking-widest text-amber",
							children: hud.area || "战区"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-xl leading-tight",
							children: hud.map || "进入中"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 h-2 w-44 bg-surface-2",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `h-full ${low ? "bg-blood" : "bg-amber"}`,
								style: { width: `${hud.hp}%` }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-1 flex flex-wrap gap-x-3 font-mono text-xs text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: low ? "text-blood" : "text-fg",
									children: [hud.hp, " HP"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: clock }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["击倒 ", hud.kills] }),
								hud.buff > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-amber",
									children: [
										"止痛 ",
										Math.ceil(hud.buff),
										"s"
									]
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 text-sm",
							children: [
								hud.weapon,
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-amber",
									children: [hud.mag, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted",
										children: [" / ", hud.reserve]
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-mono text-xs text-muted",
							children: [
								"负重 ",
								hud.weight.toFixed(1),
								" / ",
								hud.limit,
								" kg · 医疗 ",
								hud.meds
							]
						}),
						hud.prompt ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 bg-surface/80 px-2 py-1 text-sm text-amber",
							children: hud.prompt
						}) : null,
						hud.msg ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 text-sm text-fg",
							children: hud.msg
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 hidden text-xs text-muted sm:block",
							children: "WASD 移动 · 鼠标瞄准并按住射击 · F 搜索 · R 换弹 · H 治疗 · Tab 背包"
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: `pointer-events-auto absolute z-20 flex gap-2 ${touch ? "bottom-56 left-1/2 -translate-x-1/2" : "bottom-4 left-3"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HudButton, {
						label: "搜索",
						onClick: () => {
							edges.current.interact = true;
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HudButton, {
						label: "治疗",
						onClick: () => {
							edges.current.heal = true;
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HudButton, {
						label: "背包",
						onClick: togglePack
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HudButton, {
						label: "暂停",
						onClick: () => {
							const s = stateRef.current;
							if (!s || s.outcome) return;
							s.paused = true;
							setPanel("pause");
						}
					})
				]
			}),
			touch ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stick, {
				side: "left",
				onChange: (x, y) => {
					stickRef.current.mx = x;
					stickRef.current.my = y;
				}
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stick, {
				side: "right",
				onChange: (x, y, active) => {
					stickRef.current.ax = x;
					stickRef.current.ay = y;
					stickRef.current.aim = active;
				}
			})] }) : null,
			panel === "pause" && !hud.outcome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-30 flex items-center justify-center bg-bg/80 p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "w-full max-w-sm border border-line bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xl",
							children: "暂停"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-muted",
							children: "计时已停。放弃会按失踪结算，带出来的只有安全箱。"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 flex flex-col gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "min-h-11 bg-amber px-3 text-bg",
								onClick: closePanels,
								children: "继续"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "min-h-11 border border-blood px-3 text-blood",
								onClick: () => {
									const s = stateRef.current;
									if (!s || s.outcome) return;
									s.paused = false;
									s.lootId = null;
									s.outcome = "mia";
									s.endTimer = .05;
									setPanel(null);
								},
								children: "放弃本局"
							})]
						})
					]
				})
			}) : null,
			panel === "pack" && st && !hud.outcome ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-30 flex items-end justify-center bg-bg/70 p-3 sm:items-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "max-h-[85dvh] w-full max-w-lg overflow-y-auto border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg",
								children: box ? "搜索" : "携带物品"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								className: "min-h-11 px-3 text-amber",
								onClick: closePanels,
								children: "关闭"
							})]
						}),
						box ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "mt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "text-sm text-muted",
									children: "里面"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "min-h-11 px-2 text-sm text-amber",
									onClick: () => {
										const live = stateRef.current;
										const liveBox = live?.boxes.find((b) => b.id === live.lootId);
										if (!live || !liveBox) return;
										for (const it of liveBox.items.slice()) if (!raidTransfer(live, "box", "pack", it.uid)) raidTransfer(live, "box", "secure", it.uid);
										setTick((n) => n + 1);
									},
									children: "能拿的都拿走"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemBlock, {
								items: box.items,
								empty: "空了。",
								action: "拿走",
								onAction: (uid) => {
									const live = stateRef.current;
									if (!live) return;
									if (!raidTransfer(live, "box", "pack", uid)) {
										if (!raidTransfer(live, "box", "secure", uid)) return;
									}
									setTick((n) => n + 1);
								}
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-sm text-muted",
								children: [
									"背包 ",
									slotsOf(st.player.pack),
									"/",
									st.packCap
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemBlock, {
								items: st.player.pack,
								empty: "背包是空的。",
								action: box ? "放回" : "丢弃",
								extra: "装备",
								onAction: (uid) => {
									const live = stateRef.current;
									if (!live) return;
									if (box) raidTransfer(live, "pack", "box", uid);
									else raidDrop(live, uid);
									setTick((n) => n + 1);
								},
								onExtra: (uid) => {
									const live = stateRef.current;
									if (!live) return;
									raidEquip(live, uid);
									setTick((n) => n + 1);
								},
								secureAction: "放入安全箱",
								onSecure: (uid) => {
									const live = stateRef.current;
									if (!live) return;
									raidTransfer(live, "pack", "secure", uid);
									setTick((n) => n + 1);
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "mt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
								className: "text-sm text-amber",
								children: [
									"安全箱 ",
									slotsOf(st.player.secure),
									"/",
									st.secureCap,
									" · 死了也留得住"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemBlock, {
								items: st.player.secure,
								empty: "安全箱是空的。贵的东西放这里。",
								action: "拿回背包",
								onAction: (uid) => {
									const live = stateRef.current;
									if (!live) return;
									raidTransfer(live, "secure", "pack", uid);
									setTick((n) => n + 1);
								}
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs text-muted",
							"data-tick": tick,
							children: "负重过高会变慢。治疗时开枪会打断包扎。"
						})
					]
				})
			}) : null,
			hud.outcome === "dead" || hud.outcome === "mia" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 z-40 flex items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border border-blood px-6 py-3 font-mono text-2xl tracking-widest text-blood",
					children: hud.outcome === "mia" ? "失踪" : "失去意识"
				})
			}) : null,
			hud.outcome === "extract" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 z-40 flex items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border border-amber px-6 py-3 font-mono text-2xl tracking-widest text-amber",
					children: "已撤离"
				})
			}) : null
		]
	});
}
function HudButton({ label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: "min-h-11 min-w-14 bg-surface/90 px-3 text-sm text-fg border border-line",
		onClick,
		children: label
	});
}
function Stick({ side, onChange }) {
	const origin = (0, import_react.useRef)(null);
	const [knob, setKnob] = (0, import_react.useState)({
		x: 0,
		y: 0
	});
	const end = () => {
		origin.current = null;
		setKnob({
			x: 0,
			y: 0
		});
		onChange(0, 0, false);
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `absolute bottom-24 z-20 size-28 rounded-full border border-line bg-surface/70 ${side === "left" ? "left-4" : "right-4"}`,
		onPointerDown: (e) => {
			unlockAudio();
			e.currentTarget.setPointerCapture(e.pointerId);
			origin.current = {
				x: e.clientX,
				y: e.clientY,
				id: e.pointerId
			};
		},
		onPointerMove: (e) => {
			if (!origin.current || origin.current.id !== e.pointerId) return;
			let dx = e.clientX - origin.current.x;
			let dy = e.clientY - origin.current.y;
			const len = Math.hypot(dx, dy);
			const max = 44;
			if (len > max) {
				dx = dx / len * max;
				dy = dy / len * max;
			}
			setKnob({
				x: dx,
				y: dy
			});
			onChange(len > 6 ? dx / max : 0, len > 6 ? dy / max : 0, len > 6);
		},
		onPointerUp: end,
		onPointerCancel: end,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute left-1/2 top-1/2 size-11 rounded-full bg-amber",
			style: { transform: `translate(calc(-50% + ${knob.x}px), calc(-50% + ${knob.y}px))` }
		})
	});
}
function ItemBlock({ items, empty, action, onAction, extra, onExtra, secureAction, onSecure }) {
	if (!items.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-1 text-sm text-muted",
		children: empty
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-1",
		children: items.map((it) => {
			const d = ITEMS[it.defId];
			if (!d) return null;
			const gear = d.cat === "weapon" || d.cat === "armor" || d.cat === "helmet";
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center gap-2 border-b border-line py-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: d.rarity === "rare" || d.rarity === "legendary" ? "text-amber" : "text-fg",
							children: [d.name, d.stack ? ` ×${it.count}` : ""]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "font-mono text-xs text-muted",
							children: [sellValue(it).toLocaleString("zh-CN"), " ₽"]
						})]
					}),
					secureAction && onSecure ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "min-h-11 px-2 text-sm text-amber",
						onClick: () => onSecure(it.uid),
						children: secureAction
					}) : null,
					extra && onExtra && gear ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "min-h-11 px-2 text-sm text-fg",
						onClick: () => onExtra(it.uid),
						children: extra
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "min-h-11 px-2 text-sm text-muted",
						onClick: () => onAction(it.uid),
						children: action
					})
				]
			}, it.uid);
		})
	});
}
function GameApp() {
	const [save, setSave] = (0, import_react.useState)(freshSave);
	const [ready, setReady] = (0, import_react.useState)(false);
	const [phase, setPhase] = (0, import_react.useState)("hideout");
	const [setup, setSetup] = (0, import_react.useState)(null);
	const [debrief, setDebrief] = (0, import_react.useState)(null);
	const [toast, setToast] = (0, import_react.useState)("");
	const saveRef = (0, import_react.useRef)(save);
	saveRef.current = save;
	const ended = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		const loaded = loadSave();
		setSave(loaded);
		setSfxVolume(loaded.sfx);
		setReady(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (ready) writeSave(save);
	}, [save, ready]);
	(0, import_react.useEffect)(() => {
		const unlock = () => unlockAudio();
		const vis = () => {
			if (document.visibilityState === "visible") resumeAudio();
		};
		window.addEventListener("pointerdown", unlock);
		window.addEventListener("keydown", unlock);
		document.addEventListener("visibilitychange", vis);
		return () => {
			window.removeEventListener("pointerdown", unlock);
			window.removeEventListener("keydown", unlock);
			document.removeEventListener("visibilitychange", vis);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		if (!toast) return;
		const id = window.setTimeout(() => setToast(""), 2200);
		return () => window.clearTimeout(id);
	}, [toast]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "min-h-dvh bg-bg text-fg",
		children: [
			phase === "hideout" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hideout, {
				save,
				setSave,
				toast: setToast,
				onDeploy: (mapId, insure) => {
					const result = beginRaid(save, mapId, insure);
					if ("error" in result) {
						setToast(result.error);
						return;
					}
					setSave(result.save);
					setSetup(result.setup);
					setDebrief(null);
					ended.current = false;
					setPhase("raid");
				}
			}) : null,
			phase === "raid" && setup ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RaidView, {
				setup,
				sfxVol: save.sfx,
				onEnd: (result) => {
					if (ended.current) return;
					ended.current = true;
					const out = finishRaid(saveRef.current, setup, result);
					setSave(out.save);
					setDebrief(out.debrief);
					setPhase("debrief");
				}
			}) : null,
			phase === "debrief" && debrief ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DebriefView, {
				debrief,
				onBack: () => {
					setPhase("hideout");
					setSetup(null);
				}
			}) : null,
			toast ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed bottom-4 left-1/2 z-50 -translate-x-1/2 border border-line bg-surface-2 px-4 py-3 text-sm text-fg",
				children: toast
			}) : null,
			phase === "hideout" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "fixed right-3 top-3 z-40 min-h-11 border border-line bg-surface px-3 font-mono text-xs text-muted",
				onClick: () => {
					const next = Math.max(0, save.sfx > .2 ? 0 : .7);
					setSfxVolume(next);
					setSave({
						...save,
						sfx: next
					});
				},
				children: save.sfx > .05 ? "音效 开" : "音效 关"
			}) : null
		]
	});
}
function DebriefView({ debrief, onBack }) {
	const ok = debrief.outcome === "extract";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto flex min-h-dvh max-w-xl flex-col justify-center px-4 py-8",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border border-line bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: `font-mono text-xs tracking-widest ${ok ? "text-amber" : "text-blood"}`,
					children: debrief.mapName
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: `mt-2 text-3xl ${ok ? "text-amber" : "text-blood"}`,
					children: ok ? "已撤离" : debrief.outcome === "mia" ? "失踪" : "阵亡"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-muted",
					children: debrief.note
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 font-mono text-sm text-fg",
					children: [
						"击倒 ",
						debrief.kills,
						" · 经验 +",
						debrief.xp,
						ok ? ` · 新货估值 ${debrief.lootValue.toLocaleString("zh-CN")} ₽` : ""
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LootList, {
					title: ok ? "带回来的" : "还在身上的",
					items: debrief.kept
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LootList, {
					title: "留在湾里",
					items: debrief.lost
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LootList, {
					title: "保险退回",
					items: debrief.returned
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "mt-6 min-h-11 w-full bg-amber text-bg",
					onClick: onBack,
					children: "返回藏身处"
				})
			]
		})
	});
}
function LootList({ title, items }) {
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "text-sm text-muted",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-1 text-sm",
			children: items.map((it) => {
				const d = ITEMS[it.defId];
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "border-b border-line py-1",
					children: [d?.name ?? it.defId, d?.stack ? ` ×${it.count}` : ""]
				}, `${title}-${it.uid}`);
			})
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GameApp, {});
}
//#endregion
export { Home as component };
