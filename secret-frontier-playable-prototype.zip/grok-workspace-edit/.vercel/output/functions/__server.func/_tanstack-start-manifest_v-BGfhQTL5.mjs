//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BGfhQTL5.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-C7JtBEkt.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C7JtBEkt.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BBXrjYxb.js"]
	}
} });
//#endregion
export { tsrStartManifest };
