import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.secretfrontier.game",
  appName: "秘境边境",
  webDir: "mobile-dist",
  bundledWebRuntime: false,
  android: {
    allowMixedContent: false,
    backgroundColor: "#0e100e",
  },
};

export default config;
